from __future__ import annotations

import json
import tempfile
import unittest
from datetime import UTC, datetime, timedelta
from pathlib import Path

from jsonschema import Draft202012Validator

from qincert.evidence.bundle import build_bundle, generate_keypair, verify_bundle


class EvidenceTests(unittest.TestCase):
    def test_signed_bundle_schema_hash_and_artifact(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            artifact = root / "contract.sol"
            artifact.write_text("contract C {}", encoding="utf-8")
            private, _ = generate_keypair()
            envelope = build_bundle(
                subject="fixture",
                artifacts=[artifact],
                checks=[
                    {
                        "id": "unit",
                        "result": "TESTED",
                        "evidence": "tests passed",
                    }
                ],
                scope={"profile": "test"},
                exclusions=["not a complete audit"],
                private_key_pem=private,
                expires_at=(datetime.now(UTC) + timedelta(days=1)).isoformat(),
            )
            schema = json.loads(
                (
                    Path(__file__).resolve().parents[1]
                    / "schemas"
                    / "evidence-0.2.0.schema.json"
                ).read_text(encoding="utf-8")
            )
            Draft202012Validator(schema).validate(envelope)
            result = verify_bundle(envelope, artifact_root=root)
            self.assertTrue(result["valid"], result)
            self.assertTrue(result["signature_valid"])

            artifact.write_text("contract Tampered {}", encoding="utf-8")
            tampered = verify_bundle(envelope, artifact_root=root)
            self.assertFalse(tampered["valid"])
            self.assertIn("artifact hash mismatch: contract.sol", tampered["errors"])

    def test_expiry_invalidates_bundle(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            artifact = root / "a.txt"
            artifact.write_text("a", encoding="utf-8")
            envelope = build_bundle(
                subject="expired",
                artifacts=[artifact],
                checks=[],
                scope={},
                exclusions=[],
                expires_at="2020-01-01T00:00:00+00:00",
            )
            result = verify_bundle(
                envelope,
                artifact_root=root,
                now=datetime(2026, 1, 1, tzinfo=UTC),
            )
            self.assertFalse(result["valid"])


if __name__ == "__main__":
    unittest.main()
