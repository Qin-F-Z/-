from __future__ import annotations

import random
import unittest
from fractions import Fraction
from math import ceil, floor

from qincert.math.core import MAX_UINT256, Rounding, mul_div, mul_div_u256, sqrt_round


def nearest_reference(value: Fraction, half_even: bool) -> int:
    negative = value < 0
    magnitude = abs(value)
    lower = magnitude.numerator // magnitude.denominator
    remainder = magnitude - lower
    if remainder < Fraction(1, 2):
        answer = lower
    elif remainder > Fraction(1, 2):
        answer = lower + 1
    elif half_even:
        answer = lower if lower % 2 == 0 else lower + 1
    else:
        answer = lower + 1
    return -answer if negative else answer


class MathTests(unittest.TestCase):
    def test_small_domain_all_rounding_modes(self) -> None:
        for a in range(-12, 13):
            for b in range(-12, 13):
                for d in range(1, 13):
                    exact = Fraction(a * b, d)
                    expected = {
                        Rounding.DOWN: floor(exact),
                        Rounding.UP: ceil(exact),
                        Rounding.TOWARD_ZERO: int(exact),
                        Rounding.AWAY_FROM_ZERO: (
                            ceil(exact) if exact > 0 else floor(exact)
                        ),
                        Rounding.HALF_UP: nearest_reference(exact, False),
                        Rounding.HALF_EVEN: nearest_reference(exact, True),
                    }
                    for mode, answer in expected.items():
                        self.assertEqual(
                            mul_div(a, b, d, mode),
                            answer,
                            (a, b, d, mode),
                        )

    def test_randomized_exact_reference(self) -> None:
        random.seed(4626)
        for _ in range(5_000):
            a = random.randint(-(1 << 128), 1 << 128)
            b = random.randint(-(1 << 128), 1 << 128)
            d = random.randint(1, 1 << 128)
            exact = Fraction(a * b, d)
            self.assertEqual(mul_div(a, b, d, Rounding.DOWN), floor(exact))
            self.assertEqual(mul_div(a, b, d, Rounding.UP), ceil(exact))

    def test_u256_boundaries(self) -> None:
        self.assertEqual(mul_div_u256(MAX_UINT256, MAX_UINT256, MAX_UINT256), MAX_UINT256)
        with self.assertRaises(OverflowError):
            mul_div_u256(MAX_UINT256, MAX_UINT256, 1)
        with self.assertRaises(OverflowError):
            mul_div_u256(-1, 1, 1)
        with self.assertRaises(ZeroDivisionError):
            mul_div_u256(1, 1, 0)

    def test_square_root_directions(self) -> None:
        self.assertEqual(sqrt_round(0), 0)
        self.assertEqual(sqrt_round(16, Rounding.UP), 4)
        self.assertEqual(sqrt_round(17, Rounding.DOWN), 4)
        self.assertEqual(sqrt_round(17, Rounding.UP), 5)
        for value in range(10_000):
            low = sqrt_round(value, Rounding.DOWN)
            high = sqrt_round(value, Rounding.UP)
            self.assertLessEqual(low * low, value)
            self.assertGreaterEqual(high * high, value)


if __name__ == "__main__":
    unittest.main()
