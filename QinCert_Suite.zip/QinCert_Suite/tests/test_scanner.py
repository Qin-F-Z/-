from __future__ import annotations

import unittest
from pathlib import Path

from qincert.scanner import SolidityAnalyzer


FIXTURES = Path(__file__).resolve().parents[1] / "datasets" / "fixtures"


class ScannerTests(unittest.TestCase):
    def test_raw_vault_reports_upward_rounding_conflicts(self) -> None:
        result = SolidityAnalyzer().scan(FIXTURES / "UnsafeRawVault.sol")
        high_functions = {
            finding.function
            for finding in result.findings
            if finding.rule_id == "QIN-MATH-001" and finding.severity == "high"
        }
        self.assertIn("previewMint", high_functions)
        self.assertIn("previewWithdraw", high_functions)
        self.assertTrue(
            any(finding.rule_id == "QIN4626-001" for finding in result.findings)
        )
        mint_allocations = [
            allocation
            for graph in result.semantic_graphs
            for allocation in graph.allocations
            if allocation.function == "previewMint"
        ]
        self.assertTrue(mint_allocations)
        self.assertEqual(mint_allocations[0].remainder_beneficiary, "caller")
        self.assertEqual(
            mint_allocations[0].remainder_cost_bearer,
            "vault_or_protocol",
        )

    def test_comments_do_not_spoof_guards(self) -> None:
        result = SolidityAnalyzer().scan(FIXTURES / "CommentSpoof.sol")
        rules = {finding.rule_id for finding in result.findings}
        self.assertIn("QIN4626-001", rules)
        self.assertIn("QIN4626-003", rules)

    def test_explicit_policy_fixture_has_no_high_findings(self) -> None:
        result = SolidityAnalyzer().scan(FIXTURES / "ExplicitPolicyVault.sol")
        high = [finding for finding in result.findings if finding.severity == "high"]
        self.assertEqual(high, [], [finding.to_dict() for finding in high])
        self.assertEqual(result.profile, "erc4626")


if __name__ == "__main__":
    unittest.main()
