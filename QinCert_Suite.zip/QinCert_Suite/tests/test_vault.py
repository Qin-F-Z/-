from __future__ import annotations

import unittest

from qincert.vault import (
    AssetBehavior,
    assess_deposit_behavior,
    donation_counterexample_test,
)
from qincert.vault.model import VaultState, find_donation_counterexample


class VaultTests(unittest.TestCase):
    def test_preview_directions(self) -> None:
        state = VaultState(1_003, 997, 1, 1_000)
        for amount in range(1, 300):
            deposit_shares = state.preview_deposit(amount)
            mint_assets = state.preview_mint(amount)
            withdraw_shares = state.preview_withdraw(amount)
            redeem_assets = state.preview_redeem(amount)
            self.assertLessEqual(
                deposit_shares * state.effective_assets,
                amount * state.effective_supply,
            )
            self.assertGreaterEqual(
                mint_assets * state.effective_supply,
                amount * state.effective_assets,
            )
            self.assertGreaterEqual(
                withdraw_shares * state.effective_assets,
                amount * state.effective_supply,
            )
            self.assertLessEqual(
                redeem_assets * state.effective_supply,
                amount * state.effective_assets,
            )

    def test_empty_vault_one_to_one(self) -> None:
        state = VaultState(0, 0, 0, 0)
        self.assertEqual(state.preview_deposit(123), 123)
        self.assertEqual(state.preview_redeem(123), 123)

    def test_round_trip_cannot_increase_assets(self) -> None:
        for assets_total in range(1, 40):
            for supply in range(1, 40):
                state = VaultState(assets_total, supply, 1, 1)
                for amount in range(1, 40):
                    shares = state.preview_deposit(amount)
                    self.assertLessEqual(state.preview_redeem(shares), amount)

    def test_unsafe_donation_counterexample(self) -> None:
        result = find_donation_counterexample(
            seed_max=5,
            donation_max=30,
            victim_max=20,
            virtual_assets=0,
            virtual_shares=0,
        )
        self.assertIsNotNone(result)
        assert result is not None
        self.assertGreater(result.victim_loss_assets, 0)

    def test_virtual_offset_changes_attack_surface(self) -> None:
        unprotected = find_donation_counterexample(
            seed_max=4,
            donation_max=20,
            victim_max=15,
            virtual_assets=0,
            virtual_shares=0,
        )
        protected = find_donation_counterexample(
            seed_max=4,
            donation_max=20,
            victim_max=15,
            virtual_assets=1,
            virtual_shares=1_000_000,
            require_profit=True,
        )
        self.assertIsNotNone(unprotected)
        self.assertIsNone(protected)

    def test_fee_on_transfer_overmint_is_measured(self) -> None:
        state = VaultState(1_000, 1_000, 1, 1)
        assessment = assess_deposit_behavior(
            state,
            100,
            AssetBehavior(decimals=6, transfer_fee_bps=100),
        )
        self.assertEqual(assessment.received_assets, 99)
        self.assertGreater(assessment.overminted_shares, 0)
        self.assertTrue(assessment.low_decimal_asset)

    def test_foundry_reproducer_contains_exact_values(self) -> None:
        result = find_donation_counterexample(
            seed_max=5,
            donation_max=30,
            victim_max=20,
            virtual_assets=0,
            virtual_shares=0,
        )
        assert result is not None
        source = donation_counterexample_test(result)
        self.assertIn(f"uint256 attackerSeed = {result.seed_assets};", source)
        self.assertIn(f"assertEq(victimPreview, {result.victim_shares});", source)


if __name__ == "__main__":
    unittest.main()
