#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"

if [ ! -x .venv/bin/python ]; then
  python3.12 -m venv .venv
fi

.venv/bin/python -m pip install --disable-pip-version-check "pip==25.0.1"
.venv/bin/python -m pip install --disable-pip-version-check -c requirements-constraints.txt -e ".[proof,test]"
npm ci --prefix tooling --no-audit --no-fund
.venv/bin/python scripts/verify_all.py
