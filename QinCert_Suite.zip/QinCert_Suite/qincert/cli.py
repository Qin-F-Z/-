"""QinCert command-line interface."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .evidence.bundle import (
    build_bundle,
    generate_keypair,
    load_bundle,
    verify_bundle,
)
from .math.core import Rounding, mul_div
from .scanner import SolidityAnalyzer
from .vault import donation_counterexample_test, find_donation_counterexample


def _json_dump(payload: object) -> None:
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def _math_command(args: argparse.Namespace) -> int:
    print(mul_div(args.a, args.b, args.denominator, Rounding(args.rounding)))
    return 0


def _attack_command(args: argparse.Namespace) -> int:
    result = find_donation_counterexample(
        seed_max=args.seed_max,
        donation_max=args.donation_max,
        victim_max=args.victim_max,
        virtual_assets=args.virtual_assets,
        virtual_shares=args.virtual_shares,
        require_profit=args.require_profit,
    )
    _json_dump(
        {
            "result": "COUNTEREXAMPLE" if result else "NO_COUNTEREXAMPLE_IN_BOUNDS",
            "counterexample": result.to_dict() if result else None,
            "claim_boundary": "bounded search; not a universal proof",
        }
    )
    if result and args.foundry_output:
        Path(args.foundry_output).write_text(
            donation_counterexample_test(result),
            encoding="utf-8",
        )
    return 1 if result else 0


def _scan_command(args: argparse.Namespace) -> int:
    result = SolidityAnalyzer().scan(args.path)
    if args.format == "json":
        print(result.to_json())
    elif args.format == "sarif":
        _json_dump(result.to_sarif())
    else:
        print(f"QinCert {result.profile} scan: {result.source_path}")
        for finding in result.findings:
            print(
                f"{finding.severity.upper():8} "
                f"{finding.rule_id} "
                f"L{finding.source.line}:{finding.source.column} "
                f"{finding.title}"
            )
            print(f"  {finding.message}")
        if not result.findings:
            print("No findings in the implemented rule set.")
        print("Limitations:")
        for limitation in result.limitations:
            print(f"  - {limitation}")
    return 1 if any(
        finding.severity in {"critical", "high"} for finding in result.findings
    ) else 0


def _keygen_command(args: argparse.Namespace) -> int:
    private, public = generate_keypair()
    private_path = Path(args.private).resolve()
    public_path = Path(args.public).resolve()
    private_path.write_bytes(private)
    public_path.write_bytes(public)
    print(f"private key written to {private_path}")
    print(f"public key written to {public_path}")
    return 0


def _evidence_build_command(args: argparse.Namespace) -> int:
    private_key = Path(args.private_key).read_bytes() if args.private_key else None
    checks = json.loads(Path(args.checks).read_text(encoding="utf-8"))
    envelope = build_bundle(
        subject=args.subject,
        artifacts=[Path(item) for item in args.artifact],
        checks=checks,
        scope={"profile": args.profile, "claim": args.claim},
        exclusions=args.exclude,
        private_key_pem=private_key,
        expires_at=args.expires_at,
        artifact_root=Path(args.artifact_root) if args.artifact_root else None,
    )
    Path(args.output).write_text(
        json.dumps(envelope, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return 0


def _evidence_verify_command(args: argparse.Namespace) -> int:
    result = verify_bundle(
        load_bundle(args.bundle),
        artifact_root=args.artifact_root,
    )
    _json_dump(result)
    return 0 if result["valid"] else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="qincert")
    commands = parser.add_subparsers(dest="command", required=True)

    math_group = commands.add_parser("math")
    math_commands = math_group.add_subparsers(dest="math_command", required=True)
    mul = math_commands.add_parser("mul-div")
    mul.add_argument("a", type=int)
    mul.add_argument("b", type=int)
    mul.add_argument("denominator", type=int)
    mul.add_argument(
        "--rounding",
        choices=[mode.value for mode in Rounding],
        default=Rounding.DOWN.value,
    )
    mul.set_defaults(handler=_math_command)

    attack = commands.add_parser("attack")
    attack.add_argument("--seed-max", type=int, default=8)
    attack.add_argument("--donation-max", type=int, default=100)
    attack.add_argument("--victim-max", type=int, default=50)
    attack.add_argument("--virtual-assets", type=int, default=0)
    attack.add_argument("--virtual-shares", type=int, default=0)
    attack.add_argument("--require-profit", action="store_true")
    attack.add_argument("--foundry-output")
    attack.set_defaults(handler=_attack_command)

    scan = commands.add_parser("scan")
    scan.add_argument("path")
    scan.add_argument("--format", choices=("text", "json", "sarif"), default="text")
    scan.set_defaults(handler=_scan_command)

    evidence = commands.add_parser("evidence")
    evidence_commands = evidence.add_subparsers(
        dest="evidence_command", required=True
    )
    keygen = evidence_commands.add_parser("keygen")
    keygen.add_argument("--private", required=True)
    keygen.add_argument("--public", required=True)
    keygen.set_defaults(handler=_keygen_command)

    build = evidence_commands.add_parser("build")
    build.add_argument("--subject", required=True)
    build.add_argument("--artifact", action="append", default=[], required=True)
    build.add_argument("--checks", required=True)
    build.add_argument("--profile", default="erc4626")
    build.add_argument("--claim", default="arithmetic-specialist assessment")
    build.add_argument("--exclude", action="append", default=[])
    build.add_argument("--private-key")
    build.add_argument("--artifact-root")
    build.add_argument("--expires-at")
    build.add_argument("--output", required=True)
    build.set_defaults(handler=_evidence_build_command)

    verify = evidence_commands.add_parser("verify")
    verify.add_argument("bundle")
    verify.add_argument("--artifact-root")
    verify.set_defaults(handler=_evidence_verify_command)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.handler(args))
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
