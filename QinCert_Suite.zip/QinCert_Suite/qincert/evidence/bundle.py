"""Canonical, signed, input-bound QinCert evidence bundles."""

from __future__ import annotations

import base64
import hashlib
import json
import platform
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Iterable

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)


def canonical_bytes(payload: dict) -> bytes:
    """Stable UTF-8 serialization used for hashes and signatures."""

    return json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def generate_keypair() -> tuple[bytes, bytes]:
    private = Ed25519PrivateKey.generate()
    public = private.public_key()
    private_bytes = private.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    )
    public_bytes = public.public_bytes(
        serialization.Encoding.PEM,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return private_bytes, public_bytes


def _utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat()


def build_bundle(
    *,
    subject: str,
    artifacts: Iterable[Path],
    checks: list[dict],
    scope: dict,
    exclusions: list[str],
    private_key_pem: bytes | None = None,
    expires_at: str | None = None,
    tool_version: str = "0.2.0",
    artifact_root: Path | None = None,
) -> dict:
    artifact_records = []
    resolved_root = artifact_root.resolve() if artifact_root else None
    for path in sorted((Path(item).resolve() for item in artifacts), key=str):
        if resolved_root:
            if resolved_root not in path.parents and path != resolved_root:
                raise ValueError(f"artifact is outside artifact root: {path}")
            recorded_path = path.relative_to(resolved_root).as_posix()
        else:
            recorded_path = path.name
        artifact_records.append(
            {
                "path": recorded_path,
                "size": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    payload = {
        "schema": "https://qincert.example/schemas/evidence-0.2.0.json",
        "schema_version": "0.2.0",
        "subject": subject,
        "created_at": _utc_now(),
        "expires_at": expires_at,
        "status": "valid",
        "tool": {
            "name": "QinCert",
            "version": tool_version,
            "python": sys.version.split()[0],
            "platform": platform.platform(),
        },
        "scope": scope,
        "artifacts": artifact_records,
        "checks": checks,
        "exclusions": exclusions,
    }
    evidence_hash = hashlib.sha256(canonical_bytes(payload)).hexdigest()
    envelope = {
        "payload": payload,
        "evidence_sha256": evidence_hash,
        "signature": None,
    }
    if private_key_pem:
        private = serialization.load_pem_private_key(private_key_pem, password=None)
        if not isinstance(private, Ed25519PrivateKey):
            raise TypeError("private key must be Ed25519")
        signature = private.sign(canonical_bytes(payload))
        public = private.public_key().public_bytes(
            serialization.Encoding.Raw,
            serialization.PublicFormat.Raw,
        )
        envelope["signature"] = {
            "algorithm": "Ed25519",
            "public_key": base64.b64encode(public).decode("ascii"),
            "value": base64.b64encode(signature).decode("ascii"),
        }
    return envelope


def load_bundle(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def verify_bundle(
    envelope: dict,
    *,
    artifact_root: str | Path | None = None,
    now: datetime | None = None,
) -> dict:
    errors: list[str] = []
    payload = envelope.get("payload")
    if not isinstance(payload, dict):
        return {"valid": False, "status": "invalid", "errors": ["missing payload"]}

    actual_hash = hashlib.sha256(canonical_bytes(payload)).hexdigest()
    if actual_hash != envelope.get("evidence_sha256"):
        errors.append("evidence hash mismatch")

    signature = envelope.get("signature")
    signature_valid = False
    if signature:
        try:
            if signature.get("algorithm") != "Ed25519":
                raise ValueError("unsupported signature algorithm")
            public = Ed25519PublicKey.from_public_bytes(
                base64.b64decode(signature["public_key"])
            )
            public.verify(
                base64.b64decode(signature["value"]),
                canonical_bytes(payload),
            )
            signature_valid = True
        except Exception as exc:  # cryptography exposes multiple invalid types
            errors.append(f"invalid signature: {exc}")

    if artifact_root is not None:
        root = Path(artifact_root).resolve()
        for artifact in payload.get("artifacts", []):
            candidate = (root / artifact["path"]).resolve()
            if root not in candidate.parents and candidate != root:
                errors.append(f"artifact escapes root: {artifact['path']}")
                continue
            if not candidate.exists():
                errors.append(f"artifact missing: {artifact['path']}")
            elif sha256_file(candidate) != artifact["sha256"]:
                errors.append(f"artifact hash mismatch: {artifact['path']}")

    current = now or datetime.now(UTC)
    status = str(payload.get("status", "invalid"))
    expires_at = payload.get("expires_at")
    if expires_at and current >= datetime.fromisoformat(expires_at):
        status = "expired"
        errors.append("evidence expired")
    if status in {"revoked", "superseded", "expired", "invalid"}:
        errors.append(f"evidence status is {status}")

    checks = payload.get("checks", [])
    failing = [
        check.get("id", "<unnamed>")
        for check in checks
        if check.get("result") not in {"PROVED", "TESTED", "CONDITIONAL"}
    ]
    if failing:
        errors.append("non-passing checks: " + ", ".join(failing))

    return {
        "valid": not errors,
        "status": status if not errors else "invalid",
        "signature_present": bool(signature),
        "signature_valid": signature_valid,
        "errors": errors,
    }
