"""Asset-behavior assessments for ERC-4626 arithmetic assumptions."""

from __future__ import annotations

from dataclasses import asdict, dataclass

from qincert.math.core import Rounding, mul_div_u256

from .model import VaultState

BPS = 10_000


@dataclass(frozen=True, slots=True)
class AssetBehavior:
    decimals: int = 18
    transfer_fee_bps: int = 0
    rebase_numerator: int = 1
    rebase_denominator: int = 1

    def __post_init__(self) -> None:
        if not 0 <= self.decimals <= 36:
            raise ValueError("decimals outside supported assessment range")
        if not 0 <= self.transfer_fee_bps < BPS:
            raise ValueError("transfer fee must be in [0, 10000)")
        if self.rebase_numerator < 0 or self.rebase_denominator <= 0:
            raise ValueError("invalid rebase ratio")

    def amount_received(self, sent: int) -> int:
        return mul_div_u256(
            sent,
            BPS - self.transfer_fee_bps,
            BPS,
            Rounding.DOWN,
        )

    def rebased_balance(self, balance: int) -> int:
        return mul_div_u256(
            balance,
            self.rebase_numerator,
            self.rebase_denominator,
            Rounding.DOWN,
        )


@dataclass(frozen=True, slots=True)
class DepositBehaviorAssessment:
    nominal_assets: int
    received_assets: int
    preview_shares: int
    economically_backed_shares: int
    overminted_shares: int
    post_rebase_assets: int
    zero_share_risk: bool
    low_decimal_asset: bool
    findings: tuple[str, ...]

    def to_dict(self) -> dict:
        return asdict(self)


def assess_deposit_behavior(
    state: VaultState,
    nominal_assets: int,
    behavior: AssetBehavior,
) -> DepositBehaviorAssessment:
    if nominal_assets <= 0:
        raise ValueError("nominal assets must be positive")
    received = behavior.amount_received(nominal_assets)
    preview = state.preview_deposit(nominal_assets)
    backed = state.preview_deposit(received)
    overminted = max(0, preview - backed)
    post_rebase = behavior.rebased_balance(state.total_assets + received)
    findings: list[str] = []
    if received != nominal_assets:
        findings.append(
            "fee-on-transfer changes the amount received; nominal-amount "
            "minting may over-issue shares"
        )
    if overminted > 0:
        findings.append(f"deposit overmints {overminted} share units")
    if behavior.rebase_numerator != behavior.rebase_denominator:
        findings.append(
            "rebasing changes vault balance independently of ERC-4626 actions"
        )
    if behavior.decimals <= 6:
        findings.append(
            "low-decimal assets increase rounding granularity and require "
            "explicit minimum-output tests"
        )
    if preview == 0:
        findings.append("positive nominal deposit previews zero shares")
    return DepositBehaviorAssessment(
        nominal_assets,
        received,
        preview,
        backed,
        overminted,
        post_rebase,
        preview == 0,
        behavior.decimals <= 6,
        tuple(findings),
    )
