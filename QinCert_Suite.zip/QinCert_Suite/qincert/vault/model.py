"""Executable ERC-4626 arithmetic model and bounded attack search."""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from fractions import Fraction
from typing import Iterator

from qincert.math.core import Rounding, mul_div_u256


@dataclass(frozen=True, slots=True)
class VaultState:
    total_assets: int
    total_supply: int
    virtual_assets: int = 1
    virtual_shares: int = 1

    def __post_init__(self) -> None:
        for field, value in asdict(self).items():
            if value < 0:
                raise ValueError(f"{field} must be non-negative")

    @property
    def effective_assets(self) -> int:
        return self.total_assets + self.virtual_assets

    @property
    def effective_supply(self) -> int:
        return self.total_supply + self.virtual_shares

    def convert_to_shares(
        self, assets: int, rounding: Rounding = Rounding.DOWN
    ) -> int:
        if self.effective_supply == 0:
            return assets
        if self.effective_assets == 0:
            raise ZeroDivisionError("effective assets are zero")
        return mul_div_u256(
            assets, self.effective_supply, self.effective_assets, rounding
        )

    def convert_to_assets(
        self, shares: int, rounding: Rounding = Rounding.DOWN
    ) -> int:
        if self.effective_supply == 0:
            return shares
        return mul_div_u256(
            shares, self.effective_assets, self.effective_supply, rounding
        )

    def preview_deposit(self, assets: int) -> int:
        return self.convert_to_shares(assets, Rounding.DOWN)

    def preview_mint(self, shares: int) -> int:
        return self.convert_to_assets(shares, Rounding.UP)

    def preview_withdraw(self, assets: int) -> int:
        return self.convert_to_shares(assets, Rounding.UP)

    def preview_redeem(self, shares: int) -> int:
        return self.convert_to_assets(shares, Rounding.DOWN)

    def deposit(self, assets: int, minimum_shares: int = 1) -> "ActionResult":
        if assets <= 0:
            raise ValueError("deposit assets must be positive")
        shares = self.preview_deposit(assets)
        if shares < minimum_shares:
            raise ValueError("deposit violates minimum shares")
        new_state = replace(
            self,
            total_assets=self.total_assets + assets,
            total_supply=self.total_supply + shares,
        )
        return ActionResult(self, new_state, assets, shares, "deposit")

    def donate(self, assets: int) -> "ActionResult":
        if assets < 0:
            raise ValueError("donation must be non-negative")
        new_state = replace(self, total_assets=self.total_assets + assets)
        return ActionResult(self, new_state, assets, 0, "donate")

    def redeem(self, shares: int) -> "ActionResult":
        if shares <= 0 or shares > self.total_supply:
            raise ValueError("invalid redeem shares")
        assets = self.preview_redeem(shares)
        new_state = replace(
            self,
            total_assets=self.total_assets - assets,
            total_supply=self.total_supply - shares,
        )
        return ActionResult(self, new_state, assets, shares, "redeem")


@dataclass(frozen=True, slots=True)
class ActionResult:
    before: VaultState
    after: VaultState
    assets: int
    shares: int
    action: str


@dataclass(frozen=True, slots=True)
class AttackCounterexample:
    seed_assets: int
    donation_assets: int
    victim_assets: int
    attacker_shares: int
    victim_shares: int
    attacker_redeem_assets: int
    attacker_profit_assets: int
    victim_mark_to_market_assets: int
    victim_loss_assets: int
    virtual_assets: int
    virtual_shares: int
    search_bounds: dict[str, int]

    def to_dict(self) -> dict:
        return asdict(self)


def _candidate_scenarios(
    seed_max: int, donation_max: int, victim_max: int
) -> Iterator[tuple[int, int, int]]:
    for total_cost in range(1, seed_max + donation_max + 1):
        for seed in range(1, min(seed_max, total_cost) + 1):
            donation = total_cost - seed
            if donation > donation_max:
                continue
            for victim in range(1, victim_max + 1):
                yield seed, donation, victim


def find_donation_counterexample(
    *,
    seed_max: int,
    donation_max: int,
    victim_max: int,
    virtual_assets: int = 0,
    virtual_shares: int = 0,
    require_profit: bool = False,
) -> AttackCounterexample | None:
    """Find the lowest-cost bounded donation/rounding counterexample.

    This is an executable bounded search, not a universal safety proof. The
    exact search bounds are returned in the result.
    """

    bounds = {
        "seed_max": seed_max,
        "donation_max": donation_max,
        "victim_max": victim_max,
    }
    for seed, donation, victim in _candidate_scenarios(
        seed_max, donation_max, victim_max
    ):
        empty = VaultState(0, 0, virtual_assets, virtual_shares)
        attacker_deposit = empty.deposit(seed)
        donated = attacker_deposit.after.donate(donation)
        victim_shares = donated.after.preview_deposit(victim)

        # Unsafe vaults may accept a positive deposit that mints zero shares.
        after_victim = replace(
            donated.after,
            total_assets=donated.after.total_assets + victim,
            total_supply=donated.after.total_supply + victim_shares,
        )
        attacker_out = after_victim.preview_redeem(attacker_deposit.shares)
        attacker_profit = attacker_out - seed - donation
        victim_mark = after_victim.preview_redeem(victim_shares)
        victim_loss = victim - victim_mark

        exploitable = victim_shares == 0 or victim_loss > 0
        if exploitable and (not require_profit or attacker_profit > 0):
            return AttackCounterexample(
                seed,
                donation,
                victim,
                attacker_deposit.shares,
                victim_shares,
                attacker_out,
                attacker_profit,
                victim_mark,
                victim_loss,
                virtual_assets,
                virtual_shares,
                bounds,
            )
    return None


def exact_share_price(state: VaultState) -> Fraction:
    return Fraction(state.effective_assets, state.effective_supply)
