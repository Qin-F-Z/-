"""Generate a self-contained Foundry reproducer for a donation counterexample."""

from __future__ import annotations

from .model import AttackCounterexample


def donation_counterexample_test(
    counterexample: AttackCounterexample,
    *,
    contract_name: str = "UnsafeRawVault",
) -> str:
    c = counterexample
    return f"""// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.24;

import {{Test}} from "forge-std/Test.sol";
import {{{contract_name}}} from "../src/{contract_name}.sol";

contract QinCertDonationCounterexample is Test {{
    {contract_name} internal vault;
    address internal attacker = address(0xA77AC);
    address internal victim = address(0xBEEF);

    function setUp() external {{
        vault = new {contract_name}();
    }}

    function test_QinCert_counterexample() external {{
        uint256 attackerSeed = {c.seed_assets};
        uint256 attackerDonation = {c.donation_assets};
        uint256 victimDeposit = {c.victim_assets};

        vm.prank(attacker);
        uint256 attackerShares = vault.deposit(attackerSeed);
        vm.prank(attacker);
        vault.donate(attackerDonation);

        uint256 victimPreview = vault.previewDeposit(victimDeposit);
        assertEq(victimPreview, {c.victim_shares});
        vm.prank(victim);
        vault.deposit(victimDeposit);

        assertEq(attackerShares, {c.attacker_shares});
        // Expected attacker redeem value from the executable QinCert model:
        assertEq(vault.previewRedeem(attackerShares), {c.attacker_redeem_assets});
    }}
}}
"""
