"""Exact integer arithmetic with explicit rounding semantics.

SPDX-License-Identifier: LicenseRef-QinCert-Proprietary-Evaluation
"""

from __future__ import annotations

from enum import StrEnum
from math import isqrt

MAX_UINT256 = (1 << 256) - 1


class Rounding(StrEnum):
    """Rounding of an exact rational result.

    DOWN and UP mean mathematical floor and ceiling. They are intentionally
    different from TOWARD_ZERO and AWAY_FROM_ZERO for negative values.

    HALF_UP follows the common decimal convention: nearest integer, with exact
    half ties away from zero. HALF_EVEN uses the even integer on exact ties.
    """

    DOWN = "down"
    UP = "up"
    TOWARD_ZERO = "toward_zero"
    AWAY_FROM_ZERO = "away_from_zero"
    HALF_UP = "half_up"
    HALF_EVEN = "half_even"


def _require_denominator(denominator: int) -> None:
    if denominator <= 0:
        raise ZeroDivisionError("denominator must be strictly positive")


def mul_div(
    multiplicand: int,
    multiplier: int,
    denominator: int,
    rounding: Rounding | str = Rounding.DOWN,
) -> int:
    """Return `(multiplicand * multiplier) / denominator` rounded explicitly.

    Python's arbitrary-precision integer multiplication is used, so the
    mathematical product is exact. Use :func:`mul_div_u256` when EVM input and
    output bounds are part of the property.
    """

    _require_denominator(denominator)
    mode = Rounding(rounding)
    numerator = multiplicand * multiplier
    negative = numerator < 0
    magnitude = abs(numerator)
    quotient, remainder = divmod(magnitude, denominator)

    if remainder == 0:
        return -quotient if negative else quotient

    if mode is Rounding.TOWARD_ZERO:
        rounded_magnitude = quotient
    elif mode is Rounding.AWAY_FROM_ZERO:
        rounded_magnitude = quotient + 1
    elif mode is Rounding.DOWN:
        rounded_magnitude = quotient + (1 if negative else 0)
    elif mode is Rounding.UP:
        rounded_magnitude = quotient + (0 if negative else 1)
    else:
        doubled = remainder * 2
        if doubled < denominator:
            rounded_magnitude = quotient
        elif doubled > denominator:
            rounded_magnitude = quotient + 1
        elif mode is Rounding.HALF_UP:
            rounded_magnitude = quotient + 1
        else:
            rounded_magnitude = quotient if quotient % 2 == 0 else quotient + 1

    return -rounded_magnitude if negative else rounded_magnitude


def mul_div_u256(
    multiplicand: int,
    multiplier: int,
    denominator: int,
    rounding: Rounding | str = Rounding.DOWN,
) -> int:
    """EVM-compatible unsigned full-precision multiplication and division.

    Inputs and the rounded output must fit in uint256. The intermediate product
    is intentionally allowed to use 512 bits, matching full-precision EVM
    implementations.
    """

    for name, value in (
        ("multiplicand", multiplicand),
        ("multiplier", multiplier),
        ("denominator", denominator),
    ):
        if not 0 <= value <= MAX_UINT256:
            raise OverflowError(f"{name} is outside uint256")
    _require_denominator(denominator)
    result = mul_div(multiplicand, multiplier, denominator, rounding)
    if not 0 <= result <= MAX_UINT256:
        raise OverflowError("rounded result is outside uint256")
    return result


def sqrt_round(value: int, rounding: Rounding | str = Rounding.DOWN) -> int:
    """Return the integer square root with an explicit supported direction."""

    if value < 0:
        raise ValueError("square root requires a non-negative integer")
    mode = Rounding(rounding)
    lower = isqrt(value)
    if lower * lower == value:
        return lower

    if mode in (Rounding.DOWN, Rounding.TOWARD_ZERO):
        return lower
    if mode in (Rounding.UP, Rounding.AWAY_FROM_ZERO):
        return lower + 1

    upper = lower + 1
    lower_distance = value - lower * lower
    upper_distance = upper * upper - value
    if lower_distance < upper_distance:
        return lower
    if upper_distance < lower_distance:
        return upper
    if mode is Rounding.HALF_UP:
        return upper
    return lower if lower % 2 == 0 else upper
