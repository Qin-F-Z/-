"""Financial operations built only from explicit integer rounding."""

from __future__ import annotations

from .core import Rounding, mul_div_u256


def quote(
    amount: int,
    numerator: int,
    denominator: int,
    rounding: Rounding | str,
) -> int:
    return mul_div_u256(amount, numerator, denominator, rounding)


def fee_on_gross(
    gross_amount: int,
    fee_rate: int,
    fee_scale: int,
    rounding: Rounding | str = Rounding.UP,
) -> int:
    """Fee included in a gross amount: gross * rate / (scale + rate)."""

    return mul_div_u256(gross_amount, fee_rate, fee_scale + fee_rate, rounding)


def fee_on_net(
    net_amount: int,
    fee_rate: int,
    fee_scale: int,
    rounding: Rounding | str = Rounding.UP,
) -> int:
    """Fee added on top of a net amount: net * rate / scale."""

    return mul_div_u256(net_amount, fee_rate, fee_scale, rounding)


def accrue_index(
    principal: int,
    index_numerator: int,
    index_denominator: int,
    rounding: Rounding | str = Rounding.DOWN,
) -> int:
    """Apply a cumulative index without introducing an intermediate truncation."""

    return mul_div_u256(principal, index_numerator, index_denominator, rounding)
