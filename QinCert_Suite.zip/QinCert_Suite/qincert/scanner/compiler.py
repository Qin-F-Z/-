"""Pinned solc-js adapter used to obtain a Solidity compiler AST."""

from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path


class CompilerUnavailable(RuntimeError):
    pass


class SolidityParseError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class CompiledAst:
    compiler_version: str
    source_name: str
    diagnostics: list[dict]
    ast: dict


def compile_ast(source_path: Path, tooling_dir: Path | None = None) -> CompiledAst:
    source_path = source_path.resolve()
    tooling = tooling_dir or Path(__file__).resolve().parents[2] / "tooling"
    script = tooling / "solc_ast.mjs"
    node = shutil.which("node")
    if not node:
        raise CompilerUnavailable("Node.js is required for the pinned solc AST")
    if not (tooling / "node_modules" / "solc").exists():
        raise CompilerUnavailable(
            f"pinned solc is not installed; run npm ci in {tooling}"
        )

    process = subprocess.run(
        [node, str(script), str(source_path)],
        cwd=tooling,
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=60,
        check=False,
    )
    try:
        payload = json.loads(process.stdout)
    except json.JSONDecodeError as exc:
        raise SolidityParseError(
            f"solc adapter returned non-JSON output: {process.stderr.strip()}"
        ) from exc
    if process.returncode != 0 or not payload.get("ok"):
        messages = "\n".join(
            item.get("formattedMessage", item.get("message", ""))
            for item in payload.get("diagnostics", [])
        )
        raise SolidityParseError(messages or "Solidity parsing failed")
    return CompiledAst(
        payload["compilerVersion"],
        payload["sourceName"],
        payload.get("diagnostics", []),
        payload["ast"],
    )
