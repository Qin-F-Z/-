"""Finance-aware Solidity analysis over the compiler AST.

This implementation deliberately separates compiler facts from heuristic
financial-role inference. Every finding carries its confidence and evidence.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Iterator

from .compiler import compile_ast


ROLE_TERMS: dict[str, tuple[str, ...]] = {
    "asset": ("asset", "amount", "underlying", "deposit", "withdraw"),
    "share": ("share", "supply", "mint", "redeem"),
    "price": ("price", "rate", "ratio", "exchange", "index"),
    "fee": ("fee", "commission", "charge"),
    "debt": ("debt", "borrow", "loan", "liability"),
}

EXPECTED_ROUNDING = {
    "previewdeposit": "down",
    "deposit": "down",
    "converttoshares": "down",
    "previewmint": "up",
    "mint": "up",
    "previewwithdraw": "up",
    "withdraw": "up",
    "previewredeem": "down",
    "redeem": "down",
    "converttoassets": "down",
}


@dataclass(frozen=True, slots=True)
class SourceRange:
    start: int
    length: int
    line: int
    column: int


@dataclass(frozen=True, slots=True)
class AnalysisFinding:
    rule_id: str
    severity: str
    confidence: str
    title: str
    message: str
    contract: str
    function: str
    source: SourceRange
    evidence: tuple[str, ...] = ()
    assumptions: tuple[str, ...] = ()
    remediation: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class SemanticNode:
    node_id: str
    kind: str
    name: str
    roles: tuple[str, ...]
    unit: str
    confidence: str
    source: SourceRange


@dataclass(frozen=True, slots=True)
class SemanticEdge:
    source_node: str
    target_node: str
    relation: str


@dataclass(frozen=True, slots=True)
class RoundingAllocation:
    allocation_id: str
    function: str
    exact_expression: str
    actual_policy: str
    required_policy: str
    remainder_beneficiary: str
    remainder_cost_bearer: str
    roles: tuple[str, ...]
    source: SourceRange
    confidence: str


@dataclass(frozen=True, slots=True)
class SemanticGraph:
    contract: str
    nodes: tuple[SemanticNode, ...]
    edges: tuple[SemanticEdge, ...]
    allocations: tuple[RoundingAllocation, ...]

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ScanResult:
    source_path: str
    source_sha256: str
    compiler_version: str
    profile: str
    findings: tuple[AnalysisFinding, ...]
    semantic_graphs: tuple[SemanticGraph, ...] = ()
    diagnostics: tuple[dict, ...] = ()
    limitations: tuple[str, ...] = (
        "Financial role inference is heuristic unless confirmed by an adapter.",
        "Arbitrary inter-contract and delegatecall targets are not resolved.",
        "A clean result is not a complete security audit.",
    )

    def to_dict(self) -> dict:
        return {
            "source_path": self.source_path,
            "source_sha256": self.source_sha256,
            "compiler_version": self.compiler_version,
            "profile": self.profile,
            "findings": [item.to_dict() for item in self.findings],
            "semantic_graphs": [item.to_dict() for item in self.semantic_graphs],
            "diagnostics": list(self.diagnostics),
            "limitations": list(self.limitations),
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)

    def to_sarif(self) -> dict:
        rules: dict[str, dict] = {}
        results: list[dict] = []
        levels = {"critical": "error", "high": "error", "medium": "warning"}
        for finding in self.findings:
            rules.setdefault(
                finding.rule_id,
                {
                    "id": finding.rule_id,
                    "name": finding.title,
                    "shortDescription": {"text": finding.title},
                    "help": {"text": finding.remediation or finding.message},
                },
            )
            results.append(
                {
                    "ruleId": finding.rule_id,
                    "level": levels.get(finding.severity, "note"),
                    "message": {"text": finding.message},
                    "locations": [
                        {
                            "physicalLocation": {
                                "artifactLocation": {"uri": self.source_path},
                                "region": {
                                    "startLine": finding.source.line,
                                    "startColumn": finding.source.column,
                                },
                            }
                        }
                    ],
                    "properties": {
                        "confidence": finding.confidence,
                        "contract": finding.contract,
                        "function": finding.function,
                        "evidence": list(finding.evidence),
                        "assumptions": list(finding.assumptions),
                    },
                }
            )
        return {
            "version": "2.1.0",
            "$schema": (
                "https://json.schemastore.org/sarif-2.1.0.json"
            ),
            "runs": [
                {
                    "tool": {
                        "driver": {
                            "name": "QinCert",
                            "semanticVersion": "0.2.0",
                            "rules": list(rules.values()),
                        }
                    },
                    "results": results,
                }
            ],
        }


def walk(node: Any) -> Iterator[dict]:
    if isinstance(node, dict):
        if "nodeType" in node:
            yield node
        for value in node.values():
            yield from walk(value)
    elif isinstance(node, list):
        for value in node:
            yield from walk(value)


def children(node: dict) -> Iterator[dict]:
    for value in node.values():
        if isinstance(value, dict) and "nodeType" in value:
            yield value
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict) and "nodeType" in item:
                    yield item


def identifiers(node: dict) -> set[str]:
    names: set[str] = set()
    for item in walk(node):
        if item.get("nodeType") == "Identifier":
            names.add(str(item.get("name", "")))
        if item.get("nodeType") == "MemberAccess":
            names.add(str(item.get("memberName", "")))
    return {name for name in names if name}


def roles_for(names: Iterable[str]) -> set[str]:
    roles: set[str] = set()
    for name in names:
        lowered = name.lower()
        for role, terms in ROLE_TERMS.items():
            if any(term in lowered for term in terms):
                roles.add(role)
    return roles


class SourceIndex:
    def __init__(self, text: str):
        self.text = text
        self.raw = text.encode("utf-8")

    def range(self, src: str) -> SourceRange:
        start_text, length_text, *_ = src.split(":")
        start, length = int(start_text), int(length_text)
        prefix = self.raw[:start]
        line = prefix.count(b"\n") + 1
        line_start = prefix.rfind(b"\n") + 1
        column = len(prefix[line_start:].decode("utf-8", errors="replace")) + 1
        return SourceRange(start, length, line, column)

    def slice(self, src: str) -> str:
        start, length, *_ = (int(part) for part in src.split(":"))
        return self.raw[start : start + length].decode("utf-8", errors="replace")


def _base_name(item: dict) -> str:
    base = item.get("baseName", {})
    return str(base.get("namePath") or base.get("name") or "")


def _call_name(node: dict) -> str:
    expression = node.get("expression", {})
    if expression.get("nodeType") == "MemberAccess":
        return str(expression.get("memberName", ""))
    if expression.get("nodeType") == "Identifier":
        return str(expression.get("name", ""))
    return ""


class SolidityAnalyzer:
    def scan(self, source_path: str | Path) -> ScanResult:
        path = Path(source_path).resolve()
        text = path.read_text(encoding="utf-8")
        index = SourceIndex(text)
        compiled = compile_ast(path)
        findings: list[AnalysisFinding] = []
        graphs: list[SemanticGraph] = []

        contracts = [
            item for item in walk(compiled.ast)
            if item.get("nodeType") == "ContractDefinition"
        ]
        for contract in contracts:
            graphs.append(self._build_semantic_graph(contract, index))
            findings.extend(self._analyze_contract(contract, index))

        findings.sort(
            key=lambda finding: (
                finding.source.line,
                finding.source.column,
                finding.rule_id,
            )
        )
        profile = (
            "erc4626"
            if any(self._is_erc4626(contract) for contract in contracts)
            else "generic"
        )
        return ScanResult(
            source_path=str(path),
            source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            compiler_version=compiled.compiler_version,
            profile=profile,
            findings=tuple(findings),
            semantic_graphs=tuple(graphs),
            diagnostics=tuple(compiled.diagnostics),
        )

    def _build_semantic_graph(
        self, contract: dict, index: SourceIndex
    ) -> SemanticGraph:
        contract_name = str(contract.get("name", "<anonymous>"))
        semantic_nodes: dict[str, SemanticNode] = {}
        edges: list[SemanticEdge] = []
        allocations: list[RoundingAllocation] = []

        def stable_id(kind: str, function_name: str, src: str, name: str) -> str:
            material = f"{contract_name}|{function_name}|{kind}|{src}|{name}"
            return hashlib.sha256(material.encode("utf-8")).hexdigest()[:24]

        for function in contract.get("nodes", []):
            if function.get("nodeType") != "FunctionDefinition":
                continue
            function_name = str(
                function.get("name") or function.get("kind") or "<anonymous>"
            )
            expected = EXPECTED_ROUNDING.get(function_name.lower(), "not-profiled")
            name_to_ids: dict[str, list[str]] = {}

            for node in walk(function):
                if node.get("nodeType") != "VariableDeclaration":
                    continue
                name = str(node.get("name", ""))
                if not name:
                    continue
                node_roles = tuple(sorted(roles_for([name])))
                unit = (
                    node_roles[0]
                    if len(node_roles) == 1 and node_roles[0] in {"asset", "share"}
                    else "unknown"
                )
                node_id = stable_id("variable", function_name, node["src"], name)
                semantic_nodes[node_id] = SemanticNode(
                    node_id,
                    "variable",
                    name,
                    node_roles,
                    unit,
                    "heuristic" if node_roles else "unclassified",
                    index.range(node["src"]),
                )
                name_to_ids.setdefault(name, []).append(node_id)

            for node in walk(function.get("body", {})):
                if node.get("nodeType") == "Assignment":
                    left_names = identifiers(node.get("leftHandSide", {}))
                    right_names = identifiers(node.get("rightHandSide", {}))
                    for right in right_names:
                        for left in left_names:
                            for right_id in name_to_ids.get(right, []):
                                for left_id in name_to_ids.get(left, []):
                                    edges.append(
                                        SemanticEdge(right_id, left_id, "assignment")
                                    )

                if node.get("nodeType") != "BinaryOperation":
                    continue
                operator = str(node.get("operator", ""))
                expression = index.slice(node["src"]).strip()
                input_names = identifiers(node)
                node_roles = tuple(sorted(roles_for(input_names)))
                operation_id = stable_id(
                    "operation", function_name, node["src"], expression
                )
                semantic_nodes[operation_id] = SemanticNode(
                    operation_id,
                    f"binary:{operator}",
                    expression,
                    node_roles,
                    "derived",
                    "compiler-ast+heuristic-role",
                    index.range(node["src"]),
                )
                for input_name in input_names:
                    for source_id in name_to_ids.get(input_name, []):
                        edges.append(
                            SemanticEdge(source_id, operation_id, "operand")
                        )

                if operator == "/" and node_roles:
                    if expected == "up":
                        beneficiary, bearer = "caller", "vault_or_protocol"
                    elif expected == "down":
                        beneficiary, bearer = "vault_or_protocol", "caller"
                    else:
                        beneficiary, bearer = "unresolved", "unresolved"
                    allocations.append(
                        RoundingAllocation(
                            stable_id(
                                "rounding-allocation",
                                function_name,
                                node["src"],
                                expression,
                            ),
                            function_name,
                            expression,
                            "raw-solidity-division",
                            expected,
                            beneficiary,
                            bearer,
                            node_roles,
                            index.range(node["src"]),
                            (
                                "high"
                                if expected in {"up", "down"}
                                else "medium"
                            ),
                        )
                    )
        return SemanticGraph(
            contract_name,
            tuple(semantic_nodes.values()),
            tuple(edges),
            tuple(allocations),
        )

    def _is_erc4626(self, contract: dict) -> bool:
        bases = {_base_name(item).lower() for item in contract.get("baseContracts", [])}
        functions = {
            str(item.get("name", "")).lower()
            for item in contract.get("nodes", [])
            if item.get("nodeType") == "FunctionDefinition"
        }
        previews = {
            "previewdeposit", "previewmint", "previewwithdraw", "previewredeem"
        }
        return any("erc4626" in base for base in bases) or len(functions & previews) >= 3

    def _analyze_contract(
        self, contract: dict, index: SourceIndex
    ) -> list[AnalysisFinding]:
        contract_name = str(contract.get("name", "<anonymous>"))
        erc4626 = self._is_erc4626(contract)
        output: list[AnalysisFinding] = []
        contract_names = identifiers(contract)
        has_virtual = any("virtual" in name.lower() for name in contract_names)
        if erc4626 and not has_virtual:
            output.append(
                AnalysisFinding(
                    "QIN4626-003",
                    "medium",
                    "medium",
                    "No compiler-visible virtual offset",
                    (
                        "No identifier or state component named as a virtual asset/share "
                        "offset was found. Confirm whether the inherited implementation "
                        "provides an equivalent defense."
                    ),
                    contract_name,
                    "",
                    index.range(contract["src"]),
                    tuple(sorted(contract_names))[:12],
                    ("Inherited library behavior is not resolved by this rule.",),
                    "Use or prove an equivalent virtual liquidity/precision defense.",
                )
            )

        for function in contract.get("nodes", []):
            if function.get("nodeType") != "FunctionDefinition":
                continue
            output.extend(
                self._analyze_function(contract_name, function, index, erc4626)
            )
        return output

    def _analyze_function(
        self,
        contract_name: str,
        function: dict,
        index: SourceIndex,
        erc4626: bool,
    ) -> list[AnalysisFinding]:
        name = str(function.get("name") or function.get("kind") or "<anonymous>")
        expected = EXPECTED_ROUNDING.get(name.lower())
        body = function.get("body")
        if not body:
            return []
        output: list[AnalysisFinding] = []

        for node in walk(body):
            if node.get("nodeType") == "BinaryOperation" and node.get("operator") == "/":
                names = identifiers(node)
                roles = roles_for(names)
                if not roles:
                    continue
                severity = "medium"
                message = (
                    "Compiler AST contains a financial-value division. Solidity division "
                    "is deterministic, but the economic allocation of the remainder is "
                    "not expressed as a named policy."
                )
                if erc4626 and expected == "up":
                    severity = "high"
                    message = (
                        f"{name} requires an upward economic rounding policy, while raw "
                        "unsigned division rounds down. This may undercharge the caller."
                    )
                if expected == "up":
                    allocation = (
                        "raw floor benefits the caller; the vault/protocol bears "
                        "the discarded remainder"
                    )
                elif expected == "down":
                    allocation = (
                        "raw floor benefits the vault/protocol; the caller bears "
                        "the discarded remainder"
                    )
                else:
                    allocation = "economic beneficiary unresolved"
                output.append(
                    AnalysisFinding(
                        "QIN-MATH-001",
                        severity,
                        "high" if erc4626 else "medium",
                        "Financial division without explicit policy",
                        message,
                        contract_name,
                        name,
                        index.range(node["src"]),
                        (
                            f"roles={','.join(sorted(roles))}",
                            f"identifiers={','.join(sorted(names))}",
                            f"expression={index.slice(node['src']).strip()}",
                            f"rounding_allocation={allocation}",
                        ),
                        (
                            "Role labels are inferred from identifiers.",
                            f"expected_rounding={expected or 'not-profiled'}",
                        ),
                        "Use a full-precision operation with an explicit, reviewed rounding mode.",
                    )
                )

            if node.get("nodeType") == "FunctionCall" and _call_name(node) == "mulDiv":
                arguments = node.get("arguments", [])
                rounding = (
                    index.slice(arguments[-1]["src"]).strip()
                    if len(arguments) >= 4
                    else "implicit-default"
                )
                normalized = rounding.lower()
                if expected and not any(
                    token in normalized for token in (expected, expected.capitalize())
                ):
                    output.append(
                        AnalysisFinding(
                            "QIN4626-002",
                            "high",
                            "high",
                            "Rounding policy conflicts with ERC-4626 role",
                            (
                                f"{name} is expected to round {expected}, but the "
                                f"compiler-visible call uses `{rounding}`."
                            ),
                            contract_name,
                            name,
                            index.range(node["src"]),
                            (f"rounding_argument={rounding}",),
                            (),
                            f"Use a proven `{expected}` policy for this conversion.",
                        )
                    )

        if erc4626 and name.lower() == "deposit" and not self._has_zero_share_guard(body):
            output.append(
                AnalysisFinding(
                    "QIN4626-001",
                    "high",
                    "medium",
                    "No AST-visible zero-share guard",
                    (
                        "The deposit body does not contain an AST-visible comparison "
                        "between a share value and zero. Confirm inherited guards and "
                        "reject positive deposits that mint zero shares."
                    ),
                    contract_name,
                    name,
                    index.range(function["src"]),
                    (),
                    ("Interprocedural and inherited guards are not resolved.",),
                    "Require a positive minted share amount or a caller-provided minimum.",
                )
            )
        return output

    @staticmethod
    def _has_zero_share_guard(body: dict) -> bool:
        for node in walk(body):
            if node.get("nodeType") != "BinaryOperation":
                continue
            if node.get("operator") not in ("==", "<=", "<", ">=", ">"):
                continue
            names = identifiers(node)
            literals = {
                str(item.get("value", ""))
                for item in walk(node)
                if item.get("nodeType") == "Literal"
            }
            if "0" in literals and "share" in " ".join(names).lower():
                return True
        return False
