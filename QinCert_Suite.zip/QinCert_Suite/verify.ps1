$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $root

$venvPython = Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $venvPython)) {
    py -3.12 -m venv .venv
}

& $venvPython -m pip install --disable-pip-version-check "pip==25.0.1"
& $venvPython -m pip install --disable-pip-version-check -c requirements-constraints.txt -e ".[proof,test]"
npm ci --prefix tooling --no-audit --no-fund
& $venvPython scripts/verify_all.py
