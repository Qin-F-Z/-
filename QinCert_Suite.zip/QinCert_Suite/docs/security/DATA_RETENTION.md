# Customer data retention policy design

## Default principles

- collect only code and metadata needed for the requested analysis;
- do not train shared models on customer code without a separate explicit opt-in;
- encrypt in transit and at rest;
- segregate tenants;
- make retention visible and configurable;
- record deletion and legal-hold events.

## Suggested tiers

| Tier | Source retention | Evidence retention | Use case |
|---|---:|---:|---|
| Ephemeral | deleted after job completion | customer-selected | highly confidential review |
| Standard | 7 days | contract term + legal policy | normal CI |
| Continuous | latest and required diffs | subscription term | monitoring |
| Customer-managed | customer storage only | customer-controlled | VPC/on-premises |

Logs must avoid source fragments and secrets. Backups follow the same deletion
and access policy, with documented maximum purge latency.

## Customer controls

- project deletion;
- repository disconnect;
- artifact export;
- retention-tier selection;
- list of active repository permissions;
- audit-log export;
- breach and subprocessor notices.
