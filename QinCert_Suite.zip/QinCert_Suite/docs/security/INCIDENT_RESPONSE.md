# Incident response outline

## Severity

- SEV-1: signing-key compromise, cross-tenant access, active source exfiltration,
  or materially false valid attestation;
- SEV-2: single-tenant exposure, major false-negative family, revocation outage;
- SEV-3: limited service failure without confirmed confidentiality/integrity loss.

## First hour

1. appoint incident commander and recorder;
2. stop affected signing or ingestion path;
3. preserve logs and evidence;
4. rotate or disable credentials where justified;
5. identify affected tenants, evidence IDs and deployments;
6. publish internal facts, uncertainties and next update time.

## Evidence incident

- revoke affected key or bundle;
- mark descendants and dependent attestations;
- publish signed revocation statement;
- notify affected customers with exact scope;
- issue corrected result only after root cause and rerun;
- preserve old bundle for audit but prevent “valid” display.

## Recovery

- restore from known-good artifacts;
- verify tenant isolation and hashes;
- complete causal analysis and corrective actions;
- update threat model, test corpus and release gate;
- obtain legal/contract review for notifications.
