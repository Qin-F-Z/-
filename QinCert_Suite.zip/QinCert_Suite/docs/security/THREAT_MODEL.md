# QinCert threat model

## Protected assets

- customer source code and dependencies;
- analysis findings and unpublished vulnerabilities;
- signing and revocation keys;
- evidence integrity;
- tenant identity and authorization;
- billing and audit records;
- private benchmark labels and patent material.

## Trust boundaries

1. customer to upload/repository connector;
2. control plane to untrusted compiler/analyzer workers;
3. worker to artifact store;
4. reviewer to signing service;
5. public verifier to transparency/status service;
6. managed service to customer VPC or on-premises deployment.

## Priority threats and controls

| Threat | Example | Required control |
|---|---|---|
| Malicious source | compiler exploit, zip bomb, path traversal | isolated ephemeral worker, size limits, canonical paths, no host mounts |
| Resource exhaustion | solver path explosion | CPU/memory/time quotas, job cancellation, bounded queues |
| Data exfiltration | worker sends source outbound | default-deny egress, per-job credentials, network audit |
| Tenant escape | object ID or storage-key confusion | tenant-scoped authorization in service and database |
| Evidence forgery | stolen signing key | KMS/HSM, dual control, key rotation, transparency and revocation |
| Evidence replay | old valid report used after upgrade | bytecode/commit binding, expiry, deployment monitoring |
| Dependency compromise | malicious compiler/package | pinned hashes, SBOM, allowlist, signed build provenance |
| Reviewer abuse | unauthorized attestation | RBAC, separation of duties, immutable audit log |
| Result suppression | failed file silently omitted | fail-closed job status and complete input manifest |
| Prompt/report injection | source comments manipulate generated narrative | data/instruction separation and fixed report templates |

## Abuse cases

- customer attempts to obtain a clean certificate by excluding a contract;
- attacker supplies code designed to crash or hang solver workers;
- insider signs a report without required evidence;
- user presents T0/T1 output as independent T3 certification;
- proxy implementation changes while front-end continues showing old badge;
- revocation service is unavailable during a material incident.

## Security acceptance criteria

- every job has a complete input manifest;
- workers cannot reach unrelated tenant data;
- signatures cannot be produced from worker credentials;
- all status changes are append-only audited;
- verification works offline for integrity and online for status;
- incident playbook can revoke a key and all affected evidence.
