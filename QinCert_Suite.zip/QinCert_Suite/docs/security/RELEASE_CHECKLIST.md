# Security and release checklist

## Source and dependency

- [ ] exact version and source-tree hash recorded;
- [ ] SPDX and third-party notices reviewed;
- [ ] SBOM generated;
- [ ] no secrets, customer data or private patent material in release;
- [ ] dependency vulnerabilities triaged;
- [ ] reproducible build attempted in a clean environment.

## Analysis engine

- [ ] unit, property, adversarial and negative-control tests pass;
- [ ] solver UNKNOWN/TIMEOUT paths fail closed;
- [ ] parser errors and missing imports are visible;
- [ ] benchmark dataset and labels are frozen;
- [ ] accuracy and timeout deltas reviewed.

## Evidence

- [ ] payload and artifact hashes verify;
- [ ] correct signer and trust tier displayed;
- [ ] expiry and revocation tested;
- [ ] scope, assumptions and exclusions are explicit;
- [ ] old evidence becomes superseded after material change.

## SaaS

- [ ] tenant isolation tests pass;
- [ ] RBAC and token expiry tested;
- [ ] upload limits and path traversal tested;
- [ ] worker egress and resource quotas enforced;
- [ ] backups and restore tested;
- [ ] monitoring and incident contacts active.

## Human approval

- [ ] engineering release owner;
- [ ] security owner;
- [ ] IP/open-source owner;
- [ ] attestation reviewer, if applicable;
- [ ] commercial wording owner.
