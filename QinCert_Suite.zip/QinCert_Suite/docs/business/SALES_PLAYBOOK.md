# Sales and design-partner playbook

## Qualification

Ask:

1. How many financial contracts do you review or operate per quarter?
2. Which arithmetic issues consume the most reviewer time?
3. Do you use ERC-4626, custom shares, fees, rebasing or low-decimal assets?
4. What evidence is required by governance, customers or insurers?
5. How do you know an audit still applies after an upgrade?
6. What false-positive rate makes a tool unusable?
7. Can a scoped reproducer be run in your existing test framework?
8. Is private SaaS, VPC or offline processing required?

## Pilot design

- use 3-5 already reviewed projects so ground truth exists;
- blind QinCert to the prior audit findings initially;
- agree exact property scope before analysis;
- measure precision, new material findings and reviewer time;
- separate engine defects from label disagreements;
- obtain permission before using any result externally.

## Demo sequence

1. show the unsafe source;
2. show the precise value-allocation problem;
3. replay the minimal attack;
4. apply the fix;
5. rerun the property;
6. verify the evidence hash;
7. change the code and show the evidence become stale.

Avoid beginning with dashboards, certificates or generic security claims.

## Exit criteria for a paid pilot

- customer confirms at least one high-value workflow;
- reviewer can reproduce evidence without QinCert staff;
- private-code handling meets procurement needs;
- success metric and commercial conversion date are written;
- responsibility and exclusions are accepted.

## CRM stages

1. ICP confirmed;
2. technical pain confirmed;
3. reproducible dataset available;
4. pilot scope signed;
5. pilot running;
6. evidence reviewed;
7. commercial proposal;
8. security/legal review;
9. won/lost with reason.
