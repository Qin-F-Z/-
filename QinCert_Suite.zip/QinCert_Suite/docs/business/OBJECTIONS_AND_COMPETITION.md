# Objections and competitive positioning

## “OpenZeppelin already solves ERC-4626 rounding.”

Correct: the standard and OpenZeppelin provide important known defenses.
QinCert does not claim to invent those defenses. It verifies whether a specific
implementation, fee model, dependency graph and deployed bytecode preserve the
required economic properties, and it makes stale evidence visible after change.

## “Slither already scans Solidity.”

Slither is a strong general static-analysis platform and a likely integration
or comparison point. QinCert specializes in financial roles, units, economic
remainder allocation, transaction-level counterexamples and evidence validity.
Where Slither provides correct compiler facts, QinCert should reuse or
interoperate rather than duplicate without reason.

## “Formal verification tools already exist.”

They do. QinCert's proposed value is property generation and evidence workflow
for financial arithmetic, not inventing SMT. For high-assurance projects,
QinCert may orchestrate Certora, Halmos, Foundry or other engines.

## “Is this a complete audit?”

No. It is an arithmetic-specialist assurance layer. Access control, oracle,
governance, economic design and integration risks outside the selected scope
remain excluded unless explicitly assessed.

## “Can you guarantee no exploit?”

No credible tool can guarantee the absence of all exploits. QinCert states
exactly which property was proved or tested, under which assumptions and for
which code.

## “Why should we trust your certificate?”

For preliminary output, do not rely on reputation alone: verify the source
hash, toolchain, checks and signature. Higher tiers add reviewer and independent
partner signatures. Revocation and supersession remain visible.

## Positioning matrix

| Alternative | Breadth | Economic arithmetic depth | Counterexample/proof | Evidence lifecycle |
|---|---|---|---|---|
| General linter | broad | low-medium | limited | usually build-level |
| Manual audit | broad | reviewer-dependent | case-dependent | PDF often becomes stale |
| Formal verification platform | property-dependent | potentially high | high | project-specific |
| QinCert target | narrow initially | high | built into workflow | commit/bytecode/status bound |

QinCert should partner with, not dismiss, auditors and formal tools.
