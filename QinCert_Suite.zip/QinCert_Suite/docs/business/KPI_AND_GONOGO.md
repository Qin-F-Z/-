# KPI and go/no-go scorecard

## Technical gate

| Metric | Go | Hold | Stop/narrow |
|---|---:|---:|---:|
| High-severity precision | >=90% | 75-89% | <75% |
| Confirmed property-family recall | >=80% | 60-79% | <60% |
| Findings with reproducer/proof | >=90% | 70-89% | <70% |
| Median reviewer reproduction | <=30 min | 31-90 min | >90 min |
| Deterministic clean rerun | 100% | intermittent | materially nondeterministic |

## Commercial gate

| Metric by day 90 | Go | Hold | Stop/narrow |
|---|---:|---:|---:|
| Qualified interviews | >=15 | 8-14 | <8 |
| Design partners | >=2 | 1 | 0 |
| Paid pilots | >=1 | strong written intent | 0 and no intent |
| Audit/OEM pipeline | >=2 partners | 1 | 0 |

## IP gate

- contribution and assignment complete;
- professional search identifies a defensible technical delta;
- implementation supports the disclosure;
- filing occurs before broader public release;
- open-source boundary approved.

Failure of the patent gate does not automatically kill the product. It shifts
the moat toward proprietary data, evidence workflow, distribution and trade
secrets.
