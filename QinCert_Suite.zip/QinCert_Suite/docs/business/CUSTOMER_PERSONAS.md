# Customer personas and priority

## P1 - Smart-contract audit firm

Pain:

- repeated manual arithmetic review;
- inconsistent evidence between auditors;
- pressure to deliver faster without lowering quality.

Buying trigger:

- active ERC-4626/RWA pipeline;
- desire to add formal or reproducible evidence;
- need for white-label tooling.

Decision criteria:

- high-severity precision;
- review time;
- private deployment;
- responsibility boundary;
- evidence suitable for client report.

Offer:

OEM pilot on 3-5 completed audits, with blind comparison against prior findings.

## P2 - Vault/RWA/stablecoin protocol

Pain:

- donation, fee and decimals edge cases;
- upgrades invalidate old audit assumptions;
- governance needs concrete evidence.

Buying trigger:

- pre-mainnet launch;
- major upgrade;
- exchange/custodian due diligence;
- incident or audit finding.

Offer:

scoped arithmetic verification plus continuous monitoring.

## P3 - Risk, insurance, exchange or custodian

Pain:

- audit PDFs become stale;
- difficult to compare coverage and assumptions;
- deployed bytecode may not match reviewed source.

Buying trigger:

- underwriting or listing decision;
- requirement for upgrade monitoring;
- portfolio-wide control.

Offer:

evidence verification/status API and portfolio monitoring. This segment follows
technical validation; it is not the first product-design authority unless it
owns relevant contract risk.

## Deprioritized initially

- individual developers seeking only free scans;
- general Web3 security without financial arithmetic need;
- buyers requesting an absolute guarantee;
- projects unable to provide reproducible build inputs.
