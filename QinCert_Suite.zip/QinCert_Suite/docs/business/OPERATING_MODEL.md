# 90-day and 12-month operating model

All numbers are planning assumptions in USD and exclude founder opportunity
cost unless stated.

## 90-day base case

| Category | Budget assumption |
|---|---:|
| Patent search, drafting and initial filings | 15,000-35,000 |
| Independent smart-contract review | 10,000-25,000 |
| Cloud, CI, domains and security tooling | 2,000-6,000 |
| Brand, legal templates and sales operations | 3,000-10,000 |
| Contingency | 5,000-12,000 |
| Total external cash | 35,000-88,000 |

Internal engineering is the largest cost if market-rate salaries are included.

## 12-month scenarios

| Scenario | Team shape | External + payroll assumption | Revenue gate |
|---|---|---:|---|
| Lean | 2 technical founders + fractional legal/audit | 250,000-400,000 | 3 paying customers or 1 OEM by month 6 |
| Base | 4 engineers + security lead + commercial founder | 600,000-900,000 | US$300k contracted ARR by month 12 |
| Expansion | 7-10 staff + US/HK commercialization | 1.2m-2.0m | US$1m qualified ARR path |

Do not hire to the expansion case before benchmark accuracy and partner pull
are demonstrated.

## Unit-economics targets

- software gross margin >80%;
- scoped verification gross margin >55%;
- review hours per attestation decline with reusable evidence;
- customer acquisition payback <12 months;
- annual contract value grows through continuous monitoring, not liability
  inflation.

## 90-day release gates

- one command reproduces all required checks;
- 30 license-reviewed real projects;
- high-severity precision target >=90%;
- two independent reviewers can replay evidence;
- one paid pilot;
- IP ownership resolved and first application filed;
- no formal `QinCert Attested` sale before signing controls and review SOP.

## Stop or narrow conditions

- audit partners do not value the evidence over existing workflow;
- severe findings cannot maintain acceptable precision;
- source handling cannot meet procurement requirements;
- claimed patent delta collapses under search;
- every sale depends on unlimited liability or manual founder work.
