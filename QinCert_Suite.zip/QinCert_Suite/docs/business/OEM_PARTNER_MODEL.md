# Audit-firm OEM and co-attestation model

## Integration options

### Tool-only

Partner uses QinCert internally and owns final client judgment.

### White-label evidence

QinCert machine evidence is embedded in the partner report; signer and coverage
remain technically visible.

### Co-attestation

QinCert signs machine evidence and partner signs human review. Scope, liability
and revocation duties are shared by explicit agreement.

### Dedicated deployment

Analysis runs in a partner-controlled environment; QinCert supplies signed
releases, rules and support.

## Commercial terms to define

- annual platform fee, usage and reviewer seats;
- minimum volume and overage;
- support response and release policy;
- ownership of partner-specific rules;
- anonymized quality telemetry opt-in;
- client-facing naming and logo;
- incident, correction and revocation responsibility;
- professional liability and indemnity;
- termination, evidence continuity and data deletion.

## Non-negotiable integrity rules

- partner cannot remove failed checks while retaining a QinCert pass mark;
- trust tier and signer remain machine-readable;
- white-label presentation cannot conceal scope or expiry;
- evidence cannot be reused for different source/bytecode;
- both parties can trigger emergency revocation under defined conditions.
