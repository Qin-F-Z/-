# QinCert commercial product brief

## Category

Financial arithmetic assurance for smart contracts.

## Initial wedge

ERC-4626 vault conversions, donation/inflation behavior, fees, decimals and
round-trip value loss.

## Job to be done

When a protocol or auditor reviews a financial contract, they need to determine
not only whether integer operations are syntactically valid, but whether
rounding transfers value to the wrong party under realistic state and
transaction sequences. They also need evidence that remains tied to the exact
code and becomes stale after change.

## Product loop

1. Connect or upload an exact source version;
2. normalize compiler and dependencies;
3. infer financial roles and units;
4. produce findings, counterexamples and proof obligations;
5. review assumptions and exclusions;
6. issue machine-verifiable evidence at the appropriate trust tier;
7. monitor code, dependency and deployment changes.

## Product tiers

| Product | User outcome | Assurance |
|---|---|---|
| QinScan Preliminary | prioritize arithmetic risks | automated heuristic |
| QinProof Verified | reproduce tests/proofs for exact commit | automated evidence |
| QinCert Attested | share a reviewed scoped result | human + machine signature |
| QinMonitor Continuous | detect and reverify material changes | ongoing |

## Explicit non-goals

- full audit replacement;
- oracle, governance, access-control and bridge assurance outside selected rules;
- unconditional safety statement;
- automatic certification when analysis is incomplete;
- custody of production private keys or customer funds.

## Expansion

After ERC-4626 quality gates:

1. stablecoin mint/redeem and collateral ratios;
2. RWA NAV, fees and share accounting;
3. lending interest indexes and debt rounding;
4. staking rewards and cumulative reward-per-token;
5. exchange and settlement amount conversion.
