# Service catalog and pricing experiments

Prices are negotiation hypotheses, not market facts. Validate through at least
10 audit-firm and protocol interviews.

## QinScan Preliminary

Scope:

- public repository or submitted source;
- compiler-AST findings;
- SARIF/JSON and concise report;
- no attestation.

Price:

- public repository: free;
- private team CI: US$499-1,500/month.

## QinProof Verified

Scope:

- exact commit and compiler inputs;
- counterexample/property package;
- evidence bundle;
- one technical review call;
- clearly bounded claim.

Price:

- US$5,000-15,000 per scoped project.

Acceptance:

- every high finding has source evidence and reproducer or explicit limitation;
- evidence validates against delivered artifacts;
- failed/unknown checks are visible.

## QinCert Attested

Scope:

- QinProof deliverables;
- named reviewer and checklist;
- organizational signature and validity interval;
- revocation/status endpoint;
- one correction cycle.

Price:

- US$15,000-40,000 depending on complexity and responsibility.

This tier is not offered until reviewer process, signing-key controls and
professional liability terms are operational.

## QinMonitor Continuous

Scope:

- repository/deployment change detection;
- impact and stale-evidence notification;
- scheduled and event-driven reverification;
- portfolio status.

Price:

- US$1,000-5,000/month per organization plus usage.

## Audit-firm OEM

Scope:

- private tenant or dedicated deployment;
- white-label report components;
- reviewer seats;
- volume allowance;
- integration support.

Price:

- US$30,000-100,000/year plus high-volume or co-attestation fees.

## Discount rules

- discount only for reference rights, committed volume, prepayment or structured
  product feedback;
- free pilots require exact feedback obligations and case-study decision date;
- never discount by weakening scope, evidence or liability language invisibly.
