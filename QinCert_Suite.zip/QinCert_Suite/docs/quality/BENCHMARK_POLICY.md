# Benchmark and labeling policy

## Dataset layers

1. **Adversarial fixtures**: synthetic cases for deterministic rule regression;
2. **Public corpus**: license-reviewed pinned open-source projects;
3. **Private corpus**: customer or partner cases under contract;
4. **Frozen holdout**: inaccessible to rule authors until release evaluation.

## Label requirements

No item is labeled “vulnerable” without:

- exact commit and compiler configuration;
- human-readable technical rationale;
- executable reproducer or formal counterexample;
- affected function and state assumptions;
- reviewer identity and date.

No item is labeled “safe” in an absolute sense. The safe label means only that
the defined arithmetic properties passed within the recorded scope.

Disputed and unknown cases are reported separately and excluded from headline
precision/recall denominators.

## Leakage controls

- split by repository family, not individual files;
- forks and near-duplicates stay in one split;
- rule authors cannot tune against the holdout;
- public examples do not appear in the private validation split;
- every release records dataset hash and label version.

## Release gates

- all adversarial fixtures pass;
- no regression in previously confirmed high findings;
- high-severity precision target >= 90% with confidence interval;
- recall reported by property family;
- false negatives receive root-cause analysis;
- benchmark changes reviewed separately from engine changes.
