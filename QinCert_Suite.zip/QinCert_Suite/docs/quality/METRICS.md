# Quality and operating metrics

## Accuracy

- precision = TP / (TP + FP);
- recall = TP / (TP + FN);
- false-positive rate by rule and project;
- false-negative count by property family;
- disputed/unknown rate;
- 95% confidence intervals, not only point estimates.

## Evidence usability

- median reviewer time per high finding;
- percentage of findings with executable reproducer;
- percentage of proofs independently reproduced;
- evidence verification failure rate;
- stale/superseded certificate detection time.

## Performance

- median and p95 compile, scan, counterexample and proof duration;
- timeout rate;
- memory/CPU per thousand lines;
- cache hit rate;
- incremental verification speedup.

## Commercial

- design-partner activation;
- scan-to-review conversion;
- review-to-paid conversion;
- annual recurring revenue;
- gross margin by service tier;
- time to first verified result;
- renewal and expansion;
- audit-partner sourced pipeline.

Metrics must be segmented by public/private repository, contract complexity and
assurance tier. Aggregate numbers alone can hide weak performance.
