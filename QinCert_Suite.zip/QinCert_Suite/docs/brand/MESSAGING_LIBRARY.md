# QinCert messaging library

## Homepage headline

**Prove the arithmetic behind on-chain finance.**

Support:

QinCert finds where integer rounding changes who receives value, generates a
replayable counterexample or scoped proof, and binds the result to the exact
source and bytecode.

## Chinese headline

**证明链上金融背后的每一次算术。**

QinCert 识别整数舍入如何改变价值归属，生成可重放反例或有边界的证明，并将结果绑定到确切源码与字节码。

## 30-second explanation

Most scanners can tell you that a contract divides two numbers. QinCert asks a
harder question: who gains the remainder, under which state and transaction
sequence, and can that conclusion be independently reproduced? It begins with
ERC-4626 vault arithmetic and extends to fees, rates, debt and RWA accounting.

## By audience

### Protocol engineering

Catch rounding and precision failures before deployment and on every material
change. Receive a Foundry-ready reproducer, exact evidence path and fix
direction.

### Audit firms

Add a repeatable arithmetic workbench to each audit without replacing reviewer
judgment. White-label evidence or co-attest scoped results.

### Risk, governance and insurance

Evaluate the exact deployed bytecode and know when prior evidence has expired
or been invalidated by an upgrade.

## Claim-safe language

Use:

- “No counterexample found within the recorded bounds”;
- “Property proved under the listed assumptions”;
- “Automated evidence, not independently attested”;
- “Arithmetic specialist assessment; full audit excluded”.

Avoid:

- “Guaranteed safe”;
- “Unhackable”;
- “Official certification” without defined authority;
- “All theorems proved” without named properties and solver records;
- “World-first” or “patented” before factual confirmation.
