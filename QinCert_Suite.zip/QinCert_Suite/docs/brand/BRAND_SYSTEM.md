# QinCert brand system

## Brand architecture

**Master brand:** QinCert  
**Descriptor:** Financial Arithmetic Assurance  
**Chinese descriptor:** 金融算术保证平台

Product names:

- **QinScan Preliminary** - compiler-AST risk analysis;
- **QinProof Verified** - reproducible automated proof package;
- **QinCert Attested** - reviewed and signed scoped attestation;
- **QinMonitor Continuous** - change detection and continuous re-verification.

`VaultGuard` is not the master brand. It may be retained only as an internal
ERC-4626 policy-profile codename until trademark review is complete.

## Pronunciation

- English working pronunciation: “chin-cert”;
- Chinese: “秦证”仅作口头简称，正式材料使用 QinCert；
- every first introduction pairs the name with the descriptor, avoiding an
  unexplained invented word.

## Positioning

> QinCert turns rounding and precision risks in financial smart contracts into
> reproducible attack counterexamples or scoped proof evidence, bound to the
> exact code that was analyzed.

Chinese:

> QinCert 将金融智能合约中的舍入与精度风险，转化为可重放的攻击反例或有边界的证明证据，并绑定到被分析的确切代码。

## Promise hierarchy

1. **Exact input:** the result identifies the code and bytecode assessed;
2. **Exact claim:** each conclusion states property, assumptions and exclusions;
3. **Reproducible evidence:** a reviewer can rerun or verify the evidence;
4. **Living validity:** changes, expiry and revocation are visible.

Never promise “zero risk”, “100% safe”, “mathematically impossible to hack” or
“replaces an audit”.

## Visual system

### Palette

- Obsidian: `#07111F` - primary background;
- Mineral: `#0E2138` - raised surfaces;
- Proof Mint: `#59E1B2` - verified evidence;
- Signal Cyan: `#62B8FF` - analysis and links;
- Warm Amber: `#F4B860` - conditional/attention;
- Fault Coral: `#FF6B72` - failed/revoked;
- Cloud: `#EEF5FA` - primary light text;
- Slate: `#91A3B5` - secondary text.

Green is reserved for verified states. Decorative content must not use the same
green treatment as a passing evidence result.

### Typography

- Latin/UI: Geist or Inter;
- Chinese: Noto Sans SC / system sans-serif;
- evidence IDs and hashes: Geist Mono / JetBrains Mono;
- headlines are compact and technical, not futuristic or “crypto casino”.

### Wordmark

Use a typographic wordmark:

`Qin` in Cloud and `Cert` in Proof Mint on dark backgrounds. The dot over the
“i” may become the single proof-status accent. Do not use shields, padlocks,
dragons, coins or generic blockchain hexagons as the primary mark.

### Evidence motif

The distinctive visual motif is a sequence:

`SOURCE -> PROPERTY -> EVIDENCE -> STATUS`

Use thin rules, hashes and restrained state markers. It communicates traceable
proof rather than vague security.

## Voice

- direct, testable and calm;
- state what is known, bounded and excluded;
- prefer “no counterexample found within X” over “safe”;
- prefer “reviewed and signed for commit Y” over “certified contract”;
- explain economic consequence before implementation jargon.

## Trademark gate

Before public launch, run formal clearance for QinCert and Chinese marks in the
target jurisdictions and relevant classes. Web search is not clearance.
