# 专利现有技术与 FTO 初筛矩阵

状态：初筛，不替代专业检索、无效检索或自由实施分析。

| 现有技术 | 已公开内容 | 受影响的宽泛主张 | QinCert 必须增加的技术差异 |
|---|---|---|---|
| [EIP-4626](https://eips.ethereum.org/EIPS/eip-4626) | 四类转换/预览函数的方向性要求 | “为 ERC-4626 选择 Up/Down” | 具体实现的自动语义推导、经济偏差和跨交易证明 |
| [OpenZeppelin ERC-4626 文档](https://docs.openzeppelin.com/contracts/4.x/erc4626) | 虚拟资产/份额、decimals offset、捐赠攻击分析 | “虚拟偏移防攻击” | 根据状态/预算自动合成参数并证明上界 |
| [OpenZeppelin PR #3171](https://github.com/OpenZeppelin/openzeppelin-contracts/pull/3171) | ERC-4626 中带 rounding 的安全 `mulDiv` | “全精度乘除并选择 rounding” | 金融角色和余数受益方的程序分析 |
| [Slither](https://github.com/crytic/slither) | Solidity AST/IR、数据依赖、规则与 CI | “AST 静态扫描智能合约” | 单位图、经济主体、交易利润及证据切片 |
| [Ethereum formal verification](https://ethereum.org/developers/docs/smart-contracts/formal-verification/) | 规范、验证条件、SMT 与模型检查 | “用 SMT 证明智能合约” | 从金融语义自动生成特定属性及最小经济反例 |
| [US20200201838A1](https://patents.google.com/patent/US20200201838A1/en) | 注释源代码、生成验证条件、SMT 求解、报告 | “源码到 SMT 到报告” | 不依赖注释的金融语义/单位图与舍入分配 |
| [US11502822B2](https://patents.google.com/patent/US11502822) | 智能合约确定性静态分析 | “静态分析确定性或风险” | 具体金融算术状态与反例最小化 |
| [US11544045B2](https://patents.google.com/patent/US11544045B2) | AST 特征与智能合约风险分析 | “AST 特征检测风险” | 角色、单位、余数价值归属及状态证明 |
| [US20250063037A1](https://patents.google.com/patent/US20250063037A1/en) | 审计、分级证书、证书机构、链上验证和升级相关有效性 | “审计后发证/链上验证/升级失效” | 代码证明切片的细粒度依赖与增量失效；须做 FTO |
| [SARIF 2.1.0](https://docs.oasis-open.org/sarif/sarif/v2.1.0/) | 通用静态分析交换格式 | “以机器格式输出扫描结果” | 仅作为兼容输出，不主张为发明 |

## 初筛结论

### 红区：不单独申请

- rounding 枚举；
- `mulDiv`、sqrt、固定点换算；
- ERC-4626 向上/向下舍入；
- 虚拟偏移；
- 正则或 AST 找除法；
- SMT 求解和生成报告；
- 将审计摘要做成 PDF、NFT 或链上证书。

### 黄区：只有组合并有实验时考虑

- 金融角色推导；
- 单位传播；
- 多交易反例；
- 自动修复建议；
- commit/bytecode 证据绑定。

这些方向分别可能已有论文、工具或专利，必须继续做关键词、分类号、引用链、专利族和非专利文献检索。

### 绿区候选：完成实现和检索后再决定

- 余数在多个金融主体间的价值分配图；
- 从该图自动生成攻击收益属性和最小交易序列；
- 在攻击预算、流动性、decimals 和 Gas 约束下合成最小安全参数；
- 把证明义务映射为代码/依赖/字节码切片并进行细粒度增量失效。

“绿区”只表示相对值得研发，不表示已经具备新颖性或创造性。

## 专业检索任务单

代理师应覆盖：

- IPC/CPC：G06F 程序验证、G06Q 金融、H04L 区块链相关分类；
- 中英文关键词：rounding allocation、economic remainder、unit inference、
  vault inflation、counterexample synthesis、incremental verification、
  proof-carrying certificate、smart contract attestation；
- CN、US、EP、WO 文献和论文/开源提交；
- 重点申请人的专利族和继续申请；
- 权利要求逐项对比及 FTO 风险，不只看摘要。
