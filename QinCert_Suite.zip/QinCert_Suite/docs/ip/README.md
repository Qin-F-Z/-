# QinCert 知识产权控制包

本目录的用途，是让专利代理师、律师和项目负责人在同一事实基础上工作。

## 文件顺序

1. `asset_register.csv`：用户提供材料的内容哈希与权属状态；
2. `contribution_log.csv`：自然人创造性贡献记录模板；
3. `third_party_ledger.csv`：第三方软件和许可证义务；
4. `invention_disclosure.md`：技术交底书；
5. `prior_art_matrix.md`：现有技术与权利要求影响；
6. `claims_tree_draft.md`：权利要求树草案及申请门槛；
7. `trade_secret_register.md`：商业秘密分级；
8. `open_source_boundary.md`：开源/闭源边界；
9. `nda_negotiation_brief.md`：保密协议谈判底稿；
10. `collaboration_term_sheet.md`：成果归属与合作协议要点。

## 使用原则

- `asset_register.csv` 中的文件系统时间只用于检索，不能单独证明创作时间；
- “作者未确认”不是默认归公司，也不是默认归文件持有人；
- 发明人与专利申请人/权利人是不同概念；
- 未实现、未启用的构想不得包装为已经完成的专利实施例；
- 在首次专利申请完成前，不对外公开本目录中的技术差异与权利要求树；
- 本包是技术与谈判底稿，不是律师出具的法律意见。
