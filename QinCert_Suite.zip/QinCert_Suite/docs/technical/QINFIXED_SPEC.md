# QinFixed 0.2.0 normative arithmetic specification

Keywords **MUST**, **MUST NOT**, **SHOULD**, and **MAY** are normative.

## 1. Domains

### Mathematical domain

`mul_div(a, b, d, mode)` accepts signed integers `a`, `b` and a strictly
positive integer denominator `d`. The exact value is the rational number
`a * b / d`.

### EVM uint256 domain

`mul_div_u256(a, b, d, mode)` requires:

- `0 <= a,b,d <= 2^256 - 1`;
- `d > 0`;
- the rounded result fits in uint256.

The intermediate product MAY require 512 bits. An implementation MUST NOT
introduce an intermediate uint256 overflow.

## 2. Rounding modes

| Mode | Normative meaning |
|---|---|
| Down | Mathematical floor, toward negative infinity |
| Up | Mathematical ceiling, toward positive infinity |
| TowardZero | Truncate magnitude toward zero |
| AwayFromZero | Increase magnitude away from zero when a remainder exists |
| HalfUp | Nearest integer; exact half ties away from zero |
| HalfEven | Nearest integer; exact half ties select the even integer |

For non-negative EVM values, Down equals TowardZero and Up equals AwayFromZero.
The names remain distinct so cross-language specifications do not silently
change meaning when signed values are introduced.

## 3. Errors

- A zero or negative denominator MUST fail.
- A value outside the target numeric domain MUST fail.
- A rounded EVM result outside uint256 MUST fail.
- No failure MAY be converted to zero or to a passing proof result.

## 4. Square root

`sqrt_round(n, mode)` requires `n >= 0`.

- Down/TowardZero return the greatest `q` such that `q^2 <= n`;
- Up/AwayFromZero return the least `q` such that `q^2 >= n`;
- nearest modes select the closer integer square root.

Because consecutive square distances differ by an odd integer, an integer
radicand cannot be exactly equidistant between two consecutive integer roots.

## 5. Financial operations

Financial helpers MUST state:

- numerator and denominator meaning;
- rounding beneficiary;
- unit and decimals;
- whether fee is included in or added to the amount;
- acceptable error and overflow boundary.

No helper may default a customer-facing economic operation to an unnamed
rounding policy.

## 6. ERC-4626 profile

The profile requires:

| Operation | Required direction |
|---|---|
| convertToShares / previewDeposit | Down |
| convertToAssets / previewRedeem | Down |
| previewMint | Up |
| previewWithdraw | Up |

Execution functions additionally MUST reject nonsensical zero input/output
according to their interface and SHOULD accept caller-defined slippage bounds.

## 7. Conformance

A conforming language implementation MUST pass:

- exhaustive small-domain tests including negative mathematical values;
- randomized exact-reference tests;
- uint256 boundary and overflow tests;
- exact half-tie tests;
- cross-language vectors with identical canonical JSON;
- versioned solver properties;
- deterministic source-tree hashing.

Cross-language equivalence MUST be claimed only for the intersection of
supported numeric domains.
