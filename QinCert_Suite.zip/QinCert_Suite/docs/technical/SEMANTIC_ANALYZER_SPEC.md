# Solidity financial semantic analyzer specification

## 1. Assurance levels

- **L0 lexical**: text patterns only; never supports attestation;
- **L1 compiler AST**: comments and strings are structurally separated;
- **L2 typed intra-procedural**: types, scopes, definitions and uses resolved;
- **L3 interprocedural**: call graph, inheritance and storage flow resolved;
- **L4 deployment-aware**: libraries, proxies, bytecode and chain state resolved;
- **L5 property-backed**: findings connected to executable counterexamples or
  formal proof obligations.

The current implementation provides L1 plus selected L2 heuristics. It MUST NOT
be marketed as L3-L5 until their release gates pass.

## 2. Semantic roles

Supported roles include asset, share, price, fee, debt, rate and time.

Each assignment has:

- origin: compiler fact, adapter-confirmed, standard-derived or heuristic;
- confidence;
- source range;
- unit/decimals;
- definition and use edges.

A heuristic role MAY prioritize analysis but MUST NOT be presented as a
compiler-confirmed fact.

## 3. Rule result

Every finding MUST include:

- stable rule ID and version;
- severity and confidence;
- exact compiler source range;
- contract and function;
- evidence path;
- assumptions and unresolved behavior;
- specific remediation;
- optional executable reproducer.

## 4. False-positive controls

- comments and strings cannot satisfy a defense;
- a forced profile cannot alone classify any `.sol` file as ERC-4626;
- inherited behavior is reported as unresolved unless analyzed;
- raw unsigned division is described as deterministic floor/truncation, not
  as behaviorally unknown;
- a generic financial division is separated from an ERC-4626 direction error;
- confidence is reduced when role inference relies only on naming.

## 5. Fail-closed conditions

Parsing failure, missing imports, unsupported compiler, timeout, unresolved
proxy, or incomplete call graph MUST be visible in the result. The analyzer
must never emit a clean attestation by dropping failed files or functions.

## 6. Output

Canonical JSON is the evidence source. SARIF is a compatibility view. HTML/PDF
is a human-readable view and cannot carry more assurance than the underlying
JSON.
