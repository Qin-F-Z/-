# QinCert target product architecture

## Trust boundaries

```text
Customer repository
        |
        v
Isolated ingestion --> deterministic compiler --> semantic graph
                                                |
                       +------------------------+----------------------+
                       |                                               |
                       v                                               v
               rule/counterexample engine                       proof workers
                       |                                               |
                       +------------------------+----------------------+
                                                v
                                      evidence bundle builder
                                                |
                                    review/sign/revoke service
                                                |
                       +------------------------+----------------------+
                       v                                               v
                customer portal/API                           public verifier
```

## Components

### Ingestion

- ephemeral workspace per job;
- file type/size limits;
- dependency lock validation;
- no outbound network by default;
- deletion policy and audit event.

### Analysis plane

- exact compiler selected from allowlist;
- AST/IR normalization;
- role/unit graph;
- rule engine and custom policies;
- counterexample and proof workers;
- deterministic result IDs.

### Evidence plane

- immutable artifact storage;
- organization signing key in KMS/HSM;
- dual control for attestation;
- transparency and revocation log;
- bytecode/deployment monitor.

### Control plane

- organizations, projects, repositories, versions and jobs;
- RBAC, SSO, API tokens and webhook secrets;
- policy acceptance and risk waivers;
- usage metering, billing references and audit logs.

### Deployment models

- owner-private managed SaaS;
- dedicated tenant;
- customer VPC/on-premises;
- offline evidence appliance.

## Data model

Core entities:

- `Organization`, `Membership`, `Role`;
- `Project`, `RepositoryConnection`, `SourceVersion`;
- `AnalysisJob`, `Finding`, `ProofObligation`, `Counterexample`;
- `EvidenceBundle`, `Attestation`, `Revocation`;
- `Policy`, `RiskAcceptance`, `AuditEvent`;
- `UsageRecord`, `Plan`, `InvoiceReference`.

Production schema must enforce tenant ownership on every row and every object
key. Object storage paths are not authorization controls.

## Availability objectives

Initial targets:

- portal/API monthly availability: 99.9%;
- evidence verification endpoint: 99.95%;
- recovery point objective: 15 minutes for metadata;
- recovery time objective: 4 hours;
- signed evidence retained per contract and legal policy;
- customer source deleted according to selected retention tier.

These are product targets, not current measured SLAs.
