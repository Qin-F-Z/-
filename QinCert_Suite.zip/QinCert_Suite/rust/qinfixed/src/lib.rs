//! QinFixed Rust reference implementation.
//!
//! SPDX-License-Identifier: LicenseRef-QinCert-Proprietary-Evaluation

use num_bigint::{BigInt, BigUint, Sign};
use num_integer::Integer;
use num_traits::{One, Zero};
use std::str::FromStr;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Rounding {
    Down,
    Up,
    TowardZero,
    AwayFromZero,
    HalfUp,
    HalfEven,
}

impl FromStr for Rounding {
    type Err = &'static str;

    fn from_str(value: &str) -> Result<Self, Self::Err> {
        match value {
            "down" => Ok(Self::Down),
            "up" => Ok(Self::Up),
            "toward_zero" => Ok(Self::TowardZero),
            "away_from_zero" => Ok(Self::AwayFromZero),
            "half_up" => Ok(Self::HalfUp),
            "half_even" => Ok(Self::HalfEven),
            _ => Err("unsupported rounding mode"),
        }
    }
}

pub fn mul_div(
    multiplicand: &BigInt,
    multiplier: &BigInt,
    denominator: &BigInt,
    rounding: Rounding,
) -> Result<BigInt, &'static str> {
    if denominator <= &BigInt::zero() {
        return Err("denominator must be strictly positive");
    }
    let numerator = multiplicand * multiplier;
    let negative = numerator.sign() == Sign::Minus;
    let magnitude = numerator.magnitude();
    let denominator_unsigned = denominator
        .to_biguint()
        .ok_or("denominator must be strictly positive")?;
    let (quotient, remainder) = magnitude.div_rem(&denominator_unsigned);
    if remainder.is_zero() {
        let answer = BigInt::from(quotient);
        return Ok(if negative { -answer } else { answer });
    }

    let rounded = match rounding {
        Rounding::TowardZero => quotient,
        Rounding::AwayFromZero => quotient + BigUint::one(),
        Rounding::Down => {
            quotient
                + if negative {
                    BigUint::one()
                } else {
                    BigUint::zero()
                }
        }
        Rounding::Up => {
            quotient
                + if negative {
                    BigUint::zero()
                } else {
                    BigUint::one()
                }
        }
        Rounding::HalfUp | Rounding::HalfEven => {
            let doubled = &remainder << 1usize;
            if doubled < denominator_unsigned {
                quotient
            } else if doubled > denominator_unsigned
                || rounding == Rounding::HalfUp
                || quotient.is_odd()
            {
                quotient + BigUint::one()
            } else {
                quotient
            }
        }
    };
    let answer = BigInt::from(rounded);
    Ok(if negative { -answer } else { answer })
}

pub fn mul_div_u256(
    multiplicand: &BigUint,
    multiplier: &BigUint,
    denominator: &BigUint,
    rounding: Rounding,
) -> Result<BigUint, &'static str> {
    if denominator.is_zero() {
        return Err("denominator must be strictly positive");
    }
    let max = (BigUint::one() << 256usize) - BigUint::one();
    if multiplicand > &max || multiplier > &max || denominator > &max {
        return Err("input outside uint256");
    }
    let signed = mul_div(
        &BigInt::from(multiplicand.clone()),
        &BigInt::from(multiplier.clone()),
        &BigInt::from(denominator.clone()),
        rounding,
    )?;
    let result = signed.to_biguint().ok_or("negative uint256 result")?;
    if result > max {
        return Err("rounded result outside uint256");
    }
    Ok(result)
}

pub fn sqrt_round(value: &BigUint, rounding: Rounding) -> BigUint {
    let lower = value.sqrt();
    if &lower * &lower == *value {
        return lower;
    }
    match rounding {
        Rounding::Down | Rounding::TowardZero => lower,
        Rounding::Up | Rounding::AwayFromZero => lower + BigUint::one(),
        Rounding::HalfUp | Rounding::HalfEven => {
            let upper = &lower + BigUint::one();
            let lower_distance = value - (&lower * &lower);
            let upper_distance = (&upper * &upper) - value;
            if lower_distance < upper_distance {
                lower
            } else if upper_distance < lower_distance || rounding == Rounding::HalfUp {
                upper
            } else if lower.is_even() {
                lower
            } else {
                upper
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn signed_rounding_examples() {
        let five = BigInt::from(5);
        let minus_five = BigInt::from(-5);
        let one = BigInt::one();
        let two = BigInt::from(2);
        assert_eq!(
            mul_div(&five, &one, &two, Rounding::HalfEven).unwrap(),
            BigInt::from(2)
        );
        assert_eq!(
            mul_div(&minus_five, &one, &two, Rounding::Down).unwrap(),
            BigInt::from(-3)
        );
        assert_eq!(
            mul_div(&minus_five, &one, &two, Rounding::Up).unwrap(),
            BigInt::from(-2)
        );
    }

    #[test]
    fn uint256_result_overflow_is_rejected() {
        let max = (BigUint::one() << 256usize) - BigUint::one();
        assert!(mul_div_u256(&max, &max, &BigUint::one(), Rounding::Down).is_err());
    }
}
