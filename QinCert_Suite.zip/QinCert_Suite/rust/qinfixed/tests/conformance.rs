use num_bigint::{BigInt, BigUint};
use qinfixed::{Rounding, mul_div, sqrt_round};
use serde::Deserialize;
use std::collections::BTreeMap;
use std::str::FromStr;

#[derive(Deserialize)]
struct Vectors {
    mul_div: Vec<MulVector>,
    sqrt: Vec<SqrtVector>,
}

#[derive(Deserialize)]
struct MulVector {
    a: String,
    b: String,
    d: String,
    results: BTreeMap<String, String>,
}

#[derive(Deserialize)]
struct SqrtVector {
    value: String,
    results: BTreeMap<String, String>,
}

#[test]
fn python_generated_vectors_match_rust() {
    let payload = include_str!("../../../vectors/qinfixed-vectors.json");
    let vectors: Vectors = serde_json::from_str(payload).unwrap();

    for vector in vectors.mul_div {
        let a = BigInt::from_str(&vector.a).unwrap();
        let b = BigInt::from_str(&vector.b).unwrap();
        let d = BigInt::from_str(&vector.d).unwrap();
        for (mode, expected) in vector.results {
            let actual = mul_div(&a, &b, &d, Rounding::from_str(&mode).unwrap()).unwrap();
            assert_eq!(actual.to_string(), expected, "{a} * {b} / {d} {mode}");
        }
    }

    for vector in vectors.sqrt {
        let value = BigUint::from_str(&vector.value).unwrap();
        for (mode, expected) in vector.results {
            let actual = sqrt_round(&value, Rounding::from_str(&mode).unwrap());
            assert_eq!(actual.to_string(), expected, "sqrt {value} {mode}");
        }
    }
}
