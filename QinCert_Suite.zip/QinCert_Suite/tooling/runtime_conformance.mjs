import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";
import ganache from "ganache";
import { BrowserProvider, ContractFactory } from "ethers";

const tooling = path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Z]:)/, "$1"));
const root = path.resolve(tooling, "..");
const compilePath = path.join(root, "build", "solidity-compile.json");
const vectorPath = path.join(root, "vectors", "qinfixed-vectors.json");
const outputPath = path.join(root, "build", "solidity-runtime-conformance.json");
const compiled = JSON.parse(fs.readFileSync(compilePath, "utf8"));
const vectors = JSON.parse(fs.readFileSync(vectorPath, "utf8"));
const harness = compiled.contracts.QinRoundingHarness;
if (!harness?.bytecode) throw new Error("QinRoundingHarness bytecode is missing");

const eip1193 = ganache.provider({
  logging: { quiet: true },
  wallet: { totalAccounts: 1, deterministic: true },
  chain: { hardfork: "shanghai" },
});
const provider = new BrowserProvider(eip1193);
const signer = await provider.getSigner();
const factory = new ContractFactory(harness.abi, `0x${harness.bytecode}`, signer);
const contract = await factory.deploy();
await contract.waitForDeployment();

const modes = ["down", "up", "toward_zero", "away_from_zero", "half_up", "half_even"];
const checks = [];
for (const vector of vectors.mul_div) {
  if ([vector.a, vector.b, vector.d].some((item) => item.startsWith("-"))) continue;
  for (const [modeIndex, mode] of modes.entries()) {
    const actual = await contract.mulDiv(
      BigInt(vector.a),
      BigInt(vector.b),
      BigInt(vector.d),
      modeIndex,
    );
    const expected = BigInt(vector.results[mode]);
    checks.push({
      a: vector.a,
      b: vector.b,
      d: vector.d,
      mode,
      expected: expected.toString(),
      actual: actual.toString(),
      passed: actual === expected,
    });
  }
}
const passed = checks.every((item) => item.passed);
const payload = {
  schemaVersion: "0.2.0",
  compilerVersion: compiled.compilerVersion,
  contractAddress: await contract.getAddress(),
  vectorSha256: createHash("sha256")
    .update(fs.readFileSync(vectorPath))
    .digest("hex"),
  chain: "deterministic in-memory EVM",
  checks,
  passed,
};
fs.writeFileSync(outputPath, JSON.stringify(payload, null, 2));
await eip1193.disconnect();
process.stdout.write(
  `${checks.length} Solidity/Python vectors ${passed ? "passed" : "failed"}\n`,
);
process.exit(passed ? 0 : 1);
