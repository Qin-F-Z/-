import fs from "node:fs";
import path from "node:path";
import solc from "solc";

const tooling = path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Z]:)/, "$1"));
const root = path.resolve(tooling, "..");
const sourceRoot = path.join(root, "contracts", "src");
const outputPath = path.join(root, "build", "solidity-compile.json");
const sourceFiles = [
  "QinRounding.sol",
  "QinRoundingHarness.sol",
  "QinReferenceVault.sol",
];
const sources = Object.fromEntries(
  sourceFiles.map((name) => [
    name,
    { content: fs.readFileSync(path.join(sourceRoot, name), "utf8") },
  ]),
);

function findImports(importPath) {
  const candidates = [
    path.join(sourceRoot, importPath),
    path.join(tooling, "node_modules", importPath),
  ];
  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) {
      return { contents: fs.readFileSync(candidate, "utf8") };
    }
  }
  return { error: `Import not found: ${importPath}` };
}

const input = {
  language: "Solidity",
  sources,
  settings: {
    optimizer: { enabled: true, runs: 200 },
    outputSelection: {
      "*": {
        "*": ["abi", "evm.bytecode.object", "evm.deployedBytecode.object"],
      },
    },
  },
};
const compiled = JSON.parse(solc.compile(JSON.stringify(input), { import: findImports }));
const diagnostics = compiled.errors ?? [];
const fatal = diagnostics.filter((item) => item.severity === "error");
if (fatal.length > 0) {
  process.stderr.write(fatal.map((item) => item.formattedMessage).join("\n"));
  process.exit(1);
}

const contracts = {};
for (const [fileName, entries] of Object.entries(compiled.contracts ?? {})) {
  if (!sourceFiles.includes(fileName)) continue;
  for (const [contractName, artifact] of Object.entries(entries)) {
    contracts[contractName] = {
      source: fileName,
      abi: artifact.abi,
      bytecode: artifact.evm.bytecode.object,
      bytecodeSha256: artifact.evm.bytecode.object
        ? (await import("node:crypto"))
            .createHash("sha256")
            .update(artifact.evm.bytecode.object)
            .digest("hex")
        : null,
      deployedBytecodeSha256: artifact.evm.deployedBytecode.object
        ? (await import("node:crypto"))
            .createHash("sha256")
            .update(artifact.evm.deployedBytecode.object)
            .digest("hex")
        : null,
    };
  }
}
fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(
  outputPath,
  JSON.stringify(
    {
      compilerVersion: solc.version(),
      optimizer: { enabled: true, runs: 200 },
      diagnostics,
      contracts,
    },
    null,
    2,
  ),
);
process.stdout.write(`compiled ${Object.keys(contracts).join(", ")}\n`);
