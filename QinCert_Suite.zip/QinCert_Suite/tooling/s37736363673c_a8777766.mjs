import fs from "node:fs";
import path from "node:path";
import solc from "solc";

const sourcePath = process.argv[2];
if (!sourcePath) {
  process.stderr.write("usage: node solc_ast.mjs <source.sol>\n");
  process.exit(2);
}

const absolute = path.resolve(sourcePath);
const sourceName = path.basename(absolute);
const content = fs.readFileSync(absolute, "utf8");
const input = {
  language: "Solidity",
  sources: {
    [sourceName]: { content },
  },
  settings: {
    stopAfter: "parsing",
    outputSelection: {
      "*": {
        "": ["ast"],
      },
    },
  },
};

const output = JSON.parse(solc.compile(JSON.stringify(input)));
const diagnostics = (output.errors ?? []).map((item) => ({
  severity: item.severity,
  type: item.type,
  message: item.message,
  formattedMessage: item.formattedMessage,
  sourceLocation: item.sourceLocation ?? null,
}));
const fatal = diagnostics.filter((item) => item.severity === "error");
if (fatal.length > 0 || !output.sources?.[sourceName]?.ast) {
  process.stdout.write(JSON.stringify({ ok: false, diagnostics }));
  process.exit(1);
}
process.stdout.write(
  JSON.stringify({
    ok: true,
    compilerVersion: solc.version(),
    sourceName,
    diagnostics,
    ast: output.sources[sourceName].ast,
  }),
);
