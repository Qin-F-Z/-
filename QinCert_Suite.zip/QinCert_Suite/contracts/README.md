# QinCert Solidity reference

The reference consists of:

- `QinRounding.sol`: full-p
## Reproduce with Foundry

```sh
forge install OpenZeppeliforge test -vvv
```

The repository-level veri