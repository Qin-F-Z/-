# QinCert Solidity reference

The reference consists of:

- `QinRounding.sol`: full-precision unsigned rounding built on OpenZeppelin
  `Math.mulDiv`;
- `QinReferenceVault.sol`: ERC-4626 reference with virtual precision,
  zero-output rejection, entry-point slippage guards, pausing, ownership, and
  reentrancy protection;
- Foundry unit and fuzz tests.

## Reproduce with Foundry

```sh
forge install OpenZeppelin/openzeppelin-contracts@v5.6.1
forge install foundry-rs/forge-std
forge test -vvv
```

The repository-level verifier also compiles the production source with pinned
solc-js and OpenZeppelin versions. A passing compile is not an independent
security audit.
