// SPDX-License-Identifier: LicenseRef-QinCert-Proprietary-Evaluation
pragma solidity ^0.8.24;

import {QinRounding} from "./QinRounding.sol";

contract QinRoundingHarness {
    function mulDiv(
        uint256 multiplicand,
        uint256 multiplier,
        uint256 denominator,
        QinRounding.Rounding rounding
    ) external pure returns (uint256) {
        return QinRounding.mulDiv(
            multiplicand,
            multiplier,
            denominator,
            rounding
        );
    }
}
