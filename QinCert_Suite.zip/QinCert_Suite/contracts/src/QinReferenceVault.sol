// SPDX-License-Identifier: LicenseRef-QinCert-Proprietary-Evaluation
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ERC4626} from "@openzeppelin/contracts/token/ERC20/extensions/ERC4626.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/// @notice Reference ERC-4626 implementation for QinCert verification fixtures.
/// @dev This is a research reference and still requires independent audit before use.
contract QinReferenceVault is ERC4626, Ownable, Pausable, ReentrancyGuard {
    uint8 private immutable _configuredDecimalsOffset;
    uint256 public immutable minimumInitialAssets;

    error ZeroAssets();
    error ZeroShares();
    error OffsetTooLarge(uint8 supplied);
    error InitialDepositTooSmall(uint256 supplied, uint256 minimum);
    error MinimumSharesNotMet(uint256 actual, uint256 minimum);
    error MaximumAssetsExceeded(uint256 actual, uint256 maximum);
    error MaximumSharesExceeded(uint256 actual, uint256 maximum);
    error MinimumAssetsNotMet(uint256 actual, uint256 minimum);

    constructor(
        IERC20 asset_,
        string memory name_,
        string memory symbol_,
        address initialOwner_,
        uint8 decimalsOffset_,
        uint256 minimumInitialAssets_
    )
        ERC20(name_, symbol_)
        ERC4626(asset_)
        Ownable(initialOwner_)
    {
        if (decimalsOffset_ > 18) revert OffsetTooLarge(decimalsOffset_);
        _configuredDecimalsOffset = decimalsOffset_;
        minimumInitialAssets = minimumInitialAssets_;
    }

    function _decimalsOffset() internal view override returns (uint8) {
        return _configuredDecimalsOffset;
    }

    function configuredDecimalsOffset() external view returns (uint8) {
        return _configuredDecimalsOffset;
    }

    function pause() external onlyOwner {
        _pause();
    }

    function unpause() external onlyOwner {
        _unpause();
    }

    function deposit(uint256 assets, address receiver)
        public
        override
        whenNotPaused
        nonReentrant
        returns (uint256 shares)
    {
        _checkInitialDeposit(assets);
        shares = previewDeposit(assets);
        if (assets == 0) revert ZeroAssets();
        if (shares == 0) revert ZeroShares();
        _deposit(_msgSender(), receiver, assets, shares);
    }

    function mint(uint256 shares, address receiver)
        public
        override
        whenNotPaused
        nonReentrant
        returns (uint256 assets)
    {
        if (shares == 0) revert ZeroShares();
        assets = previewMint(shares);
        _checkInitialDeposit(assets);
        if (assets == 0) revert ZeroAssets();
        _deposit(_msgSender(), receiver, assets, shares);
    }

    function withdraw(uint256 assets, address receiver, address owner)
        public
        override
        whenNotPaused
        nonReentrant
        returns (uint256 shares)
    {
        if (assets == 0) revert ZeroAssets();
        shares = previewWithdraw(assets);
        if (shares == 0) revert ZeroShares();
        _withdraw(_msgSender(), receiver, owner, assets, shares);
    }

    function redeem(uint256 shares, address receiver, address owner)
        public
        override
        whenNotPaused
        nonReentrant
        returns (uint256 assets)
    {
        if (shares == 0) revert ZeroShares();
        assets = previewRedeem(shares);
        if (assets == 0) revert ZeroAssets();
        _withdraw(_msgSender(), receiver, owner, assets, shares);
    }

    function depositWithMinShares(
        uint256 assets,
        address receiver,
        uint256 minSharesOut
    ) external whenNotPaused nonReentrant returns (uint256 shares) {
        _checkInitialDeposit(assets);
        if (assets == 0) revert ZeroAssets();
        shares = previewDeposit(assets);
        if (shares == 0) revert ZeroShares();
        if (shares < minSharesOut) {
            revert MinimumSharesNotMet(shares, minSharesOut);
        }
        _deposit(_msgSender(), receiver, assets, shares);
    }

    function mintWithMaxAssets(
        uint256 shares,
        address receiver,
        uint256 maxAssetsIn
    ) external whenNotPaused nonReentrant returns (uint256 assets) {
        if (shares == 0) revert ZeroShares();
        assets = previewMint(shares);
        _checkInitialDeposit(assets);
        if (assets > maxAssetsIn) {
            revert MaximumAssetsExceeded(assets, maxAssetsIn);
        }
        _deposit(_msgSender(), receiver, assets, shares);
    }

    function withdrawWithMaxShares(
        uint256 assets,
        address receiver,
        address owner,
        uint256 maxSharesBurned
    ) external whenNotPaused nonReentrant returns (uint256 shares) {
        if (assets == 0) revert ZeroAssets();
        shares = previewWithdraw(assets);
        if (shares > maxSharesBurned) {
            revert MaximumSharesExceeded(shares, maxSharesBurned);
        }
        _withdraw(_msgSender(), receiver, owner, assets, shares);
    }

    function redeemWithMinAssets(
        uint256 shares,
        address receiver,
        address owner,
        uint256 minAssetsOut
    ) external whenNotPaused nonReentrant returns (uint256 assets) {
        if (shares == 0) revert ZeroShares();
        assets = previewRedeem(shares);
        if (assets == 0) revert ZeroAssets();
        if (assets < minAssetsOut) {
            revert MinimumAssetsNotMet(assets, minAssetsOut);
        }
        _withdraw(_msgSender(), receiver, owner, assets, shares);
    }

    function _checkInitialDeposit(uint256 assets) private view {
        if (totalSupply() == 0 && assets < minimumInitialAssets) {
            revert InitialDepositTooSmall(assets, minimumInitialAssets);
        }
    }
}
