// SPDX-License-Identifier: LicenseRef-QinCert-Proprietary-Evaluation
pragma solidity ^0.8.24;

import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";

/// @notice Full-precision uint256 multiplication/division with named rounding.
/// @dev For unsigned integers, Down equals TowardZero and Up equals AwayFromZero.
library QinRounding {
    enum Rounding {
        Down,
        Up,
        TowardZero,
        AwayFromZero,
        HalfUp,
        HalfEven
    }

    function mulDiv(
        uint256 multiplicand,
        uint256 multiplier,
        uint256 denominator,
        Rounding rounding
    ) internal pure returns (uint256 result) {
        result = Math.mulDiv(multiplicand, multiplier, denominator);
        uint256 remainder = mulmod(multiplicand, multiplier, denominator);
        if (remainder == 0) return result;

        if (rounding == Rounding.Up || rounding == Rounding.AwayFromZero) {
            return result + 1;
        }
        if (rounding == Rounding.Down || rounding == Rounding.TowardZero) {
            return result;
        }

        // Compare remainder with denominator / 2 without doubling remainder.
        uint256 complement = denominator - remainder;
        if (remainder > complement) return result + 1;
        if (remainder < complement) return result;

        // Exact half tie.
        if (rounding == Rounding.HalfUp) return result + 1;
        return result & 1 == 0 ? result : result + 1;
    }
}
