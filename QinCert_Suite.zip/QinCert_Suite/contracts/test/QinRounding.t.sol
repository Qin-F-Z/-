// SPDX-License-Identifier: LicenseRef-QinCert-Proprietary-Evaluation
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {QinRounding} from "../src/QinRounding.sol";

contract QinRoundingTest is Test {
    function testHalfEvenTies() external pure {
        assertEq(QinRounding.mulDiv(5, 1, 2, QinRounding.Rounding.HalfEven), 2);
        assertEq(QinRounding.mulDiv(7, 1, 2, QinRounding.Rounding.HalfEven), 4);
        assertEq(QinRounding.mulDiv(5, 1, 2, QinRounding.Rounding.HalfUp), 3);
    }

    function testFuzzDirectionalBounds(uint256 a, uint256 b, uint256 d) external pure {
        d = bound(d, 1, type(uint256).max);
        vm.assume(a == 0 || b <= type(uint256).max / a);
        uint256 product = a * b;
        uint256 down = QinRounding.mulDiv(a, b, d, QinRounding.Rounding.Down);
        uint256 up = QinRounding.mulDiv(a, b, d, QinRounding.Rounding.Up);
        assertLe(down * d, product);
        assertGe(up * d, product);
        assertLe(up - down, 1);
    }
}
