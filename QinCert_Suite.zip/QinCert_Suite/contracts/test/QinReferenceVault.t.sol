// SPDX-License-Identifier: LicenseRef-QinCert-Proprietary-Evaluation
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {QinReferenceVault} from "../src/QinReferenceVault.sol";
import {MockAsset} from "./MockAsset.sol";

contract QinReferenceVaultTest is Test {
    MockAsset internal asset;
    QinReferenceVault internal vault;
    address internal alice = address(0xA11CE);
    address internal attacker = address(0xBAD);
    address internal victim = address(0xBEEF);

    function setUp() external {
        asset = new MockAsset();
        vault = new QinReferenceVault(asset, "Qin Vault", "qVAULT", address(this), 6, 1);
        asset.mint(alice, 1_000_000 ether);
        asset.mint(attacker, 1_000_000 ether);
        asset.mint(victim, 1_000_000 ether);
        vm.prank(alice);
        asset.approve(address(vault), type(uint256).max);
        vm.prank(attacker);
        asset.approve(address(vault), type(uint256).max);
        vm.prank(victim);
        asset.approve(address(vault), type(uint256).max);
    }

    function testPreviewInequalities(uint128 assetsIn, uint128 sharesIn) external {
        assetsIn = uint128(bound(assetsIn, 1, type(uint96).max));
        sharesIn = uint128(bound(sharesIn, 1, type(uint96).max));
        vm.prank(alice);
        vault.deposit(10_000 ether, alice);

        uint256 supply = vault.totalSupply() + 10 ** vault.configuredDecimalsOffset();
        uint256 total = vault.totalAssets() + 1;
        assertLe(vault.previewDeposit(assetsIn) * total, uint256(assetsIn) * supply);
        assertGe(vault.previewMint(sharesIn) * supply, uint256(sharesIn) * total);
        assertGe(vault.previewWithdraw(assetsIn) * total, uint256(assetsIn) * supply);
        assertLe(vault.previewRedeem(sharesIn) * supply, uint256(sharesIn) * total);
    }

    function testDonationSequenceDoesNotProfitAttacker() external {
        uint256 attackerBefore = asset.balanceOf(attacker);
        vm.prank(attacker);
        uint256 attackerShares = vault.deposit(1 ether, attacker);

        vm.prank(attacker);
        asset.transfer(address(vault), 100_000 ether);

        vm.prank(victim);
        uint256 victimShares = vault.depositWithMinShares(100 ether, victim, 1);
        assertGt(victimShares, 0);

        vm.prank(attacker);
        vault.redeem(attackerShares, attacker, attacker);
        assertLe(asset.balanceOf(attacker), attackerBefore);
    }

    function testSlippageGuardReverts() external {
        vm.prank(alice);
        vm.expectRevert(QinReferenceVault.MinimumSharesNotMet.selector);
        vault.depositWithMinShares(100 ether, alice, type(uint256).max);
    }

    function testPauseBlocksStateChangingEntryPoints() external {
        vault.pause();
        vm.prank(alice);
        vm.expectRevert();
        vault.deposit(100 ether, alice);
    }
}
