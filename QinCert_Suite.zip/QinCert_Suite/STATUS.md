# QinCert implementation and validation ledger

Date: 2026-07-24  
Version: 0.2.0-research

| Capability | Implementation | Validation state | Release gate |
|---|---|---|---|
| Signed integer `mul_div` with six rounding modes | Implemented | TESTED after `verify_all.py` passes | Unit, exhaustive-small-domain, randomized tests |
| EVM `uint256` `mul_div` semantics | Implemented | TESTED after verification | Overflow and zero-denominator tests |
| Integer square-root rounding | Implemented | TESTED after verification | Boundary and exact-square tests |
| ERC-4626 preview directions | Implemented in Python model | TESTED after verification | Inequality and round-trip tests |
| Donation/zero-share counterexample search | Implemented, bounded | CONDITIONAL | Bounds are included in every result |
| Solidity compiler AST ingestion | Implemented through pinned solc-js | TESTED on pinned fixtures | AST fixture regression suite |
| Financial role and unit inference | Implemented, heuristic | CONDITIONAL | Confidence and evidence path required |
| Interprocedural data flow | Partial | UNVERIFIED for arbitrary programs | No production attestation may claim completeness |
| Proxy implementation resolution | Schema and rule hooks only | UNVERIFIED | Requires deployment/RPC adapter |
| Z3 arithmetic properties | Five named properties implemented | PROVED in the recorded unbounded non-negative integer model | Solver result must be `sat`/`unsat`, never inferred |
| Canonical evidence bundle | Implemented | TESTED after verification | Schema, hash, expiry, and signature tests |
| Ed25519 signing | Implemented | TESTED after verification | Ephemeral test key only; no production key included |
| Certificate transparency service | Specification only | UNVERIFIED | Requires production append-only service |
| Solidity reference vault | Implemented source; solc-js production compile passes | TESTED for compilation; Foundry tests UNVERIFIED in this environment | Foundry execution and independent audit |
| Real-project benchmark corpus | Harness and adversarial fixtures | PARTIAL | License-reviewed, pinned real projects required |
| SaaS control plane | Product implementation maintained separately | TESTED for production build and SSR; CONDITIONAL for operations | Live authentication, tenant isolation, billing, and DR exercises |
| Reproduction container | Version-pinned multi-stage Dockerfile | IMPLEMENTED; UNVERIFIED because this host lacks a running Linux engine | Build/run in release CI and record image digests |

## Non-negotiable claims policy

1. A missing tool is a failure to verify, not a pass.
2. A bounded search is not a universal proof.
3. A heuristic semantic label is not a compiler fact.
4. A passing arithmetic assessment is not a full-contract audit.
5. A self-signed evidence bundle is not independent certification.
6. Only an exact commit and bytecode digest can inherit a prior result.
