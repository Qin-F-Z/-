"""Generate deterministic cross-language QinFixed conformance vectors."""

from __future__ import annotations

import json
from pathlib import Path

from qincert.math.core import Rounding, mul_div, sqrt_round

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    mul_inputs = [
        (0, 0, 1),
        (1, 1, 2),
        (5, 1, 2),
        (7, 1, 2),
        (-5, 1, 2),
        (-7, 1, 2),
        (10, 7, 6),
        (10**18, 10**18, 10**27),
        ((1 << 128) - 1, (1 << 64) + 7, (1 << 96) + 3),
        ((1 << 255) - 1, 2, (1 << 128) + 1),
    ]
    mul_vectors = []
    for a, b, d in mul_inputs:
        mul_vectors.append(
            {
                "a": str(a),
                "b": str(b),
                "d": str(d),
                "results": {
                    mode.value: str(mul_div(a, b, d, mode))
                    for mode in Rounding
                },
            }
        )
    sqrt_inputs = [0, 1, 2, 3, 4, 15, 16, 17, 10**18, (1 << 256) - 1]
    sqrt_vectors = []
    for value in sqrt_inputs:
        sqrt_vectors.append(
            {
                "value": str(value),
                "results": {
                    mode.value: str(sqrt_round(value, mode)) for mode in Rounding
                },
            }
        )
    payload = {
        "schema_version": "0.2.0",
        "semantics": "QINFIXED_SPEC.md",
        "mul_div": mul_vectors,
        "sqrt": sqrt_vectors,
    }
    destination = ROOT / "vectors" / "qinfixed-vectors.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(destination)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
