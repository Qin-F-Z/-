"""Build and self-verify a research-release evidence bundle.

The ephemeral key proves envelope integrity during this run. It is not an
organizational identity and the bundle is explicitly T0, not an attestation.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

from qincert.evidence.bundle import build_bundle, generate_keypair, verify_bundle

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "build"


def main() -> int:
    summary = json.loads(
        (BUILD / "verification-summary.json").read_text(encoding="utf-8")
    )
    z3 = json.loads((BUILD / "z3-results.json").read_text(encoding="utf-8"))
    checks = [
        {
            "id": item["id"],
            "result": item["result"],
            "evidence": "verification-summary.json",
        }
        for item in summary["checks"]
    ]
    checks.extend(
        {
            "id": item["id"],
            "result": item["result"],
            "evidence": "z3-results.json",
        }
        for item in z3["properties"]
    )
    artifacts = [
        ROOT / "pyproject.toml",
        ROOT / "qincert" / "math" / "core.py",
        ROOT / "qincert" / "scanner" / "analyzer.py",
        ROOT / "qincert" / "evidence" / "bundle.py",
        ROOT / "contracts" / "src" / "QinRounding.sol",
        ROOT / "contracts" / "src" / "QinReferenceVault.sol",
        ROOT / "rust" / "qinfixed" / "src" / "lib.rs",
        ROOT / "vectors" / "qinfixed-vectors.json",
        BUILD / "verification-summary.json",
        BUILD / "solidity-runtime-conformance.json",
        BUILD / "z3-results.json",
    ]
    private, public = generate_keypair()
    expires = (datetime.now(UTC) + timedelta(days=30)).replace(
        microsecond=0
    ).isoformat()
    envelope = build_bundle(
        subject="QinCert Suite 0.2.0 research release",
        artifacts=artifacts,
        checks=checks,
        scope={
            "trust_tier": "T0-local-self-test",
            "claim": (
                "Reproducible implementation checks for the listed artifacts; "
                "not independent certification"
            ),
            "source_tree_sha256": summary["source_tree_sha256"],
        },
        exclusions=[
            "Not a complete smart-contract audit",
            "No independent reviewer or organizational signing identity",
            "Foundry tests are supplied but not executed unless Foundry is installed",
            "Real-project benchmark corpus is not yet release-qualified",
            "Interprocedural and deployment-aware semantic completeness is not claimed",
        ],
        private_key_pem=private,
        expires_at=expires,
        artifact_root=ROOT,
    )
    evidence_path = BUILD / "qincert-evidence-0.2.0.json"
    evidence_path.write_text(
        json.dumps(envelope, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    (BUILD / "ephemeral-test-public-key.pem").write_bytes(public)
    result = verify_bundle(envelope, artifact_root=ROOT)
    (BUILD / "evidence-verification.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
