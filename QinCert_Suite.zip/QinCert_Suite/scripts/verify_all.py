"""Fail-closed QinCert verification entry point."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "build"


def run_check(identifier: str, command: list[str]) -> dict:
    process = subprocess.run(
        command,
        cwd=ROOT,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    return {
        "id": identifier,
        "result": "TESTED" if process.returncode == 0 else "FAILED",
        "returncode": process.returncode,
        "command": command,
        "stdout": process.stdout,
        "stderr": process.stderr,
    }


def tree_hash() -> str:
    digest = hashlib.sha256()
    excluded = {
        ".git",
        ".venv",
        "node_modules",
        "build",
        "target",
        "dist",
        "__pycache__",
        ".pytest_cache",
    }
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or any(part in excluded for part in path.parts):
            continue
        relative = path.relative_to(ROOT).as_posix().encode("utf-8")
        digest.update(len(relative).to_bytes(4, "big"))
        digest.update(relative)
        payload = path.read_bytes()
        digest.update(len(payload).to_bytes(8, "big"))
        digest.update(payload)
    return digest.hexdigest()


def main() -> int:
    BUILD.mkdir(exist_ok=True)
    python = sys.executable
    toolchain = run_check(
        "toolchain-version-lock",
        [python, "scripts/check_toolchain.py"],
    )
    vectors = run_check(
        "cross-language-vector-generation",
        [python, "scripts/generate_vectors.py"],
    )
    checks = [
        toolchain,
        vectors,
        run_check(
            "python-unit-tests",
            [python, "-m", "unittest", "discover", "-s", "tests", "-v"],
        ),
        run_check("z3-properties", [python, "proofs/z3_properties.py"]),
        run_check(
            "scanner-sarif-smoke",
            [
                python,
                "-m",
                "qincert",
                "scan",
                "datasets/fixtures/ExplicitPolicyVault.sol",
                "--format",
                "sarif",
            ],
        ),
        run_check(
            "adversarial-benchmark",
            [python, "scripts/run_benchmark.py"],
        ),
        run_check(
            "solidity-production-compile",
            ["node", "tooling/compile_contracts.mjs"],
        ),
        run_check(
            "solidity-runtime-conformance",
            ["node", "tooling/runtime_conformance.mjs"],
        ),
        run_check(
            "rust-format",
            [
                "cargo",
                "fmt",
                "--manifest-path",
                "rust/qinfixed/Cargo.toml",
                "--",
                "--check",
            ],
        ),
        run_check(
            "rust-clippy",
            [
                "cargo",
                "clippy",
                "--manifest-path",
                "rust/qinfixed/Cargo.toml",
                "--all-targets",
                "--locked",
                "--",
                "-D",
                "warnings",
            ],
        ),
        run_check(
            "rust-conformance",
            ["cargo", "test", "--manifest-path", "rust/qinfixed/Cargo.toml", "--locked"],
        ),
    ]
    # A scanner finding uses return code 1 by design, so the negative control is
    # validated independently from the all-pass command list.
    negative = subprocess.run(
        [
            python,
            "-m",
            "qincert",
            "scan",
            "datasets/fixtures/UnsafeRawVault.sol",
            "--format",
            "json",
        ],
        cwd=ROOT,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    negative_ok = negative.returncode == 1 and '"severity": "high"' in negative.stdout
    checks.append(
        {
            "id": "scanner-negative-control",
            "result": "TESTED" if negative_ok else "FAILED",
            "returncode": negative.returncode,
            "command": ["qincert", "scan", "UnsafeRawVault.sol"],
            "stdout": negative.stdout,
            "stderr": negative.stderr,
        }
    )

    summary = {
        "schema_version": "0.2.0",
        "created_at": datetime.now(UTC).replace(microsecond=0).isoformat(),
        "python": sys.version,
        "platform": sys.platform,
        "source_tree_sha256": tree_hash(),
        "checks": checks,
        "all_required_checks_passed": all(
            check["result"] == "TESTED" for check in checks
        ),
        "environment": {
            key: os.environ.get(key)
            for key in ("CI", "GITHUB_SHA", "SOURCE_DATE_EPOCH")
            if os.environ.get(key)
        },
    }
    (BUILD / "verification-summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    for check in checks:
        print(f"{check['id']}: {check['result']}")
        if check["result"] == "FAILED":
            print(check["stdout"])
            print(check["stderr"], file=sys.stderr)
    if summary["all_required_checks_passed"]:
        evidence = run_check(
            "release-evidence",
            [python, "scripts/build_release_evidence.py"],
        )
        print(f"{evidence['id']}: {evidence['result']}")
        if evidence["result"] != "TESTED":
            print(evidence["stdout"])
            print(evidence["stderr"], file=sys.stderr)
            print("VERIFICATION FAILED", file=sys.stderr)
            return 1
        print("ALL REQUIRED CHECKS PASSED")
        print(f"SOURCE TREE SHA256 {summary['source_tree_sha256']}")
        return 0
    print("VERIFICATION FAILED", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
