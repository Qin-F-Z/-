"""Run the labeled adversarial benchmark and emit transparent metrics."""

from __future__ import annotations

import json
from pathlib import Path

from qincert.scanner import SolidityAnalyzer

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    manifest = json.loads(
        (ROOT / "datasets" / "benchmark_manifest.json").read_text(
            encoding="utf-8"
        )
    )
    true_positive = false_positive = false_negative = true_negative = 0
    cases = []
    for item in manifest["splits"]["public"]:
        result = SolidityAnalyzer().scan(ROOT / "datasets" / item["path"])
        actual = {
            finding.rule_id
            for finding in result.findings
            if finding.severity in {"critical", "high"}
        }
        expected = set(item["expected_rules"])
        # The manifest can include medium expected rules; headline high metrics
        # compare only rules that are high in the analyzed fixture.
        expected_high = {
            rule
            for rule in expected
            if rule in {"QIN-MATH-001", "QIN4626-001", "QIN4626-002"}
        }
        true_positive += len(actual & expected_high)
        false_positive += len(actual - expected_high)
        false_negative += len(expected_high - actual)
        if not actual and not expected_high:
            true_negative += 1
        cases.append(
            {
                "id": item["id"],
                "label": item["label"],
                "actual_high_rules": sorted(actual),
                "expected_high_rules": sorted(expected_high),
                "passed": actual == expected_high,
            }
        )
    precision = (
        true_positive / (true_positive + false_positive)
        if true_positive + false_positive
        else 1.0
    )
    recall = (
        true_positive / (true_positive + false_negative)
        if true_positive + false_negative
        else 1.0
    )
    payload = {
        "schema_version": "0.1.0",
        "dataset": "adversarial fixtures only",
        "cases": cases,
        "counts": {
            "true_positive": true_positive,
            "false_positive": false_positive,
            "false_negative": false_negative,
            "true_negative_cases": true_negative,
        },
        "precision": precision,
        "recall": recall,
        "publishable_real_world_metric": False,
        "limitations": manifest["limitations"],
        "passed": all(case["passed"] for case in cases),
    }
    destination = ROOT / "build" / "benchmark-results.json"
    destination.parent.mkdir(exist_ok=True)
    destination.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if payload["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
