"""Fail closed when the reproducibility toolchain differs from the release lock."""

from __future__ import annotations

import json
import subprocess
import sys
from importlib.metadata import version


def output(*command: str) -> str:
    process = subprocess.run(
        command,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if process.returncode != 0:
        raise RuntimeError(f"{' '.join(command)} failed: {process.stderr.strip()}")
    return process.stdout.strip()


expected = {
    "python": "3.12.13",
    "node": "v24.16.0",
    "npm": "11.13.0",
    "cargo_prefix": "cargo 1.96.0 ",
    "rustc_prefix": "rustc 1.96.0 ",
    "solc": "0.8.36",
    "openzeppelin": "5.6.1",
    "cryptography": "49.0.0",
    "jsonschema": "4.26.0",
    "z3-solver": "4.15.3.0",
    "hypothesis": "6.151.5",
}

actual = {
    "python": ".".join(str(part) for part in sys.version_info[:3]),
    "node": output("node", "--version"),
    "npm": output("npm.cmd" if sys.platform == "win32" else "npm", "--version"),
    "cargo_prefix": output("cargo", "--version"),
    "rustc_prefix": output("rustc", "--version"),
    "solc": output(
        "node",
        "-p",
        "require('./tooling/node_modules/solc/package.json').version",
    ),
    "openzeppelin": output(
        "node",
        "-p",
        "require('./tooling/node_modules/@openzeppelin/contracts/package.json').version",
    ),
    "cryptography": version("cryptography"),
    "jsonschema": version("jsonschema"),
    "z3-solver": version("z3-solver"),
    "hypothesis": version("hypothesis"),
}

failures: list[str] = []
for key, expected_value in expected.items():
    actual_value = actual[key]
    if key.endswith("_prefix"):
        if not actual_value.startswith(expected_value):
            failures.append(f"{key}: expected prefix {expected_value!r}, got {actual_value!r}")
    elif actual_value != expected_value:
        failures.append(f"{key}: expected {expected_value!r}, got {actual_value!r}")

print(json.dumps({"expected": expected, "actual": actual}, indent=2))
if failures:
    raise SystemExit("toolchain lock mismatch:\n" + "\n".join(failures))
