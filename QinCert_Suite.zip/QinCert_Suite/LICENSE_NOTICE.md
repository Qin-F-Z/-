# Licensing and ownership notice

**Distribution status: restricted pending IP consolidation.**

This package contains newly prepared code and documentation together with
concepts derived from materials supplied for the QinCert project. It must not be
published, sublicensed, or represented as exclusively owned until:

1. every contributor and contribution is entered in the asset register;
2. background and foreground intellectual property are separated;
3. third-party code and dependencies are recorded with license obligations;
4. written assignments and invention declarations are completed;
5. patent counsel approves the public-disclosure and open-source boundary.

Source files use `LicenseRef-QinCert-Proprietary-Evaluation` as a temporary SPDX
identifier. It is a control marker, not a final commercial license.
