"""Z3 counterexample checks for QinCert rounding properties.

An UNSAT result means no counterexample exists for the stated integer model.
UNKNOWN is a verification failure and exits non-zero.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

try:
    from z3 import If, Ints, Solver, sat, unknown, unsat
except ImportError:
    print("z3-solver is not installed", file=sys.stderr)
    raise SystemExit(2)


def prove(identifier: str, assumptions, bad_property) -> dict:
    solver = Solver()
    solver.add(*assumptions)
    solver.add(bad_property)
    result = solver.check()
    record = {
        "id": identifier,
        "solver_result": str(result),
        "result": "PROVED" if result == unsat else "FAILED",
        "counterexample": None,
    }
    if result == sat:
        record["counterexample"] = {
            declaration.name(): str(solver.model()[declaration])
            for declaration in solver.model().decls()
        }
    if result == unknown:
        record["reason_unknown"] = solver.reason_unknown()
    return record


def main() -> int:
    n, d = Ints("n d")
    q_floor = n / d
    r = n % d
    q_ceil = If(r == 0, q_floor, q_floor + 1)
    q_half_even = If(
        2 * r < d,
        q_floor,
        If(2 * r > d, q_floor + 1, If(q_floor % 2 == 0, q_floor, q_floor + 1)),
    )
    assumptions = [n >= 0, d > 0]
    results = [
        prove(
            "QIN-PROOF-FLOOR-BOUNDS",
            assumptions,
            (q_floor * d > n) | (n >= (q_floor + 1) * d),
        ),
        prove(
            "QIN-PROOF-CEIL-BOUNDS",
            assumptions,
            (q_ceil * d < n) | ((q_ceil - 1) * d >= n),
        ),
        prove(
            "QIN-PROOF-REMAINDER-BOUNDS",
            assumptions,
            (r < 0) | (r >= d),
        ),
        prove(
            "QIN-PROOF-HALF-EVEN-NEAREST",
            assumptions,
            (2 * (q_half_even * d - n) > d)
            | (2 * (n - q_half_even * d) > d),
        ),
        prove(
            "QIN-PROOF-HALF-EVEN-TIE",
            assumptions + [2 * r == d],
            q_half_even % 2 != 0,
        ),
    ]
    output = {"model": "unbounded non-negative integers", "properties": results}
    destination = Path(__file__).resolve().parents[1] / "build" / "z3-results.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))
    return 0 if all(item["result"] == "PROVED" for item in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
