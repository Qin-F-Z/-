# QinCert Suite

QinCert is a proof-oriented financial arithmetic assurance toolkit for smart
contracts. This repository is the reproducible engineering foundation for:

- exact, explicitly rounded fixed-point arithmetic;
- ERC-4626 economic simulation and bounded counterexample search;
- compiler-AST-based Solidity arithmetic analysis;
- machine-verifiable evidence bundles;
- reference contracts, benchmark fixtures, formal properties, and product
  documentation.

## Verification status

The project uses four result states:

- **PROVED**: a named property was discharged by the declared solver under the
  recorded assumptions;
- **TESTED**: an executable test passed in the recorded environment;
- **CONDITIONAL**: the result is valid only under explicit bounds or
  assumptions;
- **UNVERIFIED**: no passing evidence exists.

No report generator is allowed to turn `UNKNOWN`, `TIMEOUT`, missing tools, or
failed checks into a passing result.

See [STATUS.md](STATUS.md) for the exact implementation and validation ledger.

## Quick start

```powershell
.\verify.ps1
```

The wrapper creates a Python 3.12 environment, installs the constrained Python
graph, performs `npm ci` from the lockfile, selects Rust 1.96.0, and then runs
all fail-closed release gates. POSIX hosts use:

```sh
./verify.sh
```

Host execution requires Python 3.12, Node 24.16.0/npm 11.13.0, and rustup.
`Dockerfile` provides the same toolchain in an isolated build context. The
container tags are version-pinned; release CI must additionally record the
resolved base-image digests in the evidence bundle.

After installation, individual commands include:

```powershell
.\.venv\Scripts\python.exe -m qincert math mul-div 10 7 6 --rounding half_even
.\.venv\Scripts\python.exe -m qincert attack --seed-max 6 --donation-max 50 --victim-max 30
.\.venv\Scripts\python.exe -m qincert scan datasets/fixtures/UnsafeRawVault.sol --format sarif
```

## Repository map

- `qincert/math`: signed and EVM-uint256 arithmetic semantics;
- `qincert/vault`: ERC-4626 state model, previews, actions, and attacks;
- `qincert/scanner`: solc AST ingestion and finance-aware rules;
- `qincert/evidence`: canonical evidence, hashing, signing, and verification;
- `contracts`: reference Solidity implementation and Foundry tests;
- `proofs`: Z3 properties with machine-readable results;
- `datasets`: labeled adversarial benchmark fixtures;
- `schemas`: evidence JSON Schema;
- `docs`: product, IP, security, commercial, and operating materials;
- `scripts/verify_all.py`: the only release verification entry point.
- `requirements-constraints.txt`, `.nvmrc`, and `rust-toolchain.toml`: the
  fail-closed toolchain lock surface;
- `Dockerfile`: isolated reproduction image.

## Scope boundary

QinCert is an arithmetic-specialist assurance layer. It does not replace a
complete smart-contract audit and does not claim that a contract is free of all
vulnerabilities. Signed attestations are meaningful only for the exact inputs,
toolchain, properties, assumptions, and validity state recorded in the evidence
bundle.

## License and ownership

The current package is not authorized for public redistribution. Ownership and
licensing must be finalized against the contribution register before any public
release. See [LICENSE_NOTICE.md](LICENSE_NOTICE.md).
