// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

library QinFixed {
    enum Rounding { Down, Up }
    function mulDiv(uint256 a, uint256 b, uint256 d, Rounding)
        internal pure returns (uint256)
    {
        return a * b / d;
    }
}

contract ExplicitPolicyVault {
    uint256 public constant VIRTUAL_ASSETS = 1;
    uint256 public constant VIRTUAL_SHARES = 1_000_000;
    uint256 public totalAssets;
    uint256 public totalSupply;

    function previewDeposit(uint256 assets) public view returns (uint256) {
        return QinFixed.mulDiv(assets, totalSupply + VIRTUAL_SHARES, totalAssets + VIRTUAL_ASSETS, QinFixed.Rounding.Down);
    }
    function previewMint(uint256 shares) public view returns (uint256) {
        return QinFixed.mulDiv(shares, totalAssets + VIRTUAL_ASSETS, totalSupply + VIRTUAL_SHARES, QinFixed.Rounding.Up);
    }
    function previewWithdraw(uint256 assets) public view returns (uint256) {
        return QinFixed.mulDiv(assets, totalSupply + VIRTUAL_SHARES, totalAssets + VIRTUAL_ASSETS, QinFixed.Rounding.Up);
    }
    function previewRedeem(uint256 shares) public view returns (uint256) {
        return QinFixed.mulDiv(shares, totalAssets + VIRTUAL_ASSETS, totalSupply + VIRTUAL_SHARES, QinFixed.Rounding.Down);
    }
    function deposit(uint256 assets) external returns (uint256 shares) {
        shares = previewDeposit(assets);
        require(shares > 0, "zero shares");
        totalAssets += assets;
        totalSupply += shares;
    }
}
