// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract UnsafeRawVault {
    uint256 public totalAssets;
    uint256 public totalSupply;

    function previewDeposit(uint256 assets) public view returns (uint256 shares) {
        if (totalSupply == 0) return assets;
        return assets * totalSupply / totalAssets;
    }

    function previewMint(uint256 shares) public view returns (uint256 assets) {
        if (totalSupply == 0) return shares;
        return shares * totalAssets / totalSupply;
    }

    function previewWithdraw(uint256 assets) public view returns (uint256 shares) {
        if (totalSupply == 0) return assets;
        return assets * totalSupply / totalAssets;
    }

    function previewRedeem(uint256 shares) public view returns (uint256 assets) {
        if (totalSupply == 0) return shares;
        return shares * totalAssets / totalSupply;
    }

    function deposit(uint256 assets) external returns (uint256 shares) {
        shares = previewDeposit(assets);
        totalAssets += assets;
        totalSupply += shares;
    }

    function donate(uint256 assets) external {
        totalAssets += assets;
    }
}
