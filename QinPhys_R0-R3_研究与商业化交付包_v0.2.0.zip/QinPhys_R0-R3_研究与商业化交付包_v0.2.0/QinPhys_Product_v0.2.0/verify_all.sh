#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python3 -m unittest discover -s tests -v
node --test web/tests/*.test.mjs
node tooling/build_static.mjs
python3 -m qinphys run --particles 36 --events 400 --snapshot-stride 4 --out build/verification-evidence.json
python3 -m qinphys verify build/verification-evidence.json
python3 -m qinphys verify-research build/research/qinphys-r1-r3-evidence.json
node tooling/compare_engines.mjs build/verification-evidence.json
printf '%s\n' 'QinPhys v0.2.0 verification: PASS'
