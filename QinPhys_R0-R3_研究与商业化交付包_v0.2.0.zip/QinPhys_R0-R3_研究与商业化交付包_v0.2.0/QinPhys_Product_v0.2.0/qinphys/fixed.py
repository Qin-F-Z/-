"""Integer-only rounding primitives used by the reference engine."""

from __future__ import annotations

from enum import Enum


class Rounding(str, Enum):
    DOWN = "down"
    UP = "up"
    TOWARD_ZERO = "toward_zero"
    AWAY_FROM_ZERO = "away_from_zero"
    HALF_UP = "half_up"
    HALF_EVEN = "half_even"


def _sign(value: int) -> int:
    return -1 if value < 0 else 1


def div_round(numerator: int, denominator: int, mode: Rounding = Rounding.HALF_EVEN) -> int:
    """Divide signed integers with an explicit, platform-independent rounding rule."""
    if denominator == 0:
        raise ZeroDivisionError("division by zero")
    if denominator < 0:
        numerator, denominator = -numerator, -denominator

    sign = _sign(numerator)
    absolute = abs(numerator)
    quotient, remainder = divmod(absolute, denominator)
    if remainder == 0:
        return sign * quotient

    if mode is Rounding.TOWARD_ZERO:
        increment = False
    elif mode is Rounding.AWAY_FROM_ZERO:
        increment = True
    elif mode is Rounding.DOWN:
        increment = sign < 0
    elif mode is Rounding.UP:
        increment = sign > 0
    elif mode is Rounding.HALF_UP:
        increment = remainder * 2 >= denominator
    elif mode is Rounding.HALF_EVEN:
        doubled = remainder * 2
        increment = doubled > denominator or (doubled == denominator and quotient % 2 == 1)
    else:  # pragma: no cover - Enum prevents this through the public API
        raise ValueError(f"unsupported rounding mode: {mode}")
    return sign * (quotient + int(increment))


def ceil_div_nonnegative(numerator: int, denominator: int) -> int:
    if numerator < 0 or denominator <= 0:
        raise ValueError("ceil_div_nonnegative expects numerator >= 0 and denominator > 0")
    return (numerator + denominator - 1) // denominator

