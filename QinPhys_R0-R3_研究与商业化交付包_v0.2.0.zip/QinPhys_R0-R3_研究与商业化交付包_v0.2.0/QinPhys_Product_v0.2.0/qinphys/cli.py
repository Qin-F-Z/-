from __future__ import annotations

import argparse
import json
from pathlib import Path

from .engine import Scenario, run_scenario, verify_evidence
from .fixed import Rounding
from .research import ResearchSuiteConfig, run_research_suite, verify_research_evidence


def _write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="qinphys", description="QinPhys deterministic finite physics and research evidence")
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run", help="run a deterministic hard-disk scenario")
    run.add_argument("--particles", type=int, default=36)
    run.add_argument("--events", type=int, default=400)
    run.add_argument("--seed", type=int, default=20260731)
    run.add_argument("--box-size", type=int, default=120000)
    run.add_argument("--radius", type=int, default=2000)
    run.add_argument("--speed", type=int, default=260)
    run.add_argument("--snapshot-stride", type=int, default=4)
    run.add_argument("--density-bins", type=int, default=8)
    run.add_argument("--rounding", choices=[mode.value for mode in Rounding], default=Rounding.HALF_EVEN.value)
    run.add_argument("--out", type=Path, default=Path("build/qinphys-evidence.json"))

    verify = sub.add_parser("verify", help="verify the hash binding of an evidence JSON file")
    verify.add_argument("evidence", type=Path)

    research = sub.add_parser("research", help="run the R1--R3 research validation suite")
    research.add_argument("--precision-cases", type=int, default=256)
    research.add_argument("--scales", type=int, nargs="+", default=[24, 48, 96])
    research.add_argument("--replicas", type=int, default=6)
    research.add_argument("--horizon-ticks", type=int, default=60000)
    research.add_argument("--seed", type=int, default=20260731)
    research.add_argument("--out", type=Path, default=Path("build/research/qinphys-r1-r3-evidence.json"))

    verify_research = sub.add_parser("verify-research", help="verify a QinPhys R1--R3 evidence package")
    verify_research.add_argument("evidence", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "run":
        scenario = Scenario(
            particle_count=args.particles,
            event_limit=args.events,
            seed=args.seed,
            box_size=args.box_size,
            radius=args.radius,
            speed=args.speed,
            snapshot_stride=args.snapshot_stride,
            density_bins=args.density_bins,
            rounding=Rounding(args.rounding),
        )
        evidence = run_scenario(scenario)
        _write_json(args.out, evidence)
        print(json.dumps({
            "status": "completed",
            "evidence": str(args.out.resolve()),
            "run_hash": evidence["run_hash"],
            "events": evidence["deterministic_core"]["event_count"],
            "runtime_ns": evidence["runtime_observation"]["runtime_ns"],
        }, ensure_ascii=False))
        return 0

    if args.command == "research":
        evidence = run_research_suite(
            ResearchSuiteConfig(
                precision_cases=args.precision_cases,
                target_counts=tuple(args.scales),
                replicas=args.replicas,
                horizon_ticks=args.horizon_ticks,
                seed=args.seed,
            )
        )
        _write_json(args.out, evidence)
        gate = evidence["research_core"]["claim_gate"]
        print(json.dumps({
            "status": "completed",
            "evidence": str(args.out.resolve()),
            "research_hash": evidence["research_hash"],
            "claim_gate": gate,
            "runtime_ns": evidence["runtime_observation"]["runtime_ns"],
        }, ensure_ascii=False))
        return 0

    evidence = json.loads(args.evidence.read_text(encoding="utf-8"))
    if args.command == "verify-research":
        result = verify_research_evidence(evidence)
    else:
        result = verify_evidence(evidence)
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
