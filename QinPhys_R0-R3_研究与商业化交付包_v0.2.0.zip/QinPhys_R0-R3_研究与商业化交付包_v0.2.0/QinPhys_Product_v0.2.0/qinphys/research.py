"""QinPhys R1--R3 research validation pipeline.

The module deliberately separates three things that are often conflated:

* R1 audits the quantized arithmetic against an 80-digit Decimal reference.
* R2 runs finite periodic hard-disk ensembles with an explicit
  Boltzmann--Grad parameter ledger and paper-relevant observables.
* R3 performs conservation gates, uncertainty estimates and finite-scale
  convergence diagnostics.  It is computational assistance, not a proof of a
  kinetic or hydrodynamic limit.

Every output is evidence-bound.  Runtime measurements and host metadata are
outside the research hash.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from decimal import Decimal, ROUND_HALF_EVEN, localcontext
from math import ceil, exp, log, sqrt
from statistics import fmean, stdev
from time import perf_counter_ns
from typing import Any, Iterable

from .canonical import sha256_json
from .fixed import Rounding, div_round

RESEARCH_ENGINE_ID = "qinphys-periodic-ensemble-research/0.2.0"
RESEARCH_SCHEMA_ID = "urn:qinphys:schema:research-evidence:0.2.0"


def _q(value: float, digits: int = 12) -> str:
    """Stable finite-decimal representation used inside hashed evidence."""
    if value == 0:
        return "0"
    return format(value, f".{digits}g")


def _mean_ci95(values: list[float]) -> dict[str, str | int]:
    if not values:
        return {"n": 0, "mean": "nan", "ci95_low": "nan", "ci95_high": "nan"}
    mean = fmean(values)
    half = 0.0 if len(values) == 1 else 1.96 * stdev(values) / sqrt(len(values))
    # All callers summarize non-negative observables; truncate the normal
    # approximation at the admissible boundary instead of printing a negative
    # collision count or error rate.
    return {"n": len(values), "mean": _q(mean), "ci95_low": _q(max(0.0, mean - half)), "ci95_high": _q(mean + half)}


def _percentile(values: list[float], probability: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    position = probability * (len(ordered) - 1)
    lower = int(position)
    upper = min(len(ordered) - 1, lower + 1)
    fraction = position - lower
    return ordered[lower] * (1.0 - fraction) + ordered[upper] * fraction


class XorShift32:
    def __init__(self, seed: int):
        self.state = seed & 0xFFFFFFFF or 0x6D2B79F5

    def next(self) -> int:
        value = self.state
        value ^= (value << 13) & 0xFFFFFFFF
        value ^= value >> 17
        value ^= (value << 5) & 0xFFFFFFFF
        self.state = value & 0xFFFFFFFF
        return self.state

    def uniform(self) -> float:
        return (self.next() + 0.5) / 4294967296.0

    def signed_normal_surrogate(self, sigma: int) -> int:
        # Irwin--Hall finite surrogate: deterministic, zero transcendental use.
        centered = sum(self.uniform() for _ in range(12)) - 6.0
        return int(round(centered * sigma))


@dataclass(frozen=True)
class PrecisionAuditConfig:
    case_count: int = 256
    decimal_precision: int = 80
    diameter: int = 4000
    speed: int = 320
    seed: int = 0x51504A31
    rounding: Rounding = Rounding.HALF_EVEN

    def validate(self) -> None:
        if not 32 <= self.case_count <= 100_000:
            raise ValueError("case_count must be in [32, 100000]")
        if not 50 <= self.decimal_precision <= 256:
            raise ValueError("decimal_precision must be in [50, 256]")
        if self.diameter <= 2 or self.speed <= 2:
            raise ValueError("diameter and speed must exceed two")


def _decimal_collision_time(
    rx: int,
    ry: int,
    vx: int,
    vy: int,
    diameter: int,
    precision: int,
) -> Decimal | None:
    with localcontext() as context:
        context.prec = precision
        a = Decimal(vx * vx + vy * vy)
        b = Decimal(2 * (rx * vx + ry * vy))
        c = Decimal(rx * rx + ry * ry - diameter * diameter)
        if a == 0 or b >= 0:
            return None
        discriminant = b * b - Decimal(4) * a * c
        if discriminant <= 0:
            return None
        return (-b - discriminant.sqrt()) / (Decimal(2) * a)


def _integer_collision_tick(
    rx: int,
    ry: int,
    vx: int,
    vy: int,
    diameter: int,
    rounding: Rounding,
) -> int | None:
    a = vx * vx + vy * vy
    b = 2 * (rx * vx + ry * vy)
    c = rx * rx + ry * ry - diameter * diameter
    if a == 0 or b >= 0:
        return None
    discriminant = b * b - 4 * a * c
    if discriminant <= 0:
        return None
    from math import isqrt

    return max(1, div_round(-b - isqrt(discriminant), 2 * a, rounding))


def run_precision_audit(config: PrecisionAuditConfig = PrecisionAuditConfig()) -> dict[str, Any]:
    config.validate()
    rng = XorShift32(config.seed)
    records: list[dict[str, Any]] = []
    tick_errors: list[float] = []
    phase_errors: list[float] = []
    unclamped_phase_errors: list[float] = []
    agreement = 0
    minimum_tick_clamp_count = 0
    attempts = 0
    while len(records) < config.case_count:
        attempts += 1
        if attempts > config.case_count * 100:
            raise RuntimeError("unable to construct enough colliding audit pairs")
        gap = config.diameter + 1 + rng.next() % (config.diameter * 8)
        impact = int(rng.next() % (2 * config.diameter - 2)) - config.diameter + 1
        rx, ry = -gap, impact
        vx = config.speed // 2 + 1 + rng.next() % config.speed
        vy = int(rng.next() % (config.speed + 1)) - config.speed // 2
        exact = _decimal_collision_time(rx, ry, vx, vy, config.diameter, config.decimal_precision)
        if exact is None or exact <= 0:
            continue
        integer_tick = _integer_collision_tick(rx, ry, vx, vy, config.diameter, config.rounding)
        if integer_tick is None:
            continue
        reference_tick = int(exact.to_integral_value(rounding=ROUND_HALF_EVEN))
        minimum_tick_clamped = reference_tick < 1
        reference_tick = max(1, reference_tick)
        tick_error = integer_tick - reference_tick
        phase_error = abs(Decimal(integer_tick) - exact)
        tick_errors.append(float(abs(tick_error)))
        phase_errors.append(float(phase_error))
        if minimum_tick_clamped:
            minimum_tick_clamp_count += 1
        else:
            unclamped_phase_errors.append(float(phase_error))
        agreement += int(tick_error == 0)
        records.append(
            {
                "case": len(records),
                "state": [rx, ry, vx, vy],
                "reference_time": format(exact, ".30g"),
                "reference_tick": reference_tick,
                "integer_tick": integer_tick,
                "tick_error": tick_error,
                "phase_error_ticks": format(phase_error, ".20g"),
                "minimum_tick_clamped": minimum_tick_clamped,
            }
        )

    summary = {
        "case_count": len(records),
        "decimal_precision": config.decimal_precision,
        "rounding": config.rounding.value,
        "tick_agreement_count": agreement,
        "tick_agreement_rate": _q(agreement / len(records)),
        "minimum_tick_clamp_count": minimum_tick_clamp_count,
        "mean_absolute_tick_error": _q(fmean(tick_errors)),
        "p95_absolute_tick_error": _q(_percentile(tick_errors, 0.95)),
        "max_absolute_tick_error": _q(max(tick_errors)),
        "mean_absolute_phase_error_ticks": _q(fmean(phase_errors)),
        "p95_absolute_phase_error_ticks": _q(_percentile(phase_errors, 0.95)),
        "max_absolute_phase_error_ticks": _q(max(phase_errors)),
        "unclamped_mean_absolute_phase_error_ticks": _q(fmean(unclamped_phase_errors)),
        "unclamped_p95_absolute_phase_error_ticks": _q(_percentile(unclamped_phase_errors, 0.95)),
        "unclamped_max_absolute_phase_error_ticks": _q(max(unclamped_phase_errors)),
    }
    return {"config": {**asdict(config), "rounding": config.rounding.value}, "summary": summary, "cases": records}


@dataclass(frozen=True)
class PeriodicStudyConfig:
    target_counts: tuple[int, ...] = (24, 48, 96)
    replicas: int = 6
    box_size: int = 12_000_000
    boltzmann_grad_alpha_num: int = 1
    boltzmann_grad_alpha_den: int = 2
    horizon_ticks: int = 60_000
    velocity_sigma: int = 180
    density_bins: int = 6
    velocity_bins: int = 9
    seed: int = 20260731
    rounding: Rounding = Rounding.HALF_EVEN
    ensemble_mode: str = "grand_canonical_finite_surrogate"
    max_events: int = 20_000

    def validate(self) -> None:
        if len(self.target_counts) < 3 or any(not 8 <= n <= 256 for n in self.target_counts):
            raise ValueError("target_counts must contain at least three values in [8, 256]")
        if not 3 <= self.replicas <= 64:
            raise ValueError("replicas must be in [3, 64]")
        if self.box_size <= 1000 or self.horizon_ticks <= 0 or self.velocity_sigma <= 0:
            raise ValueError("box_size, horizon_ticks and velocity_sigma must be positive")
        if self.boltzmann_grad_alpha_num <= 0 or self.boltzmann_grad_alpha_den <= 0:
            raise ValueError("Boltzmann--Grad alpha must be positive")
        if self.ensemble_mode not in {"fixed_n", "grand_canonical_finite_surrogate"}:
            raise ValueError("unsupported ensemble mode")


@dataclass(frozen=True)
class PeriodicParticle:
    id: int
    x: int
    y: int
    vx: int
    vy: int

    def state(self) -> list[int]:
        return [self.id, self.x, self.y, self.vx, self.vy]


def _poisson(rng: XorShift32, mean: int) -> int:
    threshold = exp(-mean)
    product = 1.0
    count = 0
    while product > threshold:
        count += 1
        product *= rng.uniform()
    return max(2, count - 1)


def _minimum_image(delta: int, box_size: int) -> int:
    return (delta + box_size // 2) % box_size - box_size // 2


def _initial_periodic_particles(
    target_n: int,
    diameter: int,
    config: PeriodicStudyConfig,
    seed: int,
) -> tuple[list[PeriodicParticle], dict[str, Any]]:
    rng = XorShift32(seed)
    actual_n = target_n if config.ensemble_mode == "fixed_n" else _poisson(rng, target_n)
    positions: list[tuple[int, int]] = []
    rejected = 0
    limit = actual_n * 50_000
    while len(positions) < actual_n and rejected < limit:
        x, y = rng.next() % config.box_size, rng.next() % config.box_size
        valid = True
        for px, py in positions:
            dx = _minimum_image(x - px, config.box_size)
            dy = _minimum_image(y - py, config.box_size)
            if dx * dx + dy * dy <= diameter * diameter:
                valid = False
                break
        if valid:
            positions.append((x, y))
        else:
            rejected += 1
    if len(positions) != actual_n:
        raise RuntimeError("periodic hard-core rejection sampler exhausted")

    particles: list[PeriodicParticle] = []
    for index, (x, y) in enumerate(positions):
        vx = rng.signed_normal_surrogate(config.velocity_sigma)
        vy = rng.signed_normal_surrogate(config.velocity_sigma)
        if vx == 0 and vy == 0:
            vx = 1
        particles.append(PeriodicParticle(index, x, y, vx, vy))
    return particles, {
        "target_particle_count": target_n,
        "actual_particle_count": actual_n,
        "position_rejections": rejected,
        "velocity_law": "12-uniform Irwin-Hall finite Gaussian surrogate",
    }


def _momentum(particles: Iterable[PeriodicParticle]) -> tuple[int, int]:
    return sum(p.vx for p in particles), sum(p.vy for p in particles)


def _energy2(particles: Iterable[PeriodicParticle]) -> int:
    return sum(p.vx * p.vx + p.vy * p.vy for p in particles)


def _advance_periodic(particles: list[PeriodicParticle], ticks: int, box_size: int) -> list[PeriodicParticle]:
    return [
        PeriodicParticle(p.id, (p.x + p.vx * ticks) % box_size, (p.y + p.vy * ticks) % box_size, p.vx, p.vy)
        for p in particles
    ]


def _image_index_range(origin: int, velocity: int, horizon: int, box_size: int) -> range:
    end = origin + velocity * horizon
    low, high = sorted((origin, end))
    start_index = low // box_size - 1
    stop_index = ceil(high / box_size) + 1
    return range(start_index, stop_index + 1)


def _periodic_pair_event(
    a: PeriodicParticle,
    b: PeriodicParticle,
    diameter: int,
    box_size: int,
    horizon: int,
    rounding: Rounding,
) -> int | None:
    relative_x = a.x - b.x
    relative_y = a.y - b.y
    velocity_x = a.vx - b.vx
    velocity_y = a.vy - b.vy
    best: int | None = None
    for image_x in _image_index_range(relative_x, velocity_x, horizon, box_size):
        rx = relative_x - image_x * box_size
        for image_y in _image_index_range(relative_y, velocity_y, horizon, box_size):
            ry = relative_y - image_y * box_size
            tick = _integer_collision_tick(rx, ry, velocity_x, velocity_y, diameter, rounding)
            if tick is None or tick > horizon:
                continue
            if best is None or tick < best:
                best = tick
    return best


def _resolve_periodic_pair(
    a: PeriodicParticle,
    b: PeriodicParticle,
    box_size: int,
    rounding: Rounding,
) -> tuple[PeriodicParticle, PeriodicParticle, int, int, bool]:
    rx = _minimum_image(a.x - b.x, box_size)
    ry = _minimum_image(a.y - b.y, box_size)
    distance2 = rx * rx + ry * ry
    if distance2 == 0:
        rx, ry, distance2 = 1, 0, 1
    relative_dot = (a.vx - b.vx) * rx + (a.vy - b.vy) * ry
    if relative_dot >= 0:
        return a, b, 0, distance2, False
    ideal_x = div_round(relative_dot * rx, distance2, rounding)
    ideal_y = div_round(relative_dot * ry, distance2, rounding)
    before = a.vx * a.vx + a.vy * a.vy + b.vx * b.vx + b.vy * b.vy
    candidates: list[tuple[tuple[int, int, int, int, int], int, int, int]] = []
    for impulse_x in range(ideal_x - 2, ideal_x + 3):
        for impulse_y in range(ideal_y - 2, ideal_y + 3):
            avx, avy = a.vx - impulse_x, a.vy - impulse_y
            bvx, bvy = b.vx + impulse_x, b.vy + impulse_y
            separating = (avx - bvx) * rx + (avy - bvy) * ry
            if separating < 0:
                continue
            after = avx * avx + avy * avy + bvx * bvx + bvy * bvy
            energy_delta = after - before
            ideal_residual = abs(impulse_x * distance2 - relative_dot * rx) + abs(
                impulse_y * distance2 - relative_dot * ry
            )
            score = (abs(energy_delta), ideal_residual, abs(impulse_x) + abs(impulse_y), impulse_x, impulse_y)
            candidates.append((score, impulse_x, impulse_y, energy_delta))
    if candidates:
        _, impulse_x, impulse_y, energy_delta = min(candidates)
    else:
        impulse_x, impulse_y, energy_delta = ideal_x, ideal_y, 0
    return (
        PeriodicParticle(a.id, a.x, a.y, a.vx - impulse_x, a.vy - impulse_y),
        PeriodicParticle(b.id, b.x, b.y, b.vx + impulse_x, b.vy + impulse_y),
        energy_delta,
        distance2,
        True,
    )


def _velocity_histogram(particles: list[PeriodicParticle], bins: int, sigma: int) -> list[int]:
    counts = [0] * (bins * bins)
    extent = max(1, 4 * sigma)
    for particle in particles:
        bx = min(bins - 1, max(0, (particle.vx + extent) * bins // (2 * extent + 1)))
        by = min(bins - 1, max(0, (particle.vy + extent) * bins // (2 * extent + 1)))
        counts[by * bins + bx] += 1
    return counts


def _density_field(particles: list[PeriodicParticle], bins: int, box_size: int) -> list[int]:
    counts = [0] * (bins * bins)
    for particle in particles:
        bx = min(bins - 1, particle.x * bins // box_size)
        by = min(bins - 1, particle.y * bins // box_size)
        counts[by * bins + bx] += 1
    return counts


def _total_variation(first: list[int], second: list[int]) -> float:
    first_total, second_total = sum(first), sum(second)
    if first_total == 0 or second_total == 0:
        return 0.0
    return 0.5 * sum(abs(a / first_total - b / second_total) for a, b in zip(first, second))


def _density_l1_from_uniform(field: list[int]) -> float:
    total = sum(field)
    if total == 0:
        return 0.0
    uniform = 1.0 / len(field)
    return sum(abs(value / total - uniform) for value in field)


def _radial_pair_counts(particles: list[PeriodicParticle], box_size: int, bins: int = 12) -> list[int]:
    counts = [0] * bins
    max_radius = box_size // 2
    for i, first in enumerate(particles):
        for second in particles[i + 1 :]:
            dx = _minimum_image(first.x - second.x, box_size)
            dy = _minimum_image(first.y - second.y, box_size)
            distance = int(sqrt(dx * dx + dy * dy))
            bucket = min(bins - 1, distance * bins // max(1, max_radius))
            counts[bucket] += 1
    return counts


def run_periodic_replica(
    target_n: int,
    replica: int,
    config: PeriodicStudyConfig,
) -> dict[str, Any]:
    alpha_num = config.boltzmann_grad_alpha_num
    alpha_den = config.boltzmann_grad_alpha_den
    diameter = max(3, (config.box_size * alpha_num + target_n * alpha_den // 2) // (target_n * alpha_den))
    seed = (config.seed + target_n * 1_000_003 + replica * 97_409) & 0xFFFFFFFF
    particles, initialization = _initial_periodic_particles(target_n, diameter, config, seed)
    initial_state_hash = f"sha256:{sha256_json([particle.state() for particle in particles])}"
    initial_momentum = _momentum(particles)
    initial_energy2 = _energy2(particles)
    initial_velocity_histogram = _velocity_histogram(particles, config.velocity_bins, config.velocity_sigma)
    initial_density = _density_field(particles, config.density_bins, config.box_size)
    initial_radial = _radial_pair_counts(particles, config.box_size)

    elapsed = 0
    collisions = 0
    tie_buckets = 0
    contact_residual_max = 0
    energy_delta_abs = 0
    while elapsed < config.horizon_ticks and collisions < config.max_events:
        remaining = config.horizon_ticks - elapsed
        best: int | None = None
        events: list[tuple[int, int]] = []
        for i in range(len(particles)):
            for j in range(i + 1, len(particles)):
                tick = _periodic_pair_event(
                    particles[i], particles[j], diameter, config.box_size, remaining, config.rounding
                )
                if tick is None:
                    continue
                if best is None or tick < best:
                    best, events = tick, [(i, j)]
                elif tick == best:
                    events.append((i, j))
        if best is None:
            particles = _advance_periodic(particles, remaining, config.box_size)
            elapsed = config.horizon_ticks
            break
        particles = _advance_periodic(particles, best, config.box_size)
        elapsed += best
        if len(events) > 1:
            tie_buckets += 1
        for i, j in sorted(events):
            first, second, energy_delta, distance2, resolved = _resolve_periodic_pair(
                particles[i], particles[j], config.box_size, config.rounding
            )
            if not resolved:
                continue
            particles[i], particles[j] = first, second
            collisions += 1
            energy_delta_abs += abs(energy_delta)
            contact_residual_max = max(contact_residual_max, abs(distance2 - diameter * diameter))
            if collisions >= config.max_events:
                break

    final_momentum = _momentum(particles)
    final_energy2 = _energy2(particles)
    final_velocity_histogram = _velocity_histogram(particles, config.velocity_bins, config.velocity_sigma)
    final_density = _density_field(particles, config.density_bins, config.box_size)
    final_radial = _radial_pair_counts(particles, config.box_size)
    energy_drift_ratio = abs(final_energy2 - initial_energy2) / max(1, initial_energy2)
    velocity_tv = _total_variation(initial_velocity_histogram, final_velocity_histogram)
    density_shift_tv = _total_variation(initial_density, final_density)
    result_core = {
        "engine": RESEARCH_ENGINE_ID,
        "seed": seed,
        "replica": replica,
        "initialization": initialization,
        "box_size": config.box_size,
        "diameter": diameter,
        "epsilon": _q(diameter / config.box_size),
        "target_boltzmann_grad_product": _q(alpha_num / alpha_den),
        "realized_boltzmann_grad_product": _q(initialization["actual_particle_count"] * diameter / config.box_size),
        "horizon_ticks": config.horizon_ticks,
        "elapsed_ticks": elapsed,
        "collisions": collisions,
        "tie_buckets": tie_buckets,
        "initial_state_hash": initial_state_hash,
        "final_state_hash": f"sha256:{sha256_json([particle.state() for particle in particles])}",
        "initial_momentum": list(initial_momentum),
        "final_momentum": list(final_momentum),
        "initial_energy2": initial_energy2,
        "final_energy2": final_energy2,
        "energy_delta_abs": energy_delta_abs,
        "energy_drift_ratio": _q(energy_drift_ratio),
        "contact_distance2_residual_max": contact_residual_max,
        "contact_relative_residual_max": _q(contact_residual_max / max(1, diameter * diameter)),
        "velocity_histogram_tv": _q(velocity_tv),
        "density_shift_tv": _q(density_shift_tv),
        "initial_density_l1_from_uniform": _q(_density_l1_from_uniform(initial_density)),
        "final_density_l1_from_uniform": _q(_density_l1_from_uniform(final_density)),
        "initial_velocity_histogram": initial_velocity_histogram,
        "final_velocity_histogram": final_velocity_histogram,
        "initial_radial_pair_counts": initial_radial,
        "final_radial_pair_counts": final_radial,
    }
    return {**result_core, "run_hash": f"sha256:{sha256_json(result_core)}"}


def _linear_regression(xs: list[float], ys: list[float]) -> dict[str, str | int]:
    pairs = [(x, y) for x, y in zip(xs, ys) if x > 0 and y > 0]
    if len(pairs) < 2:
        return {"n": len(pairs), "slope": "nan", "intercept": "nan", "r_squared": "nan"}
    log_x = [log(x) for x, _ in pairs]
    log_y = [log(y) for _, y in pairs]
    mean_x, mean_y = fmean(log_x), fmean(log_y)
    denominator = sum((value - mean_x) ** 2 for value in log_x)
    slope = sum((x - mean_x) * (y - mean_y) for x, y in zip(log_x, log_y)) / denominator
    intercept = mean_y - slope * mean_x
    predicted = [intercept + slope * value for value in log_x]
    total = sum((value - mean_y) ** 2 for value in log_y)
    residual = sum((value - fit) ** 2 for value, fit in zip(log_y, predicted))
    r_squared = 1.0 if total == 0 else 1.0 - residual / total
    return {"n": len(pairs), "slope": _q(slope), "intercept": _q(intercept), "r_squared": _q(r_squared)}


def run_periodic_study(config: PeriodicStudyConfig = PeriodicStudyConfig()) -> dict[str, Any]:
    config.validate()
    scale_results: list[dict[str, Any]] = []
    all_momentum_exact = True
    for target_n in config.target_counts:
        replicas = [run_periodic_replica(target_n, replica, config) for replica in range(config.replicas)]
        all_momentum_exact = all_momentum_exact and all(
            result["initial_momentum"] == result["final_momentum"] for result in replicas
        )
        energy = [float(result["energy_drift_ratio"]) for result in replicas]
        velocity_tv = [float(result["velocity_histogram_tv"]) for result in replicas]
        density_tv = [float(result["density_shift_tv"]) for result in replicas]
        contact = [float(result["contact_relative_residual_max"]) for result in replicas]
        actual_counts = [result["initialization"]["actual_particle_count"] for result in replicas]
        scale_results.append(
            {
                "target_particle_count": target_n,
                "epsilon": replicas[0]["epsilon"],
                "diameter": replicas[0]["diameter"],
                "actual_particle_count": _mean_ci95([float(value) for value in actual_counts]),
                "energy_drift_ratio": _mean_ci95(energy),
                "velocity_histogram_tv": _mean_ci95(velocity_tv),
                "density_shift_tv": _mean_ci95(density_tv),
                "contact_relative_residual_max": _mean_ci95(contact),
                "collisions": _mean_ci95([float(result["collisions"]) for result in replicas]),
                "replicas": replicas,
            }
        )

    epsilons = [float(scale["epsilon"]) for scale in scale_results]
    energy_means = [float(scale["energy_drift_ratio"]["mean"]) for scale in scale_results]
    velocity_means = [float(scale["velocity_histogram_tv"]["mean"]) for scale in scale_results]
    density_means = [float(scale["density_shift_tv"]["mean"]) for scale in scale_results]
    contact_means = [float(scale["contact_relative_residual_max"]["mean"]) for scale in scale_results]
    energy_regression = _linear_regression(epsilons, energy_means)
    velocity_regression = _linear_regression(epsilons, velocity_means)
    density_regression = _linear_regression(epsilons, density_means)
    quality_gates = {
        "at_least_three_scales": len(scale_results) >= 3,
        "at_least_three_replicas_per_scale": all(len(scale["replicas"]) >= 3 for scale in scale_results),
        "momentum_conservation_exact": all_momentum_exact,
        "mean_energy_drift_below_0_5_percent": max(energy_means) <= 0.005,
        "mean_contact_relative_residual_below_5_percent": max(contact_means) <= 0.05,
        "regressions_are_computable": all(
            regression["n"] >= 2 for regression in (energy_regression, velocity_regression, density_regression)
        ),
    }
    return {
        "config": {**asdict(config), "target_counts": list(config.target_counts), "rounding": config.rounding.value},
        "paper_alignment": {
            "dimension": 2,
            "domain": "periodic square torus",
            "particle_model": "equal-mass finite hard disks",
            "ensemble": config.ensemble_mode,
            "scaling_ledger": "target N * epsilon = alpha in d=2",
            "observables": [
                "one-particle velocity histogram",
                "coarse density field",
                "radial pair-count proxy",
                "mass/momentum/kinetic-energy moments",
            ],
            "declared_surrogates": [
                "finite target scales replace the N-to-infinity limit",
                "Poisson particle count is conditioned on at least two particles",
                "Irwin-Hall velocities approximate, but do not equal, a smooth Maxwellian",
                "nearest-tick event times and integer impulses replace exact real arithmetic",
                "empirical histograms are diagnostics, not correlation-function convergence proofs",
            ],
        },
        "scales": scale_results,
        "auxiliary_validation": {
            "momentum_conservation_all_replicas": all_momentum_exact,
            "quality_gates": quality_gates,
            "all_engineering_quality_gates_pass": all(quality_gates.values()),
            "energy_drift_loglog_regression": energy_regression,
            "velocity_tv_loglog_regression": velocity_regression,
            "density_tv_loglog_regression": density_regression,
            "interpretation_rule": "A finite fitted slope is descriptive only; it does not prove a limit or identify a theorem rate.",
            "scientific_outcome": "finite-scale diagnostics generated; theorem and fluid-limit claims remain unproved",
        },
    }


@dataclass(frozen=True)
class ResearchSuiteConfig:
    precision_cases: int = 256
    target_counts: tuple[int, ...] = (24, 48, 96)
    replicas: int = 6
    horizon_ticks: int = 60_000
    seed: int = 20260731


def run_research_suite(config: ResearchSuiteConfig = ResearchSuiteConfig()) -> dict[str, Any]:
    started = perf_counter_ns()
    r1 = run_precision_audit(PrecisionAuditConfig(case_count=config.precision_cases, seed=config.seed ^ 0xA51C))
    periodic_config = PeriodicStudyConfig(
        target_counts=config.target_counts,
        replicas=config.replicas,
        horizon_ticks=config.horizon_ticks,
        seed=config.seed,
    )
    r2_r3 = run_periodic_study(periodic_config)
    research_core = {
        "engine": RESEARCH_ENGINE_ID,
        "suite_config": {**asdict(config), "target_counts": list(config.target_counts)},
        "r1_high_precision_audit": r1,
        "r2_paper_aligned_finite_experiments": {
            "paper_alignment": r2_r3["paper_alignment"],
            "config": r2_r3["config"],
            "scales": r2_r3["scales"],
        },
        "r3_computational_auxiliary_validation": r2_r3["auxiliary_validation"],
        "claim_gate": {
            "R0_finite_state_trajectory_hash_replay": "complete",
            "R1_high_precision_statistical_diagnostics": "complete",
            "R2_paper_aligned_experiment_and_observable_pipeline": "complete_with_declared_finite_surrogates",
            "R3_theorem_or_fluid_limit_computational_assistance": "complete_as_diagnostic_pipeline",
            "Deng_Hani_Ma_theorem_reproduced": "no",
            "Boltzmann_Grad_limit_proved": "no",
            "Navier_Stokes_Fourier_or_Euler_limit_proved": "no",
        },
        "epistemic_contract": {
            "valid_meaning_of_complete": "the executable protocol, evidence, diagnostics and failure states are implemented",
            "invalid_inference": "finite numerical agreement implies a mathematical convergence theorem",
            "unknown_and_failed_results_must_remain_visible": True,
        },
    }
    evidence = {
        "$schema": RESEARCH_SCHEMA_ID,
        "evidence_version": "0.2.0",
        "research_hash": f"sha256:{sha256_json(research_core)}",
        "research_core": research_core,
        "runtime_observation": {
            "runtime_ns": perf_counter_ns() - started,
            "implementation": "CPython deterministic finite research reference",
            "excluded_from_research_hash": True,
        },
    }
    return evidence


def verify_research_evidence(evidence: dict[str, Any]) -> dict[str, Any]:
    core = evidence.get("research_core")
    if not isinstance(core, dict):
        return {"valid": False, "reason": "missing research_core"}
    expected = f"sha256:{sha256_json(core)}"
    actual = evidence.get("research_hash")
    nested_failures: list[str] = []
    try:
        scales = core["r2_paper_aligned_finite_experiments"]["scales"]
        for scale in scales:
            for replica in scale["replicas"]:
                run_core = {key: value for key, value in replica.items() if key != "run_hash"}
                if replica.get("run_hash") != f"sha256:{sha256_json(run_core)}":
                    nested_failures.append(f"N={scale['target_particle_count']}/replica={replica.get('replica')}")
    except (KeyError, TypeError):
        nested_failures.append("malformed nested scale evidence")
    return {
        "valid": actual == expected and not nested_failures,
        "expected": expected,
        "actual": actual,
        "nested_failures": nested_failures,
    }
