"""Deterministic 2D hard-disk finite execution baseline.

This is intentionally a quantized numerical model, not an implementation of the
Deng-Hani-Ma convergence proof. Positions and velocities are integers, events
are scheduled on integer time ticks, simultaneous events have a canonical
order, and collision impulses are chosen by a local integer search that keeps
pair momentum exact while minimizing observed kinetic-energy drift.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import isqrt
from time import perf_counter_ns
from typing import Any, Iterable

from .canonical import sha256_json
from .fixed import Rounding, ceil_div_nonnegative, div_round

ENGINE_ID = "qinphys-harddisk-quantized-event/0.1.0"
SCHEMA_ID = "https://qincert.example/schemas/qinphys-evidence-0.1.0.json"


@dataclass(frozen=True)
class Particle:
    id: int
    x: int
    y: int
    vx: int
    vy: int

    def as_dict(self) -> dict[str, int]:
        return {"id": self.id, "x": self.x, "y": self.y, "vx": self.vx, "vy": self.vy}


@dataclass(frozen=True)
class Scenario:
    particle_count: int = 36
    event_limit: int = 400
    seed: int = 20260731
    box_size: int = 120_000
    radius: int = 2_000
    speed: int = 260
    snapshot_stride: int = 4
    density_bins: int = 8
    rounding: Rounding = Rounding.HALF_EVEN

    def validate(self) -> None:
        if not 2 <= self.particle_count <= 144:
            raise ValueError("particle_count must be in [2, 144]")
        if not 1 <= self.event_limit <= 20_000:
            raise ValueError("event_limit must be in [1, 20000]")
        if self.box_size <= 4 * self.radius:
            raise ValueError("box_size must be greater than four radii")
        if self.radius <= 0 or self.speed <= 0:
            raise ValueError("radius and speed must be positive")
        if not 1 <= self.snapshot_stride <= self.event_limit:
            raise ValueError("snapshot_stride must be in [1, event_limit]")
        if not 2 <= self.density_bins <= 32:
            raise ValueError("density_bins must be in [2, 32]")

    def as_dict(self) -> dict[str, Any]:
        return {
            "particle_count": self.particle_count,
            "event_limit": self.event_limit,
            "seed": self.seed,
            "box_size": self.box_size,
            "radius": self.radius,
            "speed": self.speed,
            "snapshot_stride": self.snapshot_stride,
            "density_bins": self.density_bins,
            "rounding": self.rounding.value,
        }


class XorShift32:
    def __init__(self, seed: int):
        self.state = seed & 0xFFFFFFFF or 0x6D2B79F5

    def next(self) -> int:
        value = self.state
        value ^= (value << 13) & 0xFFFFFFFF
        value ^= value >> 17
        value ^= (value << 5) & 0xFFFFFFFF
        self.state = value & 0xFFFFFFFF
        return self.state


def _initial_particles(scenario: Scenario) -> list[Particle]:
    """Create separated lattice positions and exactly zero total momentum."""
    n = scenario.particle_count
    columns = isqrt(n)
    if columns * columns < n:
        columns += 1
    rows = (n + columns - 1) // columns
    usable = scenario.box_size - 2 * scenario.radius
    step_x = usable // columns
    step_y = usable // rows
    if min(step_x, step_y) <= 2 * scenario.radius:
        raise ValueError("particles do not fit without overlap")

    rng = XorShift32(scenario.seed)
    velocities: list[tuple[int, int]] = []
    for _ in range(n // 2):
        vx = int(rng.next() % (2 * scenario.speed + 1)) - scenario.speed
        vy = int(rng.next() % (2 * scenario.speed + 1)) - scenario.speed
        if vx == 0 and vy == 0:
            vx = scenario.speed
        velocities.extend(((vx, vy), (-vx, -vy)))
    if n % 2:
        velocities.append((0, 0))

    # Deterministic Fisher-Yates shuffle avoids visually paired neighbours.
    for i in range(len(velocities) - 1, 0, -1):
        j = rng.next() % (i + 1)
        velocities[i], velocities[j] = velocities[j], velocities[i]

    particles: list[Particle] = []
    for index in range(n):
        row, column = divmod(index, columns)
        x = scenario.radius + step_x // 2 + column * step_x
        y = scenario.radius + step_y // 2 + row * step_y
        vx, vy = velocities[index]
        particles.append(Particle(index, x, y, vx, vy))
    return particles


def _momentum(particles: Iterable[Particle]) -> tuple[int, int]:
    return sum(p.vx for p in particles), sum(p.vy for p in particles)


def _energy2(particles: Iterable[Particle]) -> int:
    return sum(p.vx * p.vx + p.vy * p.vy for p in particles)


def _pair_time(a: Particle, b: Particle, diameter: int, rounding: Rounding) -> int | None:
    rx, ry = a.x - b.x, a.y - b.y
    vx, vy = a.vx - b.vx, a.vy - b.vy
    qa = vx * vx + vy * vy
    qb = 2 * (rx * vx + ry * vy)
    qc = rx * rx + ry * ry - diameter * diameter
    if qa == 0 or qb >= 0:
        return None
    discriminant = qb * qb - 4 * qa * qc
    if discriminant <= 0:
        return None
    # Quantized event time: nearest integer tick to the first real root.
    numerator = -qb - isqrt(discriminant)
    tick = div_round(numerator, 2 * qa, rounding)
    return max(1, tick)


def _wall_time(particle: Particle, scenario: Scenario, axis: str) -> int | None:
    coordinate = particle.x if axis == "x" else particle.y
    velocity = particle.vx if axis == "x" else particle.vy
    lower, upper = scenario.radius, scenario.box_size - scenario.radius
    if velocity > 0:
        return max(1, ceil_div_nonnegative(max(0, upper - coordinate), velocity))
    if velocity < 0:
        return max(1, ceil_div_nonnegative(max(0, coordinate - lower), -velocity))
    return None


def _next_bucket(particles: list[Particle], scenario: Scenario) -> tuple[int, list[tuple[int, int, int, str]]]:
    # Event tuple is (kind_rank, i, j, axis); j=-1 for walls.
    best: int | None = None
    events: list[tuple[int, int, int, str]] = []

    def consider(tick: int | None, event: tuple[int, int, int, str]) -> None:
        nonlocal best, events
        if tick is None:
            return
        if best is None or tick < best:
            best, events = tick, [event]
        elif tick == best:
            events.append(event)

    for particle in particles:
        consider(_wall_time(particle, scenario, "x"), (0, particle.id, -1, "x"))
        consider(_wall_time(particle, scenario, "y"), (1, particle.id, -1, "y"))
    diameter = 2 * scenario.radius
    for i in range(len(particles)):
        for j in range(i + 1, len(particles)):
            consider(_pair_time(particles[i], particles[j], diameter, scenario.rounding), (2, i, j, "pair"))
    if best is None:
        raise RuntimeError("no future event found")
    return best, sorted(events)


def _advance(particles: list[Particle], ticks: int) -> list[Particle]:
    return [Particle(p.id, p.x + p.vx * ticks, p.y + p.vy * ticks, p.vx, p.vy) for p in particles]


def _resolve_wall(particle: Particle, scenario: Scenario, axis: str) -> tuple[Particle, int]:
    lower, upper = scenario.radius, scenario.box_size - scenario.radius
    if axis == "x":
        corrected = min(upper, max(lower, particle.x))
        return Particle(particle.id, corrected, particle.y, -particle.vx, particle.vy), abs(particle.x - corrected)
    corrected = min(upper, max(lower, particle.y))
    return Particle(particle.id, particle.x, corrected, particle.vx, -particle.vy), abs(particle.y - corrected)


def _resolve_pair(a: Particle, b: Particle, rounding: Rounding) -> tuple[Particle, Particle, int, int]:
    rx, ry = a.x - b.x, a.y - b.y
    distance2 = rx * rx + ry * ry
    if distance2 == 0:
        # Deterministic fallback normal; invalid geometries remain auditable.
        rx, ry, distance2 = 1, 0, 1
    relative_dot = (a.vx - b.vx) * rx + (a.vy - b.vy) * ry
    if relative_dot >= 0:
        return a, b, 0, distance2

    ideal_x = div_round(relative_dot * rx, distance2, rounding)
    ideal_y = div_round(relative_dot * ry, distance2, rounding)
    before = a.vx * a.vx + a.vy * a.vy + b.vx * b.vx + b.vy * b.vy
    candidates: list[tuple[tuple[int, int, int, int, int], tuple[int, int, int]]] = []
    for impulse_x in range(ideal_x - 2, ideal_x + 3):
        for impulse_y in range(ideal_y - 2, ideal_y + 3):
            avx, avy = a.vx - impulse_x, a.vy - impulse_y
            bvx, bvy = b.vx + impulse_x, b.vy + impulse_y
            separating = (avx - bvx) * rx + (avy - bvy) * ry
            if separating < 0:
                continue
            after = avx * avx + avy * avy + bvx * bvx + bvy * bvy
            energy_delta = after - before
            ideal_residual = abs(impulse_x * distance2 - relative_dot * rx) + abs(
                impulse_y * distance2 - relative_dot * ry
            )
            score = (abs(energy_delta), ideal_residual, abs(impulse_x) + abs(impulse_y), impulse_x, impulse_y)
            candidates.append((score, (impulse_x, impulse_y, energy_delta)))
    if not candidates:
        impulse_x, impulse_y = ideal_x, ideal_y
        energy_delta = 0
    else:
        _, (impulse_x, impulse_y, energy_delta) = min(candidates)

    return (
        Particle(a.id, a.x, a.y, a.vx - impulse_x, a.vy - impulse_y),
        Particle(b.id, b.x, b.y, b.vx + impulse_x, b.vy + impulse_y),
        energy_delta,
        distance2,
    )


def _snapshot(particles: list[Particle], event_count: int, ticks: int) -> dict[str, Any]:
    return {
        "event_count": event_count,
        "ticks": ticks,
        "particles": [[p.x, p.y, p.vx, p.vy] for p in particles],
    }


def _density(particles: list[Particle], scenario: Scenario) -> list[int]:
    bins = scenario.density_bins
    counts = [0] * (bins * bins)
    for particle in particles:
        bx = min(bins - 1, particle.x * bins // scenario.box_size)
        by = min(bins - 1, particle.y * bins // scenario.box_size)
        counts[by * bins + bx] += 1
    return counts


def run_scenario(scenario: Scenario) -> dict[str, Any]:
    scenario.validate()
    started = perf_counter_ns()
    particles = _initial_particles(scenario)
    initial_particles = [p.as_dict() for p in particles]
    initial_momentum = _momentum(particles)
    initial_energy2 = _energy2(particles)
    total_ticks = 0
    event_count = 0
    pair_collisions = 0
    wall_collisions = 0
    tie_buckets = 0
    pair_energy_delta_abs = 0
    boundary_impulse_x = 0
    boundary_impulse_y = 0
    wall_position_correction_max = 0
    contact_distance2_residual_max = 0
    snapshots = [_snapshot(particles, 0, 0)]

    while event_count < scenario.event_limit:
        delta_ticks, bucket = _next_bucket(particles, scenario)
        particles = _advance(particles, delta_ticks)
        total_ticks += delta_ticks
        if len(bucket) > 1:
            tie_buckets += 1
        for kind_rank, i, j, axis in bucket:
            if event_count >= scenario.event_limit:
                break
            if kind_rank < 2:
                before_wall = particles[i]
                particles[i], correction = _resolve_wall(particles[i], scenario, axis)
                boundary_impulse_x += particles[i].vx - before_wall.vx
                boundary_impulse_y += particles[i].vy - before_wall.vy
                wall_position_correction_max = max(wall_position_correction_max, correction)
                wall_collisions += 1
            else:
                new_a, new_b, energy_delta, distance2 = _resolve_pair(particles[i], particles[j], scenario.rounding)
                if new_a == particles[i] and new_b == particles[j]:
                    continue
                particles[i], particles[j] = new_a, new_b
                pair_collisions += 1
                pair_energy_delta_abs += abs(energy_delta)
                contact_distance2_residual_max = max(
                    contact_distance2_residual_max,
                    abs(distance2 - (2 * scenario.radius) ** 2),
                )
            event_count += 1
        if event_count % scenario.snapshot_stride == 0 or event_count >= scenario.event_limit:
            snapshots.append(_snapshot(particles, event_count, total_ticks))

    final_momentum = _momentum(particles)
    final_energy2 = _energy2(particles)
    runtime_ns = perf_counter_ns() - started
    final_state = [p.as_dict() for p in particles]
    deterministic_core = {
        "engine": ENGINE_ID,
        "scenario": scenario.as_dict(),
        "initial_state": initial_particles,
        "final_state": final_state,
        "event_count": event_count,
        "total_ticks": total_ticks,
        "pair_collisions": pair_collisions,
        "wall_collisions": wall_collisions,
        "tie_buckets": tie_buckets,
        "initial_momentum": list(initial_momentum),
        "final_momentum": list(final_momentum),
        "boundary_impulse": [boundary_impulse_x, boundary_impulse_y],
        "initial_energy2": initial_energy2,
        "final_energy2": final_energy2,
        "pair_energy_delta_abs": pair_energy_delta_abs,
        "wall_position_correction_max": wall_position_correction_max,
        "contact_distance2_residual_max": contact_distance2_residual_max,
        "density": _density(particles, scenario),
    }
    run_hash = sha256_json(deterministic_core)
    return {
        "$schema": SCHEMA_ID,
        "evidence_version": "0.1.0",
        "run_hash": f"sha256:{run_hash}",
        "deterministic_core": deterministic_core,
        "snapshots": snapshots,
        "runtime_observation": {
            "runtime_ns": runtime_ns,
            "implementation": "CPython integer reference",
            "excluded_from_run_hash": True,
        },
        "claim_status": {
            "finite_2d_quantized_hard_disk_execution": "implemented",
            "same_engine_same_input_replay": "tested",
            "pair_momentum_conservation": "implemented_by_equal-and-opposite-integer-impulse",
            "total_momentum_balance_with_wall_impulse": "checked_exact_for_this_run",
            "kinetic_energy_conservation": "observed_not_guaranteed",
            "boltzmann_limit": "not_established",
            "navier_stokes_fourier_limit": "not_established",
            "deng_hani_ma_theorem_reproduction": "not_reproduced",
        },
        "model_contract": {
            "continuous_source": "equal-mass free flight with elastic hard-disk contact",
            "finite_execution": "integer positions/velocities; nearest-tick event scheduling; canonical tie order",
            "rounding": scenario.rounding.value,
            "time_quantum_ticks": 1,
            "known_limitations": [
                "A finite trajectory is not the Boltzmann-Grad limit.",
                "Nearest-tick contact scheduling introduces phase/contact residuals.",
                "Integer impulse selection preserves pair momentum but does not guarantee exact kinetic energy.",
                "Sequential canonical handling of simultaneous contacts is a declared modeling rule.",
            ],
        },
    }


def verify_evidence(evidence: dict[str, Any]) -> dict[str, Any]:
    core = evidence.get("deterministic_core")
    if not isinstance(core, dict):
        return {"valid": False, "reason": "missing deterministic_core"}
    expected = f"sha256:{sha256_json(core)}"
    actual = evidence.get("run_hash")
    return {"valid": actual == expected, "expected": expected, "actual": actual}
