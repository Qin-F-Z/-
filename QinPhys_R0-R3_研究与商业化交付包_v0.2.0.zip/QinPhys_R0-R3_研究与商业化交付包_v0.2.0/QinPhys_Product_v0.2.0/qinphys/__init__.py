"""QinPhys deterministic finite-computation and research evidence engine."""

from .engine import ENGINE_ID, Scenario, run_scenario
from .research import RESEARCH_ENGINE_ID, ResearchSuiteConfig, run_research_suite

__all__ = [
    "ENGINE_ID",
    "RESEARCH_ENGINE_ID",
    "Scenario",
    "ResearchSuiteConfig",
    "run_scenario",
    "run_research_suite",
]
__version__ = "0.2.0"
