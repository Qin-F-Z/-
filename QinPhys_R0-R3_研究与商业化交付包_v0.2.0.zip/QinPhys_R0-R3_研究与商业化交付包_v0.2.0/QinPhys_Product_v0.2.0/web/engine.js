export const ENGINE_ID = "qinphys-harddisk-quantized-event/0.1.0";
export const SCHEMA_ID = "https://qincert.example/schemas/qinphys-evidence-0.1.0.json";

const B = BigInt;

export const Rounding = Object.freeze({
  DOWN: "down",
  UP: "up",
  TOWARD_ZERO: "toward_zero",
  AWAY_FROM_ZERO: "away_from_zero",
  HALF_UP: "half_up",
  HALF_EVEN: "half_even",
});

export function divRound(numerator, denominator, mode = Rounding.HALF_EVEN) {
  numerator = B(numerator);
  denominator = B(denominator);
  if (denominator === 0n) throw new Error("division by zero");
  if (denominator < 0n) {
    numerator = -numerator;
    denominator = -denominator;
  }
  const sign = numerator < 0n ? -1n : 1n;
  const absolute = numerator < 0n ? -numerator : numerator;
  const quotient = absolute / denominator;
  const remainder = absolute % denominator;
  if (remainder === 0n) return sign * quotient;
  let increment;
  switch (mode) {
    case Rounding.TOWARD_ZERO: increment = false; break;
    case Rounding.AWAY_FROM_ZERO: increment = true; break;
    case Rounding.DOWN: increment = sign < 0n; break;
    case Rounding.UP: increment = sign > 0n; break;
    case Rounding.HALF_UP: increment = remainder * 2n >= denominator; break;
    case Rounding.HALF_EVEN: {
      const doubled = remainder * 2n;
      increment = doubled > denominator || (doubled === denominator && quotient % 2n === 1n);
      break;
    }
    default: throw new Error(`unsupported rounding mode: ${mode}`);
  }
  return sign * (quotient + (increment ? 1n : 0n));
}

function isqrt(value) {
  value = B(value);
  if (value < 0n) throw new Error("isqrt of negative value");
  if (value < 2n) return value;
  let x0 = 1n << (B(value.toString(2).length) + 1n >> 1n);
  let x1 = (x0 + value / x0) >> 1n;
  while (x1 < x0) {
    x0 = x1;
    x1 = (x0 + value / x0) >> 1n;
  }
  return x0;
}

function ceilDivNonnegative(numerator, denominator) {
  numerator = B(numerator); denominator = B(denominator);
  if (numerator < 0n || denominator <= 0n) throw new Error("invalid ceil division");
  return (numerator + denominator - 1n) / denominator;
}

class XorShift32 {
  constructor(seed) { this.state = (seed >>> 0) || 0x6d2b79f5; }
  next() {
    let value = this.state >>> 0;
    value = (value ^ ((value << 13) >>> 0)) >>> 0;
    value = (value ^ (value >>> 17)) >>> 0;
    value = (value ^ ((value << 5) >>> 0)) >>> 0;
    this.state = value >>> 0;
    return this.state;
  }
}

export function normalizeScenario(input = {}) {
  const scenario = {
    particle_count: Number(input.particle_count ?? 36),
    event_limit: Number(input.event_limit ?? 400),
    seed: Number(input.seed ?? 20260731),
    box_size: Number(input.box_size ?? 120000),
    radius: Number(input.radius ?? 2000),
    speed: Number(input.speed ?? 260),
    snapshot_stride: Number(input.snapshot_stride ?? 4),
    density_bins: Number(input.density_bins ?? 8),
    rounding: input.rounding ?? Rounding.HALF_EVEN,
  };
  if (scenario.particle_count < 2 || scenario.particle_count > 144) throw new Error("粒子数必须在 2–144 之间");
  if (scenario.event_limit < 1 || scenario.event_limit > 20000) throw new Error("事件数必须在 1–20000 之间");
  if (scenario.box_size <= 4 * scenario.radius) throw new Error("盒长必须大于四倍半径");
  if (scenario.radius <= 0 || scenario.speed <= 0) throw new Error("半径和速度必须为正数");
  if (scenario.snapshot_stride < 1 || scenario.snapshot_stride > scenario.event_limit) throw new Error("快照步长无效");
  if (scenario.density_bins < 2 || scenario.density_bins > 32) throw new Error("密度网格必须在 2–32 之间");
  if (!Object.values(Rounding).includes(scenario.rounding)) throw new Error("舍入模式无效");
  return scenario;
}

function particle(id, x, y, vx, vy) { return {id, x:B(x), y:B(y), vx:B(vx), vy:B(vy)}; }
function particleDict(p) { return {id:p.id, x:Number(p.x), y:Number(p.y), vx:Number(p.vx), vy:Number(p.vy)}; }

function initialParticles(scenario) {
  const n = scenario.particle_count;
  let columns = Math.floor(Math.sqrt(n));
  if (columns * columns < n) columns += 1;
  const rows = Math.ceil(n / columns);
  const usable = B(scenario.box_size - 2 * scenario.radius);
  const stepX = usable / B(columns), stepY = usable / B(rows);
  if ((stepX < stepY ? stepX : stepY) <= B(2 * scenario.radius)) throw new Error("粒子在初始状态会重叠");
  const rng = new XorShift32(scenario.seed);
  const velocities = [];
  for (let i=0; i<Math.floor(n/2); i++) {
    let vx = (rng.next() % (2 * scenario.speed + 1)) - scenario.speed;
    let vy = (rng.next() % (2 * scenario.speed + 1)) - scenario.speed;
    if (vx === 0 && vy === 0) vx = scenario.speed;
    velocities.push([vx,vy],[-vx,-vy]);
  }
  if (n % 2) velocities.push([0,0]);
  for (let i=velocities.length-1; i>0; i--) {
    const j = rng.next() % (i+1);
    [velocities[i], velocities[j]] = [velocities[j], velocities[i]];
  }
  const particles = [];
  for (let index=0; index<n; index++) {
    const row = Math.floor(index / columns), column = index % columns;
    const x = B(scenario.radius) + stepX/2n + B(column)*stepX;
    const y = B(scenario.radius) + stepY/2n + B(row)*stepY;
    particles.push(particle(index,x,y,velocities[index][0],velocities[index][1]));
  }
  return particles;
}

function momentum(particles) { return particles.reduce((a,p)=>[a[0]+p.vx,a[1]+p.vy],[0n,0n]); }
function energy2(particles) { return particles.reduce((a,p)=>a+p.vx*p.vx+p.vy*p.vy,0n); }

function pairTime(a,b,diameter,rounding) {
  const rx=a.x-b.x, ry=a.y-b.y, vx=a.vx-b.vx, vy=a.vy-b.vy;
  const qa=vx*vx+vy*vy, qb=2n*(rx*vx+ry*vy), qc=rx*rx+ry*ry-diameter*diameter;
  if (qa===0n || qb>=0n) return null;
  const discriminant=qb*qb-4n*qa*qc;
  if (discriminant<=0n) return null;
  const tick=divRound(-qb-isqrt(discriminant),2n*qa,rounding);
  return tick < 1n ? 1n : tick;
}

function wallTime(p,scenario,axis) {
  const coordinate=axis==="x"?p.x:p.y, velocity=axis==="x"?p.vx:p.vy;
  const lower=B(scenario.radius), upper=B(scenario.box_size-scenario.radius);
  if (velocity>0n) return [1n,ceilDivNonnegative(upper>coordinate?upper-coordinate:0n,velocity)].reduce((a,b)=>a>b?a:b);
  if (velocity<0n) return [1n,ceilDivNonnegative(coordinate>lower?coordinate-lower:0n,-velocity)].reduce((a,b)=>a>b?a:b);
  return null;
}

function nextBucket(particles,scenario) {
  let best=null, events=[];
  const consider=(tick,event)=>{
    if (tick===null) return;
    if (best===null || tick<best) { best=tick; events=[event]; }
    else if (tick===best) events.push(event);
  };
  for (const p of particles) {
    consider(wallTime(p,scenario,"x"),[0,p.id,-1,"x"]);
    consider(wallTime(p,scenario,"y"),[1,p.id,-1,"y"]);
  }
  const diameter=B(2*scenario.radius);
  for (let i=0;i<particles.length;i++) for(let j=i+1;j<particles.length;j++) {
    consider(pairTime(particles[i],particles[j],diameter,scenario.rounding),[2,i,j,"pair"]);
  }
  if (best===null) throw new Error("没有未来事件");
  events.sort((a,b)=>a[0]-b[0]||a[1]-b[1]||a[2]-b[2]||a[3].localeCompare(b[3]));
  return [best,events];
}

function advance(particles,ticks) { return particles.map(p=>particle(p.id,p.x+p.vx*ticks,p.y+p.vy*ticks,p.vx,p.vy)); }

function resolveWall(p,scenario,axis) {
  const lower=B(scenario.radius), upper=B(scenario.box_size-scenario.radius);
  if(axis==="x") {
    const corrected=p.x<lower?lower:(p.x>upper?upper:p.x);
    return [particle(p.id,corrected,p.y,-p.vx,p.vy), p.x>corrected?p.x-corrected:corrected-p.x];
  }
  const corrected=p.y<lower?lower:(p.y>upper?upper:p.y);
  return [particle(p.id,p.x,corrected,p.vx,-p.vy), p.y>corrected?p.y-corrected:corrected-p.y];
}

function absB(v){return v<0n?-v:v;}

function resolvePair(a,b,rounding) {
  let rx=a.x-b.x, ry=a.y-b.y, distance2=rx*rx+ry*ry;
  if(distance2===0n){rx=1n;ry=0n;distance2=1n;}
  const relativeDot=(a.vx-b.vx)*rx+(a.vy-b.vy)*ry;
  if(relativeDot>=0n) return [a,b,0n,distance2,false];
  const idealX=divRound(relativeDot*rx,distance2,rounding), idealY=divRound(relativeDot*ry,distance2,rounding);
  const before=a.vx*a.vx+a.vy*a.vy+b.vx*b.vx+b.vy*b.vy;
  let best=null;
  for(let dx=-2n;dx<=2n;dx++) for(let dy=-2n;dy<=2n;dy++) {
    const ix=idealX+dx, iy=idealY+dy;
    const avx=a.vx-ix, avy=a.vy-iy, bvx=b.vx+ix, bvy=b.vy+iy;
    const separating=(avx-bvx)*rx+(avy-bvy)*ry;
    if(separating<0n) continue;
    const after=avx*avx+avy*avy+bvx*bvx+bvy*bvy;
    const energyDelta=after-before;
    const idealResidual=absB(ix*distance2-relativeDot*rx)+absB(iy*distance2-relativeDot*ry);
    const score=[absB(energyDelta),idealResidual,absB(ix)+absB(iy),ix,iy];
    if(best===null || compareTuple(score,best.score)<0) best={score,ix,iy,energyDelta};
  }
  const ix=best?.ix??idealX, iy=best?.iy??idealY, energyDelta=best?.energyDelta??0n;
  return [particle(a.id,a.x,a.y,a.vx-ix,a.vy-iy),particle(b.id,b.x,b.y,b.vx+ix,b.vy+iy),energyDelta,distance2,true];
}

function compareTuple(a,b){for(let i=0;i<a.length;i++){if(a[i]<b[i])return-1;if(a[i]>b[i])return 1;}return 0;}
function snapshot(particles,eventCount,ticks){return{event_count:eventCount,ticks:Number(ticks),particles:particles.map(p=>[Number(p.x),Number(p.y),Number(p.vx),Number(p.vy)])};}
function density(particles,scenario){const bins=scenario.density_bins,counts=Array(bins*bins).fill(0);for(const p of particles){const bx=Math.min(bins-1,Math.floor(Number(p.x)*bins/scenario.box_size));const by=Math.min(bins-1,Math.floor(Number(p.y)*bins/scenario.box_size));counts[by*bins+bx]++;}return counts;}

export function canonicalJson(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  return `{${Object.keys(value).sort().map(k=>`${JSON.stringify(k)}:${canonicalJson(value[k])}`).join(",")}}`;
}

async function sha256(text) {
  const bytes=new TextEncoder().encode(text);
  if(globalThis.crypto?.subtle){const digest=await globalThis.crypto.subtle.digest("SHA-256",bytes);return [...new Uint8Array(digest)].map(v=>v.toString(16).padStart(2,"0")).join("");}
  const {createHash}=await import("node:crypto");return createHash("sha256").update(bytes).digest("hex");
}

export async function runScenario(input={}) {
  const scenario=normalizeScenario(input), started=globalThis.performance?.now?.()??Date.now();
  let particles=initialParticles(scenario);
  const initialState=particles.map(particleDict), initialMomentum=momentum(particles), initialEnergy2=energy2(particles);
  let totalTicks=0n,eventCount=0,pairCollisions=0,wallCollisions=0,tieBuckets=0;
  let pairEnergyDeltaAbs=0n,boundaryImpulseX=0n,boundaryImpulseY=0n,wallCorrectionMax=0n,contactResidualMax=0n;
  const snapshots=[snapshot(particles,0,0n)];
  while(eventCount<scenario.event_limit){
    const [deltaTicks,bucket]=nextBucket(particles,scenario);particles=advance(particles,deltaTicks);totalTicks+=deltaTicks;if(bucket.length>1)tieBuckets++;
    for(const [kindRank,i,j,axis] of bucket){if(eventCount>=scenario.event_limit)break;if(kindRank<2){const before=particles[i];const [after,correction]=resolveWall(before,scenario,axis);particles[i]=after;boundaryImpulseX+=after.vx-before.vx;boundaryImpulseY+=after.vy-before.vy;if(correction>wallCorrectionMax)wallCorrectionMax=correction;wallCollisions++;}else{const [a,b,delta,distance2,resolved]=resolvePair(particles[i],particles[j],scenario.rounding);if(!resolved)continue;particles[i]=a;particles[j]=b;pairCollisions++;pairEnergyDeltaAbs+=absB(delta);const residual=absB(distance2-B(2*scenario.radius)**2n);if(residual>contactResidualMax)contactResidualMax=residual;}eventCount++;}
    if(eventCount%scenario.snapshot_stride===0||eventCount>=scenario.event_limit)snapshots.push(snapshot(particles,eventCount,totalTicks));
  }
  const finalMomentum=momentum(particles),finalEnergy2=energy2(particles);
  const core={engine:ENGINE_ID,scenario,initial_state:initialState,final_state:particles.map(particleDict),event_count:eventCount,total_ticks:Number(totalTicks),pair_collisions:pairCollisions,wall_collisions:wallCollisions,tie_buckets:tieBuckets,initial_momentum:initialMomentum.map(Number),final_momentum:finalMomentum.map(Number),boundary_impulse:[Number(boundaryImpulseX),Number(boundaryImpulseY)],initial_energy2:Number(initialEnergy2),final_energy2:Number(finalEnergy2),pair_energy_delta_abs:Number(pairEnergyDeltaAbs),wall_position_correction_max:Number(wallCorrectionMax),contact_distance2_residual_max:Number(contactResidualMax),density:density(particles,scenario)};
  const runHash=await sha256(canonicalJson(core));
  return {$schema:SCHEMA_ID,evidence_version:"0.1.0",run_hash:`sha256:${runHash}`,deterministic_core:core,snapshots,runtime_observation:{runtime_ms:(globalThis.performance?.now?.()??Date.now())-started,implementation:"JavaScript BigInt browser reference",excluded_from_run_hash:true},claim_status:{finite_2d_quantized_hard_disk_execution:"implemented",same_engine_same_input_replay:"tested",pair_momentum_conservation:"implemented_by_equal-and-opposite-integer-impulse",total_momentum_balance_with_wall_impulse:"checked_exact_for_this_run",kinetic_energy_conservation:"observed_not_guaranteed",boltzmann_limit:"not_established",navier_stokes_fourier_limit:"not_established",deng_hani_ma_theorem_reproduction:"not_reproduced"},model_contract:{continuous_source:"equal-mass free flight with elastic hard-disk contact",finite_execution:"integer positions/velocities; nearest-tick event scheduling; canonical tie order",rounding:scenario.rounding,time_quantum_ticks:1,known_limitations:["A finite trajectory is not the Boltzmann-Grad limit.","Nearest-tick contact scheduling introduces phase/contact residuals.","Integer impulse selection preserves pair momentum but does not guarantee exact kinetic energy.","Sequential canonical handling of simultaneous contacts is a declared modeling rule."]}};
}

export async function verifyEvidence(evidence){if(!evidence?.deterministic_core)return{valid:false,reason:"missing deterministic_core"};const expected=`sha256:${await sha256(canonicalJson(evidence.deterministic_core))}`;return{valid:evidence.run_hash===expected,expected,actual:evidence.run_hash};}

