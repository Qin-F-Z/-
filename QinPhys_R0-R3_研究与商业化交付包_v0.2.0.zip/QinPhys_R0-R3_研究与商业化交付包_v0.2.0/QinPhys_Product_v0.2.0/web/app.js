import {runScenario,verifyEvidence} from "./engine.js";
import {RESEARCH_SUMMARY} from "./research-data.js";

const $=id=>document.getElementById(id);
const state={evidence:null,frame:0,timer:null,running:false};
const presets={light:{particle_count:16,event_limit:120,snapshot_stride:2},standard:{particle_count:36,event_limit:400,snapshot_stride:4},stress:{particle_count:100,event_limit:5000,snapshot_stride:25}};

document.querySelectorAll(".tab").forEach(button=>button.addEventListener("click",()=>switchView(button.dataset.view)));
function switchView(id){document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.view===id));document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id===id));if(id==="simulate")drawFrame();}

function getScenario(){return{particle_count:+$("particles").value,event_limit:+$("events").value,seed:+$("seed").value,box_size:+$("boxSize").value,radius:+$("radius").value,speed:+$("speed").value,snapshot_stride:Math.max(1,Math.ceil(+$("events").value/100)),density_bins:+$("densityBins").value,rounding:$("rounding").value};}
function setScenario(spec){$("particles").value=spec.particle_count;$("events").value=spec.event_limit;$("particleOut").value=spec.particle_count;$("eventOut").value=spec.event_limit;}

$("particles").addEventListener("input",()=>$("particleOut").value=$("particles").value);
$("events").addEventListener("input",()=>$("eventOut").value=$("events").value);
document.querySelectorAll("[data-preset]").forEach(button=>button.addEventListener("click",()=>{document.querySelectorAll("[data-preset]").forEach(b=>b.classList.toggle("selected",b===button));setScenario(presets[button.dataset.preset]);}));

function message(text,type=""){$("runMessage").textContent=text;$("runMessage").className=`message ${type}`;}
function fmt(value){return new Intl.NumberFormat("zh-CN").format(value);}
function pct(delta,base){if(!base)return"0";return`${delta>=0?"+":""}${(delta/base*100).toFixed(5)}%`;}

async function execute({replay=false}={}){
  if(state.running)return;state.running=true;$("runButton").disabled=true;$("replayButton").disabled=true;message(replay?"正在执行两次独立回放…":"正在执行整数事件计算…");
  try{
    const spec=getScenario();
    const first=await runScenario(spec);
    if(replay){const second=await runScenario(spec);if(first.run_hash!==second.run_hash)throw new Error("双重回放哈希不一致");message(`双重回放一致：${first.run_hash.slice(7,23)}…`,"ok");}
    else message(`完成 · ${first.deterministic_core.event_count} 个事件`,"ok");
    state.evidence=first;state.frame=0;renderEvidence();
  }catch(error){console.error(error);message(error.message||String(error),"error");}
  finally{state.running=false;$("runButton").disabled=false;$("replayButton").disabled=false;}
}

$("runButton").addEventListener("click",()=>execute());
$("replayButton").addEventListener("click",()=>execute({replay:true}));

function renderEvidence(){const e=state.evidence,c=e.deterministic_core;$("hashMetric").textContent=e.run_hash.slice(7,23)+"…";$("hashMetric").title=e.run_hash;$("eventMetric").textContent=fmt(c.event_count);$("tickMetric").textContent=`${fmt(c.total_ticks)} ticks`;const momentumOk=c.final_momentum[0]===c.initial_momentum[0]+c.boundary_impulse[0]&&c.final_momentum[1]===c.initial_momentum[1]+c.boundary_impulse[1];$("momentumMetric").textContent=momentumOk?"EXACT":"FAIL";$("momentumMetric").style.color=momentumOk?"var(--lime)":"var(--red)";const energyDelta=c.final_energy2-c.initial_energy2;$("energyMetric").textContent=pct(energyDelta,c.initial_energy2);$("runtimeMetric").textContent=`${e.runtime_observation.runtime_ms.toFixed(1)} ms`;$("hardwareMetric").textContent=`${navigator.hardwareConcurrency||"?"} logical cores / 1 thread`;$("contactResidual").textContent=fmt(c.contact_distance2_residual_max);$("wallCorrection").textContent=fmt(c.wall_position_correction_max);$("tieBuckets").textContent=fmt(c.tie_buckets);$("verifyStatus").textContent="已生成，待校验";$("exportButton").disabled=false;$("verifyButton").disabled=false;$("simEvents").textContent=fmt(c.event_count);$("timeline").max=e.snapshots.length-1;$("timeline").value=0;document.querySelector("#claimTable .wait").textContent="已通过";document.querySelector("#claimTable .wait").className="ok";drawFrame();}

$("exportButton").addEventListener("click",()=>{if(!state.evidence)return;const blob=new Blob([JSON.stringify(state.evidence,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`QinPhys-evidence-${state.evidence.run_hash.slice(7,19)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);});
$("verifyButton").addEventListener("click",async()=>{if(!state.evidence)return;$("verifyStatus").textContent="校验中…";const result=await verifyEvidence(state.evidence);$("verifyStatus").textContent=result.valid?"VALID · 哈希绑定有效":"INVALID · 证据已变化";$("verifyStatus").style.color=result.valid?"var(--lime)":"var(--red)";});

function currentSnapshot(){return state.evidence?.snapshots[state.frame]??null;}
function drawFrame(){const canvas=$("simCanvas"),ctx=canvas.getContext("2d"),snap=currentSnapshot();ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle="#050c0b";ctx.fillRect(0,0,canvas.width,canvas.height);drawGrid(ctx,canvas);if(!snap){ctx.fillStyle="#72867f";ctx.font="16px Segoe UI";ctx.textAlign="center";ctx.fillText("请先在计算台执行一次运行",canvas.width/2,canvas.height/2);return;}const s=state.evidence.deterministic_core.scenario,scale=Math.min(canvas.width,canvas.height)/s.box_size,ox=(canvas.width-s.box_size*scale)/2,oy=(canvas.height-s.box_size*scale)/2;ctx.strokeStyle="#536b62";ctx.strokeRect(ox,oy,s.box_size*scale,s.box_size*scale);for(let i=0;i<snap.particles.length;i++){const [x,y,vx,vy]=snap.particles[i],px=ox+x*scale,py=oy+y*scale,r=Math.max(2.6,s.radius*scale);const speed=Math.sqrt(vx*vx+vy*vy),h=(140+Math.min(80,speed/4));ctx.beginPath();ctx.arc(px,py,r,0,Math.PI*2);ctx.fillStyle=`hsl(${h} 82% 64%)`;ctx.fill();ctx.strokeStyle="rgba(255,255,255,.28)";ctx.stroke();ctx.beginPath();ctx.moveTo(px,py);ctx.lineTo(px+vx*.035,py+vy*.035);ctx.strokeStyle="rgba(201,255,91,.45)";ctx.stroke();}$("frameLabel").textContent=`FRAME ${state.frame+1} / ${state.evidence.snapshots.length}`;$("timeline").value=state.frame;renderFrameStats(snap);drawDensity(snap,s);}
function drawGrid(ctx,canvas){ctx.strokeStyle="rgba(90,228,200,.045)";ctx.lineWidth=1;for(let x=0;x<canvas.width;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,canvas.height);ctx.stroke()}for(let y=0;y<canvas.height;y+=40){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(canvas.width,y);ctx.stroke()}}
function renderFrameStats(snap){let px=0,py=0,e=0;for(const [, ,vx,vy] of snap.particles){px+=vx;py+=vy;e+=vx*vx+vy*vy;}$("liveEvent").textContent=fmt(snap.event_count);$("liveTick").textContent=fmt(snap.ticks);$("livePx").textContent=fmt(px);$("livePy").textContent=fmt(py);$("liveEnergy").textContent=fmt(e);}
function drawDensity(snap,scenario){const canvas=$("densityCanvas"),ctx=canvas.getContext("2d"),bins=scenario.density_bins,counts=Array(bins*bins).fill(0);for(const [x,y]of snap.particles){const bx=Math.min(bins-1,Math.floor(x*bins/scenario.box_size)),by=Math.min(bins-1,Math.floor(y*bins/scenario.box_size));counts[by*bins+bx]++;}const max=Math.max(1,...counts),cell=canvas.width/bins;ctx.fillStyle="#07100e";ctx.fillRect(0,0,canvas.width,canvas.height);counts.forEach((count,i)=>{const alpha=.06+.85*count/max;ctx.fillStyle=`rgba(201,255,91,${alpha})`;ctx.fillRect((i%bins)*cell+1,Math.floor(i/bins)*cell+1,cell-2,cell-2);if(count){ctx.fillStyle=count/max>.55?"#0a100d":"#dce8df";ctx.font="11px Cascadia Mono";ctx.textAlign="center";ctx.fillText(count,(i%bins+.5)*cell,(Math.floor(i/bins)+.55)*cell);}});}

function step(delta){if(!state.evidence)return;state.frame=Math.max(0,Math.min(state.evidence.snapshots.length-1,state.frame+delta));drawFrame();}
$("backButton").addEventListener("click",()=>step(-1));$("nextButton").addEventListener("click",()=>step(1));$("timeline").addEventListener("input",()=>{state.frame=+$("timeline").value;drawFrame();});
$("playButton").addEventListener("click",()=>{if(state.timer){clearInterval(state.timer);state.timer=null;$("playButton").textContent="▶";return;}if(!state.evidence)return;$("playButton").textContent="Ⅱ";state.timer=setInterval(()=>{if(state.frame>=state.evidence.snapshots.length-1)state.frame=0;else state.frame++;drawFrame();},+$("playSpeed").value);});
$("playSpeed").addEventListener("change",()=>{if(state.timer){clearInterval(state.timer);state.timer=null;$("playButton").click();}});

function scientific(value,digits=2){const numeric=Number(value);if(!Number.isFinite(numeric))return "—";if(numeric===0)return "0";return numeric.toExponential(digits);}

function renderResearch(){
  const data=RESEARCH_SUMMARY,r1=data.r1,r3=data.r3,scales=data.scales;
  $("researchHash").textContent=data.research_hash.slice(7,25)+"…";
  $("researchHash").title=data.research_hash;
  $("precisionCases").textContent=fmt(r1.case_count);
  $("tickAgreement").textContent=`${(Number(r1.tick_agreement_rate)*100).toFixed(1)}%`;
  const replicas=scales.reduce((total,scale)=>total+Number(scale.energy_drift_ratio.n||0),0);
  $("ensembleRuns").textContent=fmt(replicas);
  const gates=Object.values(r3.quality_gates),passed=gates.filter(Boolean).length;
  $("qualityGates").textContent=`${passed}/${gates.length} PASS`;
  $("qualityGates").style.color=passed===gates.length?"var(--lime)":"var(--orange)";
  $("researchScaleRows").innerHTML=scales.map(scale=>`<tr><td>${scale.target_particle_count}</td><td>${Number(scale.epsilon).toPrecision(3)}</td><td>${Number(scale.collisions.mean).toFixed(1)}</td><td>${scientific(scale.energy_drift_ratio.mean)}</td><td>${scientific(scale.contact_relative_residual_max.mean)}</td></tr>`).join("");
  drawResearchTrend(scales);
}

function drawResearchTrend(scales){
  const canvas=$("researchTrendCanvas"),ctx=canvas.getContext("2d"),w=canvas.width,h=canvas.height;
  ctx.clearRect(0,0,w,h);ctx.fillStyle="#08110f";ctx.fillRect(0,0,w,h);
  const pad={l:58,r:28,t:34,b:48},plotW=w-pad.l-pad.r,plotH=h-pad.t-pad.b,max=.7;
  ctx.strokeStyle="rgba(143,163,155,.13)";ctx.lineWidth=1;ctx.font="11px Cascadia Mono";ctx.fillStyle="#72867f";
  for(let i=0;i<=4;i++){const y=pad.t+plotH*i/4;ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();ctx.fillText((max*(1-i/4)).toFixed(2),8,y+4);}
  const series=[{key:"velocity_histogram_tv",color:"#5ae4c8",label:"velocity TV"},{key:"density_shift_tv",color:"#7ba2ff",label:"density TV"}];
  series.forEach((line,index)=>{ctx.strokeStyle=line.color;ctx.fillStyle=line.color;ctx.lineWidth=3;ctx.beginPath();scales.forEach((scale,i)=>{const x=pad.l+(scales.length===1?0:plotW*i/(scales.length-1)),y=pad.t+plotH*(1-Number(scale[line.key].mean)/max);if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);});ctx.stroke();scales.forEach((scale,i)=>{const x=pad.l+plotW*i/(scales.length-1),y=pad.t+plotH*(1-Number(scale[line.key].mean)/max);ctx.beginPath();ctx.arc(x,y,5,0,Math.PI*2);ctx.fill();ctx.fillStyle="#8fa39b";ctx.textAlign="center";ctx.fillText(`N=${scale.target_particle_count}`,x,h-18);ctx.fillStyle=line.color;});ctx.textAlign="left";ctx.fillRect(w-190,pad.t+index*22,16,3);ctx.fillText(line.label,w-166,pad.t+5+index*22);});
}

$("downloadResearchButton").addEventListener("click",()=>{const blob=new Blob([JSON.stringify(RESEARCH_SUMMARY,null,2)],{type:"application/json"}),anchor=document.createElement("a");anchor.href=URL.createObjectURL(blob);anchor.download=`QinPhys-research-summary-${RESEARCH_SUMMARY.research_hash.slice(7,19)}.json`;anchor.click();setTimeout(()=>URL.revokeObjectURL(anchor.href),1000);$("researchActionStatus").textContent="研究摘要已导出；完整证据请使用 Python evidence 包";});
$("copyResearchHashButton").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(RESEARCH_SUMMARY.research_hash);$("researchActionStatus").textContent="研究哈希已复制";}catch{const input=document.createElement("textarea");input.value=RESEARCH_SUMMARY.research_hash;document.body.appendChild(input);input.select();document.execCommand("copy");input.remove();$("researchActionStatus").textContent="研究哈希已复制";}});

renderResearch();
execute();
