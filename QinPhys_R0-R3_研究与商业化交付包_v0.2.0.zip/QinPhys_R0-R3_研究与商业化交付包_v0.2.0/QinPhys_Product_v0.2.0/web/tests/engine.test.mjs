import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {divRound, Rounding, runScenario, verifyEvidence} from "../engine.js";

test("half-even is explicit",()=>{
  assert.equal(divRound(5n,2n,Rounding.HALF_EVEN),2n);
  assert.equal(divRound(7n,2n,Rounding.HALF_EVEN),4n);
  assert.equal(divRound(-5n,2n,Rounding.HALF_EVEN),-2n);
});

test("same input produces same hash",async()=>{
  const spec={particle_count:12,event_limit:60,snapshot_stride:5};
  const a=await runScenario(spec),b=await runScenario(spec);
  assert.equal(a.run_hash,b.run_hash);
  assert.deepEqual(a.deterministic_core,b.deterministic_core);
});

test("wall impulse closes momentum balance",async()=>{
  const result=await runScenario({particle_count:16,event_limit:100,snapshot_stride:10});
  const core=result.deterministic_core;
  assert.deepEqual(core.final_momentum,[core.initial_momentum[0]+core.boundary_impulse[0],core.initial_momentum[1]+core.boundary_impulse[1]]);
});

test("tampering is detected",async()=>{
  const result=await runScenario({particle_count:8,event_limit:20,snapshot_stride:5});
  assert.equal((await verifyEvidence(result)).valid,true);
  result.deterministic_core.total_ticks++;
  assert.equal((await verifyEvidence(result)).valid,false);
});

test("JavaScript matches the Python conformance vector",async()=>{
  const reference=JSON.parse(fs.readFileSync(new URL("../../vectors/conformance-12x60.json",import.meta.url),"utf8"));
  const actual=await runScenario(reference.deterministic_core.scenario);
  assert.equal(actual.run_hash,reference.run_hash);
  assert.deepEqual(actual.deterministic_core,reference.deterministic_core);
});

