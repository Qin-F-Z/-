$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root
$Python = (Get-Command python -ErrorAction Stop).Source

& $Python -m qinphys research --precision-cases 512 --scales 24 48 96 --replicas 8 --horizon-ticks 60000 --out build/research/qinphys-r1-r3-evidence.json
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $Python -m qinphys verify-research build/research/qinphys-r1-r3-evidence.json
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $Python tooling/generate_research_assets.py
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host 'QinPhys R1-R3 research reproduction: PASS' -ForegroundColor Green
