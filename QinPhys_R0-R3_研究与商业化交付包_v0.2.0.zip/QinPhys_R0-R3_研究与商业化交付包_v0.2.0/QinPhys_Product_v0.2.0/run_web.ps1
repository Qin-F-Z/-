$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host 'QinPhys: http://127.0.0.1:8765/' -ForegroundColor Green
Write-Host '按 Ctrl+C 停止本地服务。所有计算均在本机完成。'
python -m http.server 8765 --bind 127.0.0.1 --directory (Join-Path $Root 'dist')

