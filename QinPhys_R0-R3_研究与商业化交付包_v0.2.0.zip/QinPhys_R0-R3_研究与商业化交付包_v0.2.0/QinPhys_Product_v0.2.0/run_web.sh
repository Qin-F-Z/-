#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
printf '%s\n' 'QinPhys: http://127.0.0.1:8765/' 'Press Ctrl+C to stop. All computation remains local.'
python3 -m http.server 8765 --bind 127.0.0.1 --directory dist
