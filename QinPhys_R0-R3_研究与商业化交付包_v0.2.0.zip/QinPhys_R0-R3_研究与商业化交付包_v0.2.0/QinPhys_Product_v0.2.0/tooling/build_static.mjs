import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const web=path.join(root,"web"),dist=path.join(root,"dist");
fs.mkdirSync(dist,{recursive:true});
let engine=fs.readFileSync(path.join(web,"engine.js"),"utf8").replace(/^export /gm,"");
let research=fs.readFileSync(path.join(web,"research-data.js"),"utf8").replace(/^export /gm,"");
let app=fs.readFileSync(path.join(web,"app.js"),"utf8").replace(/^import .*?;\r?\n/gm,"");
const banner="/* QinPhys v0.2.0 standalone build — deterministic core + R1–R3 research evidence */\n";
fs.writeFileSync(path.join(dist,"app.bundle.js"),banner+engine+"\n"+research+"\n"+app,"utf8");
const html=fs.readFileSync(path.join(web,"index.html"),"utf8").replace('<script type="module" src="app.js"></script>','<script src="app.bundle.js"></script>');
fs.writeFileSync(path.join(dist,"index.html"),html,"utf8");
fs.copyFileSync(path.join(web,"styles.css"),path.join(dist,"styles.css"));
fs.copyFileSync(path.join(web,"research.css"),path.join(dist,"research.css"));
console.log(JSON.stringify({status:"built",dist,files:["index.html","styles.css","research.css","app.bundle.js"]}));
