import fs from "node:fs";
import {runScenario} from "../web/engine.js";

const reference=JSON.parse(fs.readFileSync(process.argv[2],"utf8"));
const actual=await runScenario(reference.deterministic_core.scenario);
const diffs=[];
function walk(a,b,path="core"){
  if(Object.is(a,b)) return;
  if(typeof a!==typeof b||a===null||b===null){diffs.push({path,a,b});return;}
  if(Array.isArray(a)&&Array.isArray(b)){if(a.length!==b.length)diffs.push({path:path+".length",a:a.length,b:b.length});for(let i=0;i<Math.min(a.length,b.length);i++)walk(a[i],b[i],`${path}[${i}]`);return;}
  if(typeof a==="object"){for(const key of new Set([...Object.keys(a),...Object.keys(b)]))walk(a[key],b[key],`${path}.${key}`);return;}
  diffs.push({path,a,b});
}
walk(reference.deterministic_core,actual.deterministic_core);
console.log(JSON.stringify({reference_hash:reference.run_hash,actual_hash:actual.run_hash,diff_count:diffs.length,diffs:diffs.slice(0,50)},null,2));
process.exitCode=diffs.length?1:0;
