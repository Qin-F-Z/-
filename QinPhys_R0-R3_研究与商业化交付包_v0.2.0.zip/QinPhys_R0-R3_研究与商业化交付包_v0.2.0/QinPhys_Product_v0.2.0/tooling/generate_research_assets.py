from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "build" / "research" / "qinphys-r1-r3-evidence.json"
PAPER_FIGURES = ROOT / "paper" / "figures"
PAPER_GENERATED = ROOT / "paper" / "generated"


def tex_escape(value: str) -> str:
    return value.replace("_", r"\_").replace("%", r"\%")


def main() -> None:
    evidence = json.loads(EVIDENCE.read_text(encoding="utf-8"))
    core = evidence["research_core"]
    r1 = core["r1_high_precision_audit"]
    r2 = core["r2_paper_aligned_finite_experiments"]
    r3 = core["r3_computational_auxiliary_validation"]
    PAPER_FIGURES.mkdir(parents=True, exist_ok=True)
    PAPER_GENERATED.mkdir(parents=True, exist_ok=True)

    with (ROOT / "build" / "research" / "r1_precision_cases.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(r1["cases"][0]))
        writer.writeheader()
        writer.writerows(r1["cases"])

    scale_rows = []
    for scale in r2["scales"]:
        scale_rows.append(
            {
                "target_n": scale["target_particle_count"],
                "epsilon": scale["epsilon"],
                "actual_n_mean": scale["actual_particle_count"]["mean"],
                "collisions_mean": scale["collisions"]["mean"],
                "energy_drift_mean": scale["energy_drift_ratio"]["mean"],
                "velocity_tv_mean": scale["velocity_histogram_tv"]["mean"],
                "density_tv_mean": scale["density_shift_tv"]["mean"],
                "contact_residual_mean": scale["contact_relative_residual_max"]["mean"],
            }
        )
    with (ROOT / "build" / "research" / "r2_r3_scales.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(scale_rows[0]))
        writer.writeheader()
        writer.writerows(scale_rows)

    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "axes.edgecolor": "#39534b",
            "axes.labelcolor": "#173d35",
            "xtick.color": "#39534b",
            "ytick.color": "#39534b",
            "text.color": "#173d35",
            "figure.facecolor": "white",
        }
    )
    unclamped_cases = [row for row in r1["cases"] if not row["minimum_tick_clamped"]]
    phase = [float(row["phase_error_ticks"]) for row in unclamped_cases]
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    ax.hist(phase, bins=24, color="#159977", edgecolor="white", linewidth=0.7)
    ax.axvline(0.5, color="#dc7c28", linestyle="--", linewidth=1.5, label="half-tick boundary")
    ax.set_title("R1: 80-digit reference audit (unclamped events)", loc="left", weight="bold")
    ax.set_xlabel("absolute phase error (ticks)")
    ax.set_ylabel("cases")
    ax.grid(axis="y", alpha=0.18)
    ax.legend(frameon=False)
    clamped_count = r1["summary"]["minimum_tick_clamp_count"]
    ax.text(
        0.01,
        0.96,
        f"{clamped_count} minimum-tick clamped cases reported separately",
        transform=ax.transAxes,
        va="top",
        fontsize=8,
        color="#51665f",
    )
    fig.tight_layout()
    for suffix in ("pdf", "png"):
        fig.savefig(PAPER_FIGURES / f"r1-phase-error.{suffix}", dpi=220, bbox_inches="tight")
    plt.close(fig)

    eps = [float(row["epsilon"]) for row in scale_rows]
    velocity = [float(row["velocity_tv_mean"]) for row in scale_rows]
    density = [float(row["density_tv_mean"]) for row in scale_rows]
    energy = [float(row["energy_drift_mean"]) for row in scale_rows]
    contact = [float(row["contact_residual_mean"]) for row in scale_rows]
    fig, (left, right) = plt.subplots(1, 2, figsize=(8.3, 3.6))
    left.loglog(eps, velocity, "o-", color="#159977", linewidth=2, label="velocity histogram TV")
    left.loglog(eps, density, "s-", color="#527ad9", linewidth=2, label="density shift TV")
    left.invert_xaxis()
    left.set_title("Finite-scale observables", loc="left", weight="bold")
    left.set_xlabel(r"smaller $\varepsilon$ $\rightarrow$")
    left.set_ylabel("diagnostic magnitude")
    left.grid(alpha=0.18, which="both")
    left.legend(frameon=False, fontsize=8)
    right.loglog(eps, energy, "o-", color="#dc7c28", linewidth=2, label="energy drift")
    right.loglog(eps, contact, "s-", color="#8b5bc1", linewidth=2, label="contact residual")
    right.invert_xaxis()
    right.set_title("Numerical-control diagnostics", loc="left", weight="bold")
    right.set_xlabel(r"smaller $\varepsilon$ $\rightarrow$")
    right.grid(alpha=0.18, which="both")
    right.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    for suffix in ("pdf", "png"):
        fig.savefig(PAPER_FIGURES / f"r2-r3-scaling.{suffix}", dpi=220, bbox_inches="tight")
    plt.close(fig)

    summary = {
        "research_hash": evidence["research_hash"],
        "runtime_ns": evidence["runtime_observation"]["runtime_ns"],
        "r1": r1["summary"],
        "scales": [
            {key: value for key, value in scale.items() if key != "replicas"}
            for scale in r2["scales"]
        ],
        "r3": r3,
        "claim_gate": core["claim_gate"],
        "paper_alignment": r2["paper_alignment"],
    }
    (ROOT / "build" / "research" / "research-summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    (ROOT / "web" / "research-data.js").write_text(
        "// Generated from build/research/qinphys-r1-r3-evidence.json\n"
        f"export const RESEARCH_SUMMARY = {json.dumps(summary, ensure_ascii=False, separators=(',', ':'))};\n",
        encoding="utf-8",
    )

    macros = {
        "ResearchHash": evidence["research_hash"],
        "RoneCases": str(r1["summary"]["case_count"]),
        "RonePrecision": str(r1["summary"]["decimal_precision"]),
        "RoneTickAgreement": r1["summary"]["tick_agreement_rate"],
        "RoneUnclampedMaxPhase": r1["summary"]["unclamped_max_absolute_phase_error_ticks"],
        "ResearchRuntimeSeconds": format(evidence["runtime_observation"]["runtime_ns"] / 1e9, ".2f"),
        "EnergySlope": r3["energy_drift_loglog_regression"]["slope"],
        "EnergyRsquared": r3["energy_drift_loglog_regression"]["r_squared"],
        "VelocitySlope": r3["velocity_tv_loglog_regression"]["slope"],
        "VelocityRsquared": r3["velocity_tv_loglog_regression"]["r_squared"],
        "DensitySlope": r3["density_tv_loglog_regression"]["slope"],
        "DensityRsquared": r3["density_tv_loglog_regression"]["r_squared"],
    }
    benchmark_path = ROOT / "build" / "research" / "hardware-benchmark.json"
    if benchmark_path.exists():
        benchmark = json.loads(benchmark_path.read_text(encoding="utf-8-sig"))
        macros.update(
            {
                "BenchmarkElapsedSeconds": str(benchmark["elapsed_seconds"]),
                "BenchmarkPeakMiB": str(benchmark["peak_working_set_mib"]),
                "BenchmarkCpu": str(benchmark["cpu_name"]),
                "BenchmarkPython": str(benchmark["python"]),
            }
        )
    macro_text = "\n".join(
        rf"\newcommand{{\{name}}}{{\detokenize{{{tex_escape(value)}}}}}" for name, value in macros.items()
    )
    raw_hash = evidence["research_hash"]
    hash_chunks = [raw_hash[:7]] + [raw_hash[index : index + 16] for index in range(7, len(raw_hash), 16)]
    macro_text += "\n" + r"\newcommand{\ResearchHashBreakable}{\texttt{" + r"\allowbreak ".join(hash_chunks) + "}}"
    (PAPER_GENERATED / "results_macros.tex").write_text(macro_text + "\n", encoding="utf-8")

    rows = []
    for scale in scale_rows:
        formatted = {
            "target_n": str(scale["target_n"]),
            "epsilon": format(float(scale["epsilon"]), ".4g"),
            "actual_n_mean": format(float(scale["actual_n_mean"]), ".4g"),
            "collisions_mean": format(float(scale["collisions_mean"]), ".4g"),
            "energy_drift_mean": format(float(scale["energy_drift_mean"]), ".3e"),
            "velocity_tv_mean": format(float(scale["velocity_tv_mean"]), ".4f"),
            "density_tv_mean": format(float(scale["density_tv_mean"]), ".4f"),
            "contact_residual_mean": format(float(scale["contact_residual_mean"]), ".3e"),
        }
        rows.append(
            " & ".join(
                [
                    formatted["target_n"],
                    formatted["epsilon"],
                    formatted["actual_n_mean"],
                    formatted["collisions_mean"],
                    formatted["energy_drift_mean"],
                    formatted["velocity_tv_mean"],
                    formatted["density_tv_mean"],
                    formatted["contact_residual_mean"],
                ]
            )
            + r" \\"
        )
    (PAPER_GENERATED / "scaling_rows.tex").write_text("\n".join(rows) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASS", "figures": 4, "summary": str(ROOT / "build" / "research" / "research-summary.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
