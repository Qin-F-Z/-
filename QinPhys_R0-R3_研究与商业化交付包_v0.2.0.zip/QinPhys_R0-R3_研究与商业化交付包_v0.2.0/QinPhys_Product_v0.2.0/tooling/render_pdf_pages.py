from pathlib import Path
import sys
import pypdfium2 as pdfium

src = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(parents=True, exist_ok=True)
pdf = pdfium.PdfDocument(str(src))
for i in range(len(pdf)):
    image = pdf[i].render(scale=1.5).to_pil().convert("RGB")
    image.save(out / f"page-{i+1}.png")
print(f"pages={len(pdf)}")
