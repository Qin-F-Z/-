param(
    [string]$OutputEvidence = "build/research/benchmark-evidence.json",
    [string]$OutputReport = "build/research/hardware-benchmark.json"
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Root
$Python = (Get-Command python -ErrorAction Stop).Source
$Stdout = Join-Path $Root 'build/research/benchmark.stdout.log'
$Stderr = Join-Path $Root 'build/research/benchmark.stderr.log'
$Started = Get-Date
$Arguments = @(
    '-m', 'qinphys', 'research',
    '--precision-cases', '512',
    '--scales', '24', '48', '96',
    '--replicas', '8',
    '--horizon-ticks', '60000',
    '--out', $OutputEvidence
)

$Process = Start-Process -FilePath $Python -ArgumentList $Arguments -RedirectStandardOutput $Stdout -RedirectStandardError $Stderr -WindowStyle Hidden -PassThru
$PeakWorkingSet = 0L
while (-not $Process.HasExited) {
    $Process.Refresh()
    if ($Process.WorkingSet64 -gt $PeakWorkingSet) { $PeakWorkingSet = $Process.WorkingSet64 }
    Start-Sleep -Milliseconds 100
}
$Process.Refresh()
if ($Process.PeakWorkingSet64 -gt $PeakWorkingSet) { $PeakWorkingSet = $Process.PeakWorkingSet64 }
if ($Process.ExitCode -ne 0) {
    throw "Research benchmark failed with exit code $($Process.ExitCode): $(Get-Content -Raw $Stderr)"
}

$Evidence = Get-Content -Raw $OutputEvidence | ConvertFrom-Json
$Computer = Get-CimInstance Win32_ComputerSystem
$Processor = Get-CimInstance Win32_Processor | Select-Object -First 1
$Report = [ordered]@{
    benchmark_version = '0.2.0'
    started_at = $Started.ToUniversalTime().ToString('o')
    elapsed_seconds = [math]::Round(((Get-Date) - $Started).TotalSeconds, 3)
    peak_working_set_bytes = $PeakWorkingSet
    peak_working_set_mib = [math]::Round($PeakWorkingSet / 1MB, 2)
    logical_processors = $Computer.NumberOfLogicalProcessors
    total_physical_memory_bytes = [int64]$Computer.TotalPhysicalMemory
    cpu_name = $Processor.Name.Trim()
    python = (& $Python --version 2>&1 | Out-String).Trim()
    gpu_required = $false
    network_required_during_research_run = $false
    research_hash = $Evidence.research_hash
    interpretation = 'Observed on this host; not a minimum-hardware proof or SLA.'
}
$Report | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 $OutputReport
$Report | ConvertTo-Json -Depth 5
