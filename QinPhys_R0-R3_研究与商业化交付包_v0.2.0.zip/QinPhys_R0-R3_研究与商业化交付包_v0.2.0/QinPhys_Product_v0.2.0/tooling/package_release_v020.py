from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
WORKSPACE = PROJECT.parent.parent
OUTPUTS = WORKSPACE / "outputs"
STAGING = WORKSPACE / "work" / "qinphys-release-v020-20260731"
SMOKE = WORKSPACE / "work" / "qinphys-release-v020-smoke-20260731"
PACKAGE_NAME = "QinPhys_R0-R3_研究与商业化交付包_v0.2.0"
RELEASE_DATE = (2026, 7, 31, 0, 0, 0)


def require_absent(path: Path) -> None:
    if path.exists():
        raise SystemExit(f"Refusing to overwrite existing release path: {path}")


def copy_file(source: Path, destination: Path) -> None:
    if not source.is_file():
        raise FileNotFoundError(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def copy_tree(source: Path, destination: Path) -> None:
    shutil.copytree(
        source,
        destination,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".DS_Store", "qa-v*", "word-qa*"),
    )


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_manifest(root: Path) -> Path:
    manifest = root / "SHA256SUMS.txt"
    files = sorted(path for path in root.rglob("*") if path.is_file() and path != manifest)
    manifest.write_text(
        "\n".join(f"{sha256(path)}  {path.relative_to(root).as_posix()}" for path in files) + "\n",
        encoding="utf-8",
    )
    return manifest


def verify_manifest(root: Path) -> int:
    entries = (root / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines()
    for entry in entries:
        expected, relative = entry.split("  ", 1)
        path = root / Path(relative)
        if not path.is_file() or sha256(path) != expected:
            raise RuntimeError(f"Manifest verification failed: {relative}")
    return len(entries)


def write_zip(source: Path, output: Path, include_root: bool = True) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(item for item in source.rglob("*") if item.is_file()):
            relative = path.relative_to(source)
            name = Path(source.name) / relative if include_root else relative
            info = zipfile.ZipInfo(name.as_posix(), RELEASE_DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())


def main() -> None:
    OUTPUTS.mkdir(parents=True, exist_ok=True)
    package = STAGING / PACKAGE_NAME
    product = package / "QinPhys_Product_v0.2.0"
    final_folder = OUTPUTS / PACKAGE_NAME
    full_zip = OUTPUTS / f"{PACKAGE_NAME}_2026-07-31.zip"
    source_zip = OUTPUTS / "QinPhys_v0.2.0_完整源码.zip"
    evidence_zip = OUTPUTS / "QinPhys_v0.2.0_R0-R3研究证据包.zip"
    latex_zip = OUTPUTS / "QinPhys_LaTeX论文源文件_v0.2.0.zip"
    standalone_pdf = OUTPUTS / "QinPhys_确定性有限物理与多尺度研究验证_v0.2.0.pdf"
    standalone_tex = OUTPUTS / "QinPhys_确定性有限物理与多尺度研究验证_v0.2.0.tex"
    standalone_readme = OUTPUTS / "00_打开这里_QinPhys_v0.2.0完整交付说明.md"
    artifact_manifest = OUTPUTS / "QinPhys_v0.2.0_交付文件_SHA256.txt"
    pointer = OUTPUTS / "QinPhys_v0.2.0_全部交付包.txt"

    for target in (
        STAGING,
        SMOKE,
        final_folder,
        full_zip,
        source_zip,
        evidence_zip,
        latex_zip,
        standalone_pdf,
        standalone_tex,
        standalone_readme,
        artifact_manifest,
        pointer,
    ):
        require_absent(target)

    package.mkdir(parents=True)
    copy_file(PROJECT / "00_打开这里_QinPhys完整交付说明.md", package / "00_打开这里_QinPhys_v0.2.0完整交付说明.md")
    copy_file(PROJECT / "paper" / "QinPhys_R0-R3_研究论文_v0.2.0.pdf", package / "QinPhys_R0-R3_研究论文_v0.2.0.pdf")
    copy_file(PROJECT / "paper" / "main.tex", package / "QinPhys_R0-R3_研究论文_v0.2.0.tex")
    copy_file(PROJECT / "build" / "research" / "qinphys-r1-r3-evidence.json", package / "QinPhys_R0-R3_正式研究证据.json")

    for filename in (
        "LICENSE-EVALUATION.txt",
        "pyproject.toml",
        "README.md",
        "run_web.ps1",
        "run_web.sh",
        "verify_all.ps1",
        "verify_all.sh",
        "reproduce_research.ps1",
        "reproduce_research.sh",
    ):
        copy_file(PROJECT / filename, product / filename)

    for dirname in ("qinphys", "web", "dist", "schemas", "vectors", "tests", "docs"):
        copy_tree(PROJECT / dirname, product / dirname)

    tooling_files = (
        "build_static.mjs",
        "compare_engines.mjs",
        "generate_research_assets.py",
        "benchmark_research.ps1",
        "render_pdf_pages.py",
        "package_release_v020.py",
    )
    for filename in tooling_files:
        copy_file(PROJECT / "tooling" / filename, product / "tooling" / filename)

    for filename in ("evidence-36x400.json", "evidence-100x5000.json", "final-verification-evidence.json"):
        copy_file(PROJECT / "build" / filename, product / "build" / filename)
    for filename in (
        "qinphys-r1-r3-evidence.json",
        "benchmark-evidence.json",
        "research-summary.json",
        "r1_precision_cases.csv",
        "r2_r3_scales.csv",
        "hardware-benchmark.json",
    ):
        copy_file(PROJECT / "build" / "research" / filename, product / "build" / "research" / filename)

    paper_destination = product / "paper"
    copy_file(PROJECT / "paper" / "main.tex", paper_destination / "main.tex")
    copy_file(PROJECT / "paper" / "README.md", paper_destination / "README.md")
    copy_file(PROJECT / "paper" / "QinPhys_R0-R3_研究论文_v0.2.0.pdf", paper_destination / "QinPhys_R0-R3_研究论文_v0.2.0.pdf")
    copy_tree(PROJECT / "paper" / "figures", paper_destination / "figures")
    copy_tree(PROJECT / "paper" / "generated", paper_destination / "generated")

    source_pdf = Path(
        "C:/Users/Administrator/Documents/xwechat_files/"
        "wxid_gy1dy9cisvwv12_682b/msg/file/2026-07/问.pdf"
    )
    copy_file(source_pdf, package / "输入材料" / "问.pdf")

    build_info = {
        "product": "QinPhys",
        "version": "0.2.0",
        "release_date": "2026-07-31",
        "research_hash": "sha256:6437735f9264f4a38db5b4daa2e0db80ce11ea27a1116d7e52f004370074052e",
        "verification": {
            "python_tests": "9/9 PASS",
            "javascript_tests": "5/5 PASS",
            "r0_cross_language_diff_count": 0,
            "r1_decimal_cases": 512,
            "r2_finite_ensemble_runs": 24,
            "r3_engineering_quality_gates": "6/6 PASS",
            "research_hash_repeat": "PASS",
            "nested_research_hashes": "PASS",
            "latex_pages": 7,
            "browser_compute_evidence_simulation": "PASS",
            "package_manifest": "generated and smoke-verified",
        },
        "benchmark": {
            "elapsed_seconds": 89.612,
            "peak_working_set_mib": 20.24,
            "cpu": "11th Gen Intel Core i9-11950H",
            "python": "3.12.13",
            "interpretation": "host observation, not a minimum-hardware proof or SLA",
        },
        "scientific_boundary": {
            "R0": "complete",
            "R1": "complete",
            "R2": "complete with declared finite surrogates",
            "R3": "complete as a computational diagnostic pipeline",
            "Deng_Hani_Ma_theorem_reproduced": False,
            "Boltzmann_or_fluid_limit_proved": False,
        },
    }
    (package / "BUILD_INFO.json").write_text(json.dumps(build_info, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    write_manifest(package)

    shutil.copytree(package, final_folder)
    write_zip(final_folder, full_zip)
    write_zip(final_folder / "QinPhys_Product_v0.2.0", source_zip)

    evidence_stage = STAGING / "QinPhys_v0.2.0_R0-R3研究证据包"
    evidence_stage.mkdir()
    for filename in (
        "qinphys-r1-r3-evidence.json",
        "benchmark-evidence.json",
        "research-summary.json",
        "r1_precision_cases.csv",
        "r2_r3_scales.csv",
        "hardware-benchmark.json",
    ):
        copy_file(PROJECT / "build" / "research" / filename, evidence_stage / "evidence" / filename)
    copy_file(PROJECT / "build" / "final-verification-evidence.json", evidence_stage / "evidence" / "r0-final-verification-evidence.json")
    copy_file(PROJECT / "schemas" / "qinphys-research-evidence-0.2.0.schema.json", evidence_stage / "schemas" / "qinphys-research-evidence-0.2.0.schema.json")
    copy_file(PROJECT / "schemas" / "qinphys-evidence-0.1.0.schema.json", evidence_stage / "schemas" / "qinphys-evidence-0.1.0.schema.json")
    copy_file(PROJECT / "qinphys" / "research.py", evidence_stage / "verifier-source" / "research.py")
    copy_file(PROJECT / "qinphys" / "canonical.py", evidence_stage / "verifier-source" / "canonical.py")
    copy_file(PROJECT / "tests" / "test_research.py", evidence_stage / "tests" / "test_research.py")
    copy_file(PROJECT / "reproduce_research.ps1", evidence_stage / "reproduce_research.ps1")
    copy_file(PROJECT / "reproduce_research.sh", evidence_stage / "reproduce_research.sh")
    write_manifest(evidence_stage)
    write_zip(evidence_stage, evidence_zip)

    latex_stage = STAGING / "QinPhys_LaTeX论文源文件_v0.2.0"
    latex_stage.mkdir()
    copy_file(PROJECT / "paper" / "main.tex", latex_stage / "main.tex")
    copy_file(PROJECT / "paper" / "README.md", latex_stage / "README.md")
    copy_file(PROJECT / "paper" / "QinPhys_R0-R3_研究论文_v0.2.0.pdf", latex_stage / "QinPhys_R0-R3_研究论文_v0.2.0.pdf")
    copy_tree(PROJECT / "paper" / "figures", latex_stage / "figures")
    copy_tree(PROJECT / "paper" / "generated", latex_stage / "generated")
    copy_file(PROJECT / "build" / "research" / "research-summary.json", latex_stage / "data" / "research-summary.json")
    copy_file(PROJECT / "tooling" / "generate_research_assets.py", latex_stage / "tooling" / "generate_research_assets.py")
    write_manifest(latex_stage)
    write_zip(latex_stage, latex_zip)

    copy_file(package / "QinPhys_R0-R3_研究论文_v0.2.0.pdf", standalone_pdf)
    copy_file(package / "QinPhys_R0-R3_研究论文_v0.2.0.tex", standalone_tex)
    copy_file(package / "00_打开这里_QinPhys_v0.2.0完整交付说明.md", standalone_readme)

    artifacts = [full_zip, source_zip, evidence_zip, latex_zip, standalone_pdf, standalone_tex, standalone_readme]
    artifact_manifest.write_text(
        "\n".join(f"{sha256(path)}  {path.name}" for path in artifacts) + "\n",
        encoding="utf-8",
    )
    pointer.write_text(
        "QinPhys v0.2.0 R0-R3 全部交付包\n"
        f"主压缩包：{full_zip.name}\n"
        f"完整目录：{final_folder.name}\n"
        f"完整源码：{source_zip.name}\n"
        f"研究证据：{evidence_zip.name}\n"
        f"LaTeX 源文件：{latex_zip.name}\n"
        f"总校验清单：{artifact_manifest.name}\n",
        encoding="utf-8",
    )

    with zipfile.ZipFile(full_zip) as archive:
        for member in archive.infolist():
            path = Path(member.filename)
            if path.is_absolute() or ".." in path.parts:
                raise RuntimeError(f"Unsafe zip member: {member.filename}")
        archive.extractall(SMOKE)
    verified = verify_manifest(SMOKE / PACKAGE_NAME)

    print(
        json.dumps(
            {
                "status": "PASS",
                "package": str(final_folder),
                "zip": str(full_zip),
                "source_zip": str(source_zip),
                "evidence_zip": str(evidence_zip),
                "latex_zip": str(latex_zip),
                "manifest_files_verified": verified,
                "zip_sha256": sha256(full_zip),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
