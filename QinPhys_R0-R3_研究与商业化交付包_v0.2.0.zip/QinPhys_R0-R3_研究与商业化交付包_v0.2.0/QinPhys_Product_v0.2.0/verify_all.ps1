$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

$Python = (Get-Command python -ErrorAction Stop).Source
$Node = (Get-Command node -ErrorAction Stop).Source

& $Python -m unittest discover -s tests -v
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& $Node --test web/tests/*.test.mjs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& $Node tooling/build_static.mjs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& $Python -m qinphys run --particles 36 --events 400 --snapshot-stride 4 --out build/verification-evidence.json
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& $Python -m qinphys verify build/verification-evidence.json
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& $Python -m qinphys verify-research build/research/qinphys-r1-r3-evidence.json
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& $Node tooling/compare_engines.mjs build/verification-evidence.json
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host 'QinPhys v0.2.0 verification: PASS' -ForegroundColor Green
