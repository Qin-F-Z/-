# QinPhys v0.2.0

QinPhys 是“有限执行、显式数值契约、研究声明分级、证据绑定”的确定性物理计算平台。它保留计算台与模拟台两个主界面，并新增嵌入计算台的 R1–R3 研究验证模块。

## 已实现能力

- **R0**：整数状态、量化轨迹、canonical JSON 和 SHA-256 重复一致；
- **R1**：80 位 Decimal 碰撞时刻基准、tick 一致性、半 tick 相位误差和最小 tick 钳位统计；
- **R2**：二维周期环面、硬核初态、有限 Poisson 系综、目标 `Nε=α` 账本、速度/密度/径向配对观测量和置信区间；
- **R3**：动量/能量/接触质量门、三尺度 log-log 回归、结论状态和可验证研究证据；
- Python 参考内核、JavaScript BigInt R0 内核、双界面、JSON Schema、CSV、图表和 LaTeX 论文；
- 独立 `verify` 与 `verify-research` 防篡改验证。

“R2/R3 已完成”表示有限实验协议、观测量、统计量、回归、质量门、证据和失败状态已经实现。它不表示邓煜–Hani–Ma 定理、Boltzmann–Grad 极限或 Navier–Stokes–Fourier/Euler 极限已经得到数学证明。

## 五分钟运行

需要 Python 3.11+ 和 Node.js 20+。

```powershell
powershell -ExecutionPolicy Bypass -File verify_all.ps1
powershell -ExecutionPolicy Bypass -File run_web.ps1
```

浏览器打开脚本显示的 `http://127.0.0.1:8765/`。Linux/macOS 使用 `verify_all.sh` 与 `run_web.sh`。

运行单轨迹：

```powershell
python -m qinphys run --particles 36 --events 400 --out build/evidence.json
python -m qinphys verify build/evidence.json
```

重新生成正式 R1–R3 证据、CSV 和论文图：

```powershell
powershell -ExecutionPolicy Bypass -File reproduce_research.ps1
```

对应命令为：

```powershell
python -m qinphys research --precision-cases 512 --scales 24 48 96 --replicas 8 --horizon-ticks 60000 --out build/research/qinphys-r1-r3-evidence.json
python -m qinphys verify-research build/research/qinphys-r1-r3-evidence.json
python tooling/generate_research_assets.py
```

正式研究矩阵在本次机器上约 90 秒，主要使用单个 CPU 线程，不需要 GPU 或网络。性能数字是观察值，不是 SLA。

## 正式研究结果

- 研究哈希：`sha256:6437735f9264f4a38db5b4daa2e0db80ce11ea27a1116d7e52f004370074052e`；
- R1：512/512 的整数 tick 与 80 位 Decimal 最近 tick 一致；非钳位事件最大相位误差 0.499956635211 tick；
- R2：`N={24,48,96}`，每尺度 8 个 Poisson 有限系综；目标 `Nε=0.5`；
- R3：动量在全部副本中逐整数严格守恒；6/6 工程质量门通过；
- 有限尺度速度直方图 TV 回归斜率约 0.2525，`R²≈0.9580`；密度位移 TV 斜率约 0.3763，`R²≈0.9812`；
- 独立外层基准：Intel i9-11950H、Python 3.12.13，89.612 秒，进程峰值工作集 20.24 MiB；该数字不是最低硬件证明或 SLA；
- 上述回归只描述这 24 个有限运行，不构成理论收敛率。

## 目录

- `qinphys/engine.py`：R0 反射边界量化事件参考引擎；
- `qinphys/research.py`：R1–R3 高精度、周期系综和辅助验证；
- `web/`：商业双界面源码；
- `dist/`：无前端运行时依赖的静态构建；
- `build/research/`：完整研究证据、摘要和 CSV；
- `schemas/`：R0 与 R1–R3 JSON Schema；
- `paper/`：LaTeX 论文、生成数据和正式图；
- `tests/`、`web/tests/`：Python、JavaScript、跨语言、防篡改和研究测试；
- `docs/`：科学、产品、专利、商业和安全文档。

## 科学与法律边界

当前 R2 使用有限 Poisson 系综、Irwin–Hall 速度替代和量化事件动力学；这些替代项全部进入证据。要宣称论文级复现，仍需实现论文精确初值类、关联函数/累积量、误差范数、长时间参数窗口和独立数学审阅。

本软件不替代同行评审、实验验证、行业认证、安全审计或专利代理师法律意见。代码许可见 `LICENSE-EVALUATION.txt`。
