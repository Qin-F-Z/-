# QinPhys LaTeX paper

`main.tex` is the authoritative source. The tables and macros in `generated/`, and the figures in `figures/`, are generated from `../build/research/qinphys-r1-r3-evidence.json` by:

```powershell
python ../tooling/generate_research_assets.py
```

Compile with XeLaTeX or the included Codex LaTeX compile helper. The PDF must be visually reviewed after every material update.
