#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python3 -m qinphys research --precision-cases 512 --scales 24 48 96 --replicas 8 --horizon-ticks 60000 --out build/research/qinphys-r1-r3-evidence.json
python3 -m qinphys verify-research build/research/qinphys-r1-r3-evidence.json
python3 tooling/generate_research_assets.py
printf '%s\n' 'QinPhys R1-R3 research reproduction: PASS'
