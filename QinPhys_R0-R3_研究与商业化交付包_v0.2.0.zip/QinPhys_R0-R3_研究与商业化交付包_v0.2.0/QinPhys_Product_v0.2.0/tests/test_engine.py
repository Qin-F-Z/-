import json
import unittest

from qinphys.engine import Scenario, run_scenario, verify_evidence
from qinphys.fixed import Rounding, div_round


class FixedTests(unittest.TestCase):
    def test_half_even_ties(self):
        self.assertEqual(div_round(5, 2, Rounding.HALF_EVEN), 2)
        self.assertEqual(div_round(7, 2, Rounding.HALF_EVEN), 4)
        self.assertEqual(div_round(-5, 2, Rounding.HALF_EVEN), -2)

    def test_directed_modes(self):
        self.assertEqual(div_round(-7, 3, Rounding.DOWN), -3)
        self.assertEqual(div_round(-7, 3, Rounding.UP), -2)
        self.assertEqual(div_round(7, 3, Rounding.TOWARD_ZERO), 2)
        self.assertEqual(div_round(7, 3, Rounding.AWAY_FROM_ZERO), 3)


class EngineTests(unittest.TestCase):
    def test_replay_is_identical(self):
        scenario = Scenario(particle_count=12, event_limit=60, snapshot_stride=5)
        first = run_scenario(scenario)
        second = run_scenario(scenario)
        self.assertEqual(first["run_hash"], second["run_hash"])
        self.assertEqual(first["deterministic_core"], second["deterministic_core"])

    def test_momentum_balance_is_exact(self):
        result = run_scenario(Scenario(particle_count=16, event_limit=100, snapshot_stride=10))
        core = result["deterministic_core"]
        expected = [
            core["initial_momentum"][0] + core["boundary_impulse"][0],
            core["initial_momentum"][1] + core["boundary_impulse"][1],
        ]
        self.assertEqual(expected, core["final_momentum"])

    def test_evidence_tamper_is_detected(self):
        result = run_scenario(Scenario(particle_count=8, event_limit=20, snapshot_stride=5))
        self.assertTrue(verify_evidence(result)["valid"])
        tampered = json.loads(json.dumps(result))
        tampered["deterministic_core"]["total_ticks"] += 1
        self.assertFalse(verify_evidence(tampered)["valid"])


if __name__ == "__main__":
    unittest.main()
