import json
import unittest

from qinphys.research import (
    PrecisionAuditConfig,
    ResearchSuiteConfig,
    run_precision_audit,
    run_research_suite,
    verify_research_evidence,
)


class PrecisionAuditTests(unittest.TestCase):
    def test_decimal_reference_audit_is_complete(self):
        result = run_precision_audit(PrecisionAuditConfig(case_count=64, seed=77))
        self.assertEqual(result["summary"]["case_count"], 64)
        self.assertEqual(result["summary"]["decimal_precision"], 80)
        self.assertLessEqual(float(result["summary"]["unclamped_max_absolute_phase_error_ticks"]), 0.5)


class ResearchSuiteTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.result = run_research_suite(
            ResearchSuiteConfig(
                precision_cases=64,
                target_counts=(8, 12, 16),
                replicas=3,
                horizon_ticks=80,
                seed=117,
            )
        )

    def test_claim_gate_keeps_theorem_boundary(self):
        gate = self.result["research_core"]["claim_gate"]
        self.assertEqual(gate["R3_theorem_or_fluid_limit_computational_assistance"], "complete_as_diagnostic_pipeline")
        self.assertEqual(gate["Deng_Hani_Ma_theorem_reproduced"], "no")

    def test_periodic_momentum_is_exact(self):
        scales = self.result["research_core"]["r2_paper_aligned_finite_experiments"]["scales"]
        for scale in scales:
            for replica in scale["replicas"]:
                self.assertEqual(replica["initial_momentum"], replica["final_momentum"])

    def test_hash_and_nested_hashes_detect_tampering(self):
        self.assertTrue(verify_research_evidence(self.result)["valid"])
        tampered = json.loads(json.dumps(self.result))
        tampered["research_core"]["r2_paper_aligned_finite_experiments"]["scales"][0]["replicas"][0]["collisions"] += 1
        verification = verify_research_evidence(tampered)
        self.assertFalse(verification["valid"])
        self.assertTrue(verification["nested_failures"])


if __name__ == "__main__":
    unittest.main()
