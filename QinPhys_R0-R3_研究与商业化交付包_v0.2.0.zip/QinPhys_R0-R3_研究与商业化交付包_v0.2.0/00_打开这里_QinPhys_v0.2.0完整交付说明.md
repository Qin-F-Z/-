# QinPhys v0.2.0 R0–R3 完整交付说明

发布日期：2026-07-31

## 最终结论

本交付已经把 R0–R3 做成可运行、可测试、可出证据、可编译论文和可商业演示的工程管线：

- R0：有限状态、轨迹和哈希重复一致；
- R1：80 位 Decimal 高精度事件审计完成；
- R2：二维周期环面、有限 Poisson 系综、Boltzmann–Grad 参数账本和论文相关经验观测量完成；
- R3：守恒门、置信区间、有限尺度回归、结论分级和失败状态完成。

这里的 R2/R3“完成”是实验和诊断系统完成，不是邓煜–Hani–Ma 定理或流体极限被数学证明。软件、证据和 LaTeX 论文均明确保留这一边界。

## 优先打开

1. `README.md`：安装、运行、验证和目录；
2. `dist/index.html`：商业双界面静态构建，建议通过 `run_web.ps1`/`.sh` 打开；
3. `paper/QinPhys_R0-R3_研究论文_v0.2.0.pdf`：正式 7 页论文；
4. `paper/main.tex`：可编辑 LaTeX 源文档；
5. `build/research/qinphys-r1-r3-evidence.json`：完整研究证据；
6. `build/research/hardware-benchmark.json`：硬件与峰值内存实测；
7. `schemas/`：R0 与研究证据 Schema；
8. `SHA256SUMS.txt`：全部交付文件完整性清单。

## 一键验收

```powershell
powershell -ExecutionPolicy Bypass -File verify_all.ps1
powershell -ExecutionPolicy Bypass -File run_web.ps1
```

完整重算 R1–R3：

```powershell
powershell -ExecutionPolicy Bypass -File reproduce_research.ps1
```

正式研究矩阵哈希：

`sha256:6437735f9264f4a38db5b4daa2e0db80ce11ea27a1116d7e52f004370074052e`

## 验证摘要

- Python：9/9 测试通过；
- JavaScript：5/5 测试通过；
- R0 Python/JavaScript 固定向量差异：0；
- R1：512/512 tick 与 80 位 Decimal 最近 tick 一致；
- R2：3 个目标尺度 × 8 个有限副本；
- R3：6/6 工程质量门通过；全部副本动量逐整数守恒；
- 研究证据总哈希和所有嵌套副本哈希通过；
- 商业计算台、研究验证台、模拟台和浏览器证据校验通过；
- LaTeX 论文由 Tectonic 编译，7 页逐页视觉复核通过。

## 商业化边界

当前版本适合受控演示、专利实施例、研究合作、确定性计算验证试点和 SDK 评估。生产 SaaS 仍需增加账户/权限、多租户隔离、签名与撤销、SBOM、资源配额、数据删除、计费、SLA 和第三方安全审计。

专利提交前不要公开完整源码、研究证据或权利要求级流程。代码许可见 `LICENSE-EVALUATION.txt`。
