# Threat model

## Protected assets

Customer structures, source files, models, pseudopotentials, credentials,
signing keys, evidence integrity, claim semantics, compute capacity, and
confidential research conclusions.

## Primary threats and controls

| Threat | Control in v0.3.0 | Production control still required |
|---|---|---|
| Malicious input triggers commansignature cannot prove scientific correctness. Parsing cannot safely
interpret every future engine version. Thresholds are screening policies, not
universal physical laws. Production deployment must add trusted builders,
attestation, key governance, version-qualified parsers, and expert review.
