# Threat model

## Protected assets

Customer structures, source files, models, pseudopotentials, credentials,
signing keys, evidence integrity, claim semantics, compute capacity, and
confidential research conclusions.

## Primary threats and controls

| Threat | Control in v0.3.0 | Production control still required |
|---|---|---|
| Malicious input triggers command execution | Guards are read-only; runner requires `--execute`, fixed `pw.x`, argument vector and root-confined input | Immutable sandbox, seccomp/AppArmor and hostile-input assessment |
| Evidence JSON is edited | Canonical core hash, evidence ID and five signed top-level release documents | Externally anchored trust root and timestamp |
| Artifact path escapes workspace | Relative-path and root-containment checks | OS/container mount isolation |
| Missing engine is reported as success | Capability check remains `unknown` | Managed engine inventory |
| Failed/unknown check is hidden | Passing claims cannot depend on non-pass checks | Review and transparency log |
| Model card points to different model | Optional model digest binding | Sealed registry and access policy |
| Signature key is stolen | Public trust policy and revoke/supersede transparency events | HSM/KMS, dual control, external timestamp and independent log witness |
| Resource exhaustion | Thread/input limits, deadlines and a tested verifier worker with CPU/memory/PID quotas | Equivalent isolation for all engine workers and streaming disk limit |
| Dependency or image compromise | Version/digest snapshots, pinned verifier base and model digest | Complete SBOM, signed engine images and vulnerability scanning |
| Customer data exfiltration | No network required | Egress deny, telemetry policy, DLP |

## Residual risks

Canonical hashing alone cannot prove that the producer executed the declared code;
v0.3.0 strengthens this with engine logs and runtime provenance but does not add
hardware attestation.
An embedded public key cannot establish a trusted legal identity. The bundled
local public trust root is replaceable by anyone able to replace the whole
package, so its fingerprint must be distributed through an independent
customer-approved channel. A valid
signature cannot prove scientific correctness. Parsing cannot safely
interpret every future engine version. Thresholds are screening policies, not
universal physical laws. Production deployment must add trusted builders,
attestation, key governance, version-qualified parsers, and expert review.
