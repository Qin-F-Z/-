# QINSCIENCE v0.3.0 acceptance record

Release acceptance requires all of the following:

- 30 unit tests pass, including tamper, fail-closed execution and trust-log tests;
- the deterministic release builder punt changes without a versioned contract update, or clean-copy verification fails.

This record accepts a local engineering release. It does not accept external scientific validity, HSM identity assurance, trusted timestamping, hostile multi-tenant engine execution, customer operational acceptance, legal certification or patent grant.
