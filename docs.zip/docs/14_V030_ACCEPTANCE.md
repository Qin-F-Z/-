# QINSCIENCE v0.3.0 acceptance record

Release acceptance requires all of the following:

- 30 unit tests pass, including tamper, fail-closed execution and trust-log tests;
- the deterministic release builder produces exactly 28 pre-portfolio evidence documents plus one release portfolio;
- every document in the fixed release contract verifies against the supplied artifact tree;
- QE has nine valid run documents, a valid summary and a passing run monitor;
- LAMMPS/ASE has three valid real-run documents, a valid summary and a passing monitor;
- MACE has one valid real-engine summary and a passing monitor;
- the hardened worker acceptance evidence is valid while external certification remains unknown;
- four primary scientific/deployment claim maps exactly match their fixed pass/unknown contracts;
- five signed top-level documents verify against the public trust store and the five-entry transparency log;
- the private key is not included in the repository or release ZIP;
- the unsigned and signed release SHA-256 manifests verify;
- two consecutive ZIP builds are byte-identical;
- a clean extracted copy completes `verify_all.ps1` without executing external scientific engines.

The release fails acceptance if any unknown is relabelled pass, an artifact digest changes, a transparency link breaks, a self-signed key replaces the trusted key, the private key enters the package, the evidence count changes without a versioned contract update, or clean-copy verification fails.

This record accepts a local engineering release. It does not accept external scientific validity, HSM identity assurance, trusted timestamping, hostile multi-tenant engine execution, customer operational acceptance, legal certification or patent grant.
