# Private deployment baseline

## Recommended topology

- Customer-controlled source repository and artifact storage.
- Offline or egress-denied validation workers.
- Separate engine runners for QE, LAMMPS, and MACE; guards remain read-only.
- Append-only evidence registry and externally managed signing service.
- CI integration invokes `qinscience monitor` and rejects invalid evidence.
- Customer-managed encryption keys, backups, retention, and deletion policy.

## Container controls

The included Compose baseline uses a read-only root filesystem, drops Linux
capabilities, disables privilege escalation, limits processes and memory, uses
a non-root user, mounts customer inputs read-only, and provides a separate
writable output volume. Production engine images should be derived separately
because engine licensing, MPI/GPU drivers, pseudopotentials, and models are
customer-specific.

v0.3.0 additionally builds and executes the pinned `qinscience-worker:0.3.0`
verifier image with `--network none`, a read-only root, user `10001:10001`, all
capabilities dropped, no-new-privileges, PID/CPU/memory limits and a `noexec`
temporary filesystem. The acceptance evidence is local and does not certify the
Docker host. QE, LAMMPS and MACE engine workers remain a separate production
hardening task.

## Data retention

QINSCIENCE evidence should normally retain hashes and metadata, not duplicate
confidential source, structures, models, or raw trajectories. Customer policy
must define whether artifacts remain local, how long temporary workspaces live,
who can decrypt them, and how deletion is evidenced.

## Operational gates

- No shell=True execution.
- No automatic pseudopotential, model, or plugin download.
- No network access unless a specific connector is approved.
- Per-job wall-time, CPU, GPU, memory, disk, and output-count quotas.
- Immutable runner images and recorded image digests.
- Separate signing identity from compute worker identity.
- Signed releases, SBOM, dependency lock, vulnerability response, and key
  rotation before production.
