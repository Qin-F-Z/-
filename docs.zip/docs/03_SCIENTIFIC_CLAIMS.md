# Scientific claim policy

## Claims permitted by this release

- A supplied file has the recorded SHA-256 digest and size.
- A QE/LAMMPS/ASE/MACE input or output contains the fields or markers explicitly
  parsed by the adapter.
- The built-in reference kernel replays identically for a declared finite case.
- Declared checks and their thresholds passed, failed, or remained unknown.
- A monitoring snapshot verified the listed evidence under its local policy.

## Claims prohibited without more evidence

- A DFT functional, basis, pseudopotential, or spin state is physically correct.
- A converged SCF result is the unique or experimentally correct solution.
- A small MD energy drift proves correct dynamics or ensemble sampling.
- Bit-identical chaotic trajectories are more physically accurate than
  statistically equivalent trajectories.
- A MACE holdout MAE proves transferability or long-time stability.
- The four illustrative demos predict real glasses, electrolytes, catalysts, or
  defects.
- Finite computation proves a continuum, thermodynamic, Boltzmann, NSF, or Euler
  limit theorem.

## Production evidence required by domain

### DFT

Input and output hashes, code build, pseudopotential hashes, structure, units,
functional, spin and occupation choices, cutoff and k-point convergence,
SCF/geometry thresholds, alternate initializations where relevant, force and
stress checks, and cross-code or all-electron reference where justified.

### Molecular dynamics

Force-field and topology hashes, integrator, timestep convergence, neighbor
settings, thermostat/barostat definition, random-stream contract, conserved or
extended quantities, replica statistics, equilibration, autocorrelation,
finite-size analysis, and experimental or higher-level reference where needed.

### Machine-learning potentials

Training/validation/test data lineage, deduplication, reference method,
configuration domain, deterministic policy, model digest, sealed holdout
recomputation, energy-force consistency, out-of-domain detection, long-run MD
stability, and risk-selected DFT spot checks.

