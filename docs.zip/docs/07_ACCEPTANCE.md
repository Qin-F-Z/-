# Acceptance and release gates

## v0.3.0 implemented gates

- QinEvidence schema and independent verifier reject core, ID, artifact and
  nested-snapshot tampering.
- A passing claim cannot depend on a failed or unknown check.
- External execution requires explicit authorisation and the fixed `pw.x`
  backend; path, input, timeout, output and overwrite policy are enforced.
- Nine real Quantum ESPRESSO 7.5 runs are bound to exact inputs,
  pseudopotential, stdout, stderr and runtime metadata.
- The cutoff, k-point and force screens pass without relaxing their predeclared
  thresholds; the vacancy result is computed and external scientific validation
  remains unknown.
- Safe resume rejects invalid or non-passing prior evidence.
- QE/LAMMPS fixture guards, live ASE parsing, MACE manifest review, four
  deterministic reference cases and portfolio monitoring remain regression
  tested.
- Full verification runs offline once the repository and included third-party
  pseudopotential have been supplied.
- Three real LAMMPS executions and an ASE reference agree within the fixed LJ
  threshold; two quench replays produce byte-identical final dumps.
- Real MACE CPU/GPU checks, exact GPU replay, EOS scan and an 8/64/216-atom
  vacancy-size screen are bound to one exact model digest.
- The verifier worker image is pinned and locally accepted under non-root,
  network-none, read-only, capability-free and resource-limited controls.
- The 29-document release contract passes; five top-level documents have
  trusted Ed25519 signatures and five valid hash-chain issue records.

See `14_V030_ACCEPTANCE.md` for package-level release acceptance.

## Gates required before production claims

- Apply immutable non-root isolation to QE/LAMMPS/MACE engine workers, add
  streaming-output quotas and complete hostile-input campaigns.
- Pin approved QE/LAMMPS/MACE images and produce SBOM, signatures and provenance.
- Add supercell extrapolation, cross-code baselines and qualified domain review
  for any scientific claim offered to customers.
- Move the local signing key to customer-managed HSM/KMS, add a trusted
  timestamp and independently witnessed transparency publication.
- Complete backup/recovery, deletion evidence, security assessment, paid-pilot
  acceptance, contracts, patent search and external scientific/legal review.
