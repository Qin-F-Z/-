# Architecture and trust boundaries

## Product layers

1. **QinEvidence** defines the evidence envelope, canonical identity,
   artifacts, checks, claims, lifecycle, and signatures.
2. **QinDFT Guard** inspects Quantum ESPRESSO inputs and outputs and records
   convergence evidence without claiming that an approximate functional is
   physically exact.
3. **QinMD Guard** inspects LAMMPS protocols/logs and ASE structures. It
   separates trajectory replay, ensemble diagnostics, and physical validity.
4. **QinMLP Guard** binds model card, training-data digest, model digest,
   deterministic execution policy, metrics, domain, and excluded cases.
5. **QinReference** is a small deterministic audit oracle and regression
   target. It is not a production force field.
6. **QinMonitor** re-verifies an evidence portfolio for CI or scheduled use.
7. **QinRunner** executes only explicitly authorised, allow-listed scientific
   jobs and binds command policy, runtime, logs, inputs and pseudopotentials.
8. **QinGolden** aggregates verified run evidence into declared numerical
   screening and deliberately separate scientific-validation claims.
9. **QinTrust** evaluates Ed25519 signatures against an explicit public trust
   store and a hash-chained issue/revoke/supersede transparency log.
10. **QinWorker** provides a pinned, non-root, network-denied, read-only verifier
    container acceptance baseline. External scientific engines remain separate.

## QinEvidence identity

The evidence document contains `core` and `integrity`.

```text
core_hash   = SHA-256(qin-canonical-json(core))
evidence_id = "urn:qinevidence:" + core_hash
signature   = Ed25519-sign(ASCII(core_hash))
```

The signature array is outside `core`; adding a signature does not change the
scientific evidence identifier. Changing any model, result, check, limitation,
artifact digest, environment record, lifecycle declaration, or claim changes
the core hash and evidence identifier.

## Three levels of computational agreement

- **Execution agreement:** same declared finite engine and input produce the
  same evidence-bound result.
- **Statistical agreement:** independent trajectories or solvers yield
  compatible observables within declared uncertainty.
- **Physical validity:** the model and observables agree with appropriate
  benchmark theory or experiment within a declared domain.

No lower level implies a higher level. The schema and claim rules preserve this
separation.

## External engine policy

Guards remain read-only. v0.3.0 retains a local/private-worker WSL runner with an
allow-listed executable, non-shell argument vector, root-confined paths, dual
timeout, explicit overwrite policy and post-run artifact collection. Guard
inspection never authorises execution. A hostile multi-tenant production runner
still requires immutable engine containers, read-only input mounts, streaming
output quotas, network disabled by default, OS CPU/GPU/memory quotas and
ephemeral storage. The included verifier image demonstrates a subset of those
controls; it does not sandbox QE, LAMMPS or MACE execution.
