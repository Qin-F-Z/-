# Architecture and trust boundaries

## Product layers

1. **Qin-denied, read-only verifier
    container acceptance baseline. External scientific engines remain separate.

## QinEvidence identity

The evidence document contains `core` and `integrity`.

```text
core_hash   = SHA-256(qin-cr solvers yield
  compatible observables within declared uncertainty.
- **Physical validity:** the model and observables agree with appropriate
  benchmark theor
