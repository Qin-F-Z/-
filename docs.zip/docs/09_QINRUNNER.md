# QinRunner v0.3.0 execution contract

## Security objective

QinRunner turns an explicitly authorised scientific job into a bounded process
and a QinEvidence document. Supplying an input file is not authorisation. The
caller must pass `--execute`; the only executable accepted in v0.3.0 is `pw.x`.

## Enforced controls

1. WSL distribution names and file names use a restricted character set.
2. The work directory and input must resolve beneath the declared artifact root;
   the input must also be inside the work directory.
3. Symlink inputs and inputs above the declared byte limit are refused.
4. The command is an argument vector, not a shell string. No input value is
   interpolated into a shell program.
5. Linux `timeout` and the Windows parent process provide separate deadlines.
6. Threads, timeout, input bytes and captured-output bytes are policy values
   embedded in evidence.
7. stdout and stderr are stored separately and hash-bound with the input and all
   declared pseudopotentials.
8. Existing exact run products are not overwritten without explicit authority.

## Resume contract

`--resume` is not a blind file-existence shortcut. Before reusing a run, the
independent verifier checks its canonical hash and every bound artifact. The
subject prefix must match the declared run and both operational and result claims
must be `pass`. Any mismatch stops the workflow. `--resume` and `--overwrite`
cannot be combined.

## Known v0.3.0 boundary

The output-size rule is evaluated after the child process returns because Python
captures the pipes in memory. It detects and rejects oversized results but does
not provide streaming back-pressure. Therefore this runner is suitable for a
trusted single-user workstation and controlled private worker, not yet a hostile
multi-tenant execution service. A production service must add OS/container
resource quotas, streaming log truncation, read-only images, non-root workers,
network denial and per-job ephemeral storage.

No runner control proves that a functional, pseudopotential, cell, k mesh or
scientific interpretation is correct. Those are separate evidence obligations.
