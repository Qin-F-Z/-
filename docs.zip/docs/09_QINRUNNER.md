# QinRunner v0.3.0 execution contract

## Security objective

QinRunner turns an explicitlyersized results but does
not provide streaming back-pressure. Therefore this runner is suitable for a
trusted single-useread-only images, non-root workers,
network denial and per-job ephemeral storage.

No runner control proves that a functional, pseudopotential, cell, k mesh or
scientific interpretation is correct. Those are separate evidence obligations.
