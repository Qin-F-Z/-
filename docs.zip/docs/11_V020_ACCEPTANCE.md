# QINSCIENCE v0.2.0 acceptance record

Release acceptance requires all of the following:

- the full unit suite passesnt evidence and
  independently verify the bundled golden evidence without network access.

The release is not accepted if a failed or unknown claim is relabelled, a run is
reused without verification, a package omits artifacts needed by the independent
verifier, or real and synthetic outputs are not clearly distinguished.
