# QINSCIENCE v0.2.0 acceptance record

Release acceptance requires all of the following:

- the full unit suite passes;
- the independent verifier accepts the real QE golden summary and run monitor
  against the supplied artifact tree;
- nine run evidence documents remain valid and operational;
- cutoff, k-point and force screens are `pass`;
- the computed vacancy claim is `pass` while independent scientific validation
  remains `unknown`;
- pseudopotential bytes and provenance metadata are included with third-party
  licensing notice;
- scratch wavefunctions and engine temporary directories are excluded from the
  source/evidence ZIP;
- two consecutive package builds have identical SHA-256 hashes;
- a clean extracted copy can run unit tests, rebuild development evidence and
  independently verify the bundled golden evidence without network access.

The release is not accepted if a failed or unknown claim is relabelled, a run is
reused without verification, a package omits artifacts needed by the independent
verifier, or real and synthetic outputs are not clearly distinguished.
