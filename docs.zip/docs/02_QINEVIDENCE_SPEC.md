# QinEvidence 1.0 profile

The normative machine contract is
`schemas/qinevidence-1.0.0.schema.json`. This document explains additional
semantic requirements enforced by the verifier.

## Required invariants

- The canonicalized `core` SHA-256 digest equals `integrity.core_hash`.
- `evidence_id` is derived from that exact digest.
- Check and claim identifiers are unique.
- Every claim references existing checks.
- A passing claim cannot depend on a failed, unknown, or not-applicable check.
- Artifact paths are relative, traversal-free, and confined to an explicitly
  supplied artifact root.
- `expired`, `revoked`, and `superseded` evidence is not currently valid.
- Unknown results remain unknown; the verifier never upgrades them to pass.
- Unsigned integrity-valid evidence is reported as unsigned, not signed.

## Signatures and trust

Embedded Ed25519 verifies cryptographic possession of a private key. It does
not itself establish the legal identity, authorization, security, or current
trust status of that key. Production deployments should maintain an external
trust registry, revocation list, key rotation procedure, and trusted timestamp
service. These external trust decisions are deliberately not fabricated by the
offline verifier.

## Lifecycle

The producer can declare `valid`, `revoked`, or `superseded` and an optional
expiry. A production transparency service should publish revocation and
supersession records. v0.3.0 verifies embedded lifecycle and expiry offline; it
does not fetch remote revocation state.

## Schema evolution

- Patch versions may clarify prose but must not change canonical semantics.
- Minor versions may add optional fields while retaining verifier compatibility.
- Major versions may change semantics and require a new schema URI and verifier.
- Producers must never silently reinterpret old evidence using a new profile.
