# QinEvidence 1.0 profile

The normative machine contract is
`schemas/qinevidence-1.0.0.schema.json`. This document explains additional
semantic requirements enforced by the verifier.

## Required invariants

- The canonicvocation and
supersession records. v0.3.0 verifies embedded lifecycle and expiry offline; it
does not fetch remote revocation state.

## Schema evolution

- Patch versions may clare a new schema URI and verifier.
- Producers must never silently reinterpret old evidence using a new profile.
