# Commercial packaging: private deployment, project validation, monitoring, OEM

## Offer 1 — Private deployment

Customer receives the validation service, evidence schema, verifier, engine
adapters, policy configuration, release provenance, and deployment runbook.
Pricing should be annual platform licence plus deployment/support tier, not a
low-price per-simulation commodity.

Acceptance should cover isolation, supported engine/version matrix, evidence
reproduction, retention, deletion, RBAC integration, backup, recovery, and
support response. The customer retains responsibility for scientific model
selection unless an explicitly scoped expert-review service is purchased.

## Offer 2 — Project validation

Fixed-scope engagement for one calculation campaign. Deliverables include
model and input inventory, convergence protocol, selected reruns, discrepancy
analysis, QinEvidence package, independent verification instructions, covered
claims, exclusions, and unresolved risks.

Never price or describe this as a guarantee that a material will work. It is a
bounded computational validation service.

## Offer 3 — Continuous monitoring

CI or scheduled re-verification of evidence and artifact digests. Commercial
value comes from detecting stale certificates after code, model, parameter,
input, pseudopotential, or dependency changes. v0.3.0 provides the one-shot
monitoring primitive; enterprise scheduling, notification, registry, and remote
revocation are deployment integrations.

## Offer 4 — OEM/white label

OEM partners embed the versioned schema, CLI or Python API, independent
verifier, and guard result contract. Required OEM terms should cover:

- namespace and stable identifier ownership;
- attribution and white-label presentation;
- compatibility and deprecation windows;
- customer support split and incident ownership;
- evidence and signing-key ownership;
- telemetry disabled by default for private code;
- no modification that converts unknown or fail into pass;
- engine, model, dataset, and open-source licence responsibilities;
- audit rights for certification-related representations.

## Initial customer priority

1. Battery and solid-electrolyte computation teams.
2. Semiconductor and defect/surface modeling teams.
3. Catalysis and materials-AI teams using DFT-to-MLP pipelines.
4. Nuclear and aerospace programs where provenance and change control matter.
5. Simulation vendors and audit firms as OEM partners.

Universities are valuable benchmark and validation partners but should not be
the only assumed source of high-margin platform revenue.

## v0.3.0 monetisation gate

The most defensible first offer is a paid, fixed-scope validation pilot using
the signed evidence package and an agreed acceptance matrix. Convert successful
pilots into annual private-deployment licences plus continuous re-verification.
The deterministic simulator is a test oracle and demonstration asset, not the
low-price product. OEM agreements should reserve evidence semantics, verifier
compatibility and the rule that unknown/fail may not be relabelled.
