Commercial packaging: private deployment, project validation, msful
pilots into annual private-deployment licences plus continuous re-verification.
The deterministic simulator is a test oracle and demonstration asset, not the
low-price product. OEM agreements should reserve evidence semantics, verifier
compatibility and the rule that unknown/fail may not be relabelled.

