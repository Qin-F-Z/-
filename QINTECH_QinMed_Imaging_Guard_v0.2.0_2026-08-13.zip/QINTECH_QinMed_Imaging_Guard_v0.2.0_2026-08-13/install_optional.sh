#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PYTHON=${QINMED_PYTHON:-python3}
"$PYTHON" -m pip install --disable-pip-version-check --no-input -r "$ROOT/requirements-optional.txt"
echo 'PASS: fastMRI, DICOM, and signing dependencies installed.'

