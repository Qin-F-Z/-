# QinMed Imaging Guard v0.2.0 本机验收报告

验证日期：2026-08-13  
结论：**PASS WITH DECLARED EXTERNAL BOUNDARIES**  
患者数据：**NONE**，随包 fastMRI、盲测和 DICOM 扩展示例均为本机合成数据。

## 已通过

- Python 单元与集成测试：10 / 10 PASS。
- JavaScript 引擎：舍入、重放、范围、指标与 SHA-256 PASS。
- fastMRI Guard：兼容 HDF5 检查、单/多线圈零填充/RSS、12-bit PGM 冻结与源承诺 PASS。
- 锁定协议评测：案例清单、模型身份、指标、阈值、失败政策、bootstrap 种子和输出合同均被哈希绑定；缺失案例计失败。
- DICOM Guard：直接标识符、私有元素、overlay、日期、UID 与嵌套序列处理通过合成测试；像素烧录状态不明确时失败闭合。
- QinEvidence：fastMRI、盲测、DICOM 三套示例均通过工件哈希、Ed25519 验签和独立公钥指纹固定，状态为 `SIGNED_TRUSTED`。
- 篡改拒绝：修改证据核心或锁定协议后验证失败。
- 离线浏览器与 Python 证据规范互操作 PASS；CSP 禁止网络连接。
- UI：1440×1100 桌面和 390×844 真实移动 viewport 视觉验收通过。
- 技术验收书：Word 与 LibreOffice 双渲染，最终 7 页，无空白页或裁切；高严重度可访问性问题为 0。

## 明确边界

- DICOM 模块是研究级最小隐私门，`profile_conformance = not_claimed`；不宣称 PS3.15 完整符合、像素无 PHI 或 PACS 生产兼容。
- 浮点 FFT 结果未证明跨 NumPy、CPU、指令集或硬件逐位一致；可复验保证落在冻结后的整数工件和哈希。
- 本机协议锁定不能证明操作者盲法；正式结论需要独立数据托管、隔离执行与审计日志。
- 未完成临床有效性、读片研究、质量体系、监管批准、HSM/KMS 组织身份、可信时间戳和正式撤销服务。

## 参考样例

64×64、12-bit、Half Even、noise=5、seed=20260813：

- 认证输出 SHA-256：`4b491689c248172c75797c397b72458205aba701f15ef70e67797469428c7cea`
- 模型代理输出 SHA-256：`ecfca62bac674ecaba3ccdecc67d2ba174933bd83868e98da39e7c579929f566`
- MAE：19.7880859375 codes
- 最大绝对差：393 codes
- PSNR：39.10441961692832 dB

这些数值仅描述随包合成样例，不代表临床性能、设备性能或对主流算法的优势。
