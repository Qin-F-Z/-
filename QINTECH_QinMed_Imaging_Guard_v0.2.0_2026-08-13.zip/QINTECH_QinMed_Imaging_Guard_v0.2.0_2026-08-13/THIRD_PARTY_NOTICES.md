# Third-party notices

The browser and deterministic core use platform or Python standard-library APIs. Optional real-data capabilities use separately installed packages; they are not vendored into this release archive.

| Package | Tested version | License | Project |
|---|---:|---|---|
| NumPy | 2.3.5 | BSD-3-Clause | https://numpy.org/ |
| h5py | 3.16.0 | BSD-3-Clause | https://www.h5py.org/ |
| pydicom | 3.0.2 | MIT | https://pydicom.github.io/ |
| cryptography | 50.0.0 | Apache-2.0 OR BSD-3-Clause | https://cryptography.io/ |

fastMRI data and code are not redistributed as third-party patient data in this package. The included `.h5` fixture is generated locally from a QinMed synthetic phantom and is explicitly marked `patient_data=NONE`. Users must obtain and comply with any dataset or model license independently.

