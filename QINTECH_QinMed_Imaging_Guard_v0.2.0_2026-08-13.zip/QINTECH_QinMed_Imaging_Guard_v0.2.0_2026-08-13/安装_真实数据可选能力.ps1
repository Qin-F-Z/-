$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Python = if ($env:QINMED_PYTHON) { $env:QINMED_PYTHON } else { (Get-Command python.exe -ErrorAction Stop).Source }
& $Python -m pip install --disable-pip-version-check --no-input -r (Join-Path $Root 'requirements-optional.txt')
if ($LASTEXITCODE -ne 0) { throw 'Optional dependency installation failed.' }
Write-Host 'PASS: fastMRI, DICOM, and signing dependencies installed.' -ForegroundColor Green

