# Changelog

## 0.2.0 — 2026-08-13

- Added fastMRI-compatible HDF5 inspection and deterministic 12-bit artifact freezing.
- Added locked-protocol, file-contract blind evaluation with failure retention and deterministic bootstrap.
- Added research-grade DICOM privacy gate with fail-closed burned-in annotation handling.
- Added Ed25519 key generation, signing, trusted-fingerprint verification and signed example evidence.
- Distinguished `unsigned`, `signed_untrusted` and `signed_trusted` assurance.
- Added protocol/schema assets, threat-boundary documentation, pilot SOW, patent supplement and 30-day external-validation checklist.
- Added reproducible desktop/mobile UI capture and commercial capability gates.
- Expanded automated tests from 5 to 10 and added required optional-dependency verification.

## 0.1.0 — 2026-08-13

- Initial deterministic integer imaging demonstrator, browser/Python evidence interoperation and independent verifier.
