"""QinEvidence 1.0 producer for QinMed Imaging Guard."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any

from .imaging import Config

SCHEMA = "https://schemas.qinscience.com/qinevidence/1.0.0.json"


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest_json(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def wrap_core(core: dict[str, Any]) -> dict[str, Any]:
    """Wrap an immutable evidence core in the QinEvidence 1.0 envelope."""
    core_hash = digest_json(core)
    return {
        "$schema": SCHEMA,
        "spec_version": "1.0.0",
        "evidence_id": "urn:qinevidence:" + core_hash,
        "core": core,
        "integrity": {"canonicalization": "qin-canonical-json/1", "core_hash": core_hash, "signatures": []},
    }


def build_evidence(
    config: Config,
    hashes: dict[str, str],
    observed: dict[str, float | int | bool | None],
    perturbation: dict[str, object],
    generated_at: str | None = None,
) -> dict[str, Any]:
    timestamp = generated_at or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    deterministic = hashes.get("replay_hash") == hashes.get("replay_hash_repeat")
    perturbation_status = "pass" if perturbation.get("trials", 0) >= 2 else "unknown"
    core = {
        "evidence_kind": "qinmed-imaging-audit",
        "generated_at": timestamp,
        "subject": {
            "product": "QinMed Imaging Guard Research Edition",
            "profile": "synthetic-phantom-post-acquisition-audit",
            "intended_use": "research verification and algorithm QA only",
        },
        "producer": {"name": "QINTECH", "component": "qinmed.reference"},
        "engine": {"name": "QinMed deterministic reference", "version": "0.2.0"},
        "inputs": [],
        "outputs": [],
        "execution": {
            "size": config.size,
            "adc_bits": config.adc_bits,
            "rounding": config.rounding.value,
            "noise_codes": config.noise_codes,
            "seed": config.seed,
            "filter_radius": config.filter_radius,
            "edge_threshold": config.edge_threshold,
            "model_strength_percent": config.model_strength_percent,
        },
        "results": {"hashes": hashes, "observed_metrics": observed, "perturbation": {k: v for k, v in perturbation.items() if k != "range_map"}},
        "checks": [
            {"id": "qinmed.replay", "status": "pass" if deterministic else "fail", "statement": "Same engine and declared input replay to the same output digest.", "severity": "high", "observed": deterministic, "expected": True, "evidence_paths": ["core.results.hashes.replay_hash", "core.results.hashes.replay_hash_repeat"]},
            {"id": "qinmed.perturbation", "status": perturbation_status, "statement": "Declared perturbation trials were executed and reported without upgrading observation to proof.", "severity": "high", "observed": perturbation.get("trials", 0), "expected": 2, "unit": "trials", "evidence_paths": ["core.results.perturbation"]},
            {"id": "qinmed.clinical_validation", "status": "unknown", "statement": "Clinical safety and effectiveness have not been established.", "severity": "critical", "observed": "not_performed", "expected": "independent_clinical_validation", "evidence_paths": ["core.coverage.excluded"]},
        ],
        "claims": [
            {"id": "qinmed.deterministic_replay", "status": "pass" if deterministic else "fail", "statement": "The packaged reference engine replays this synthetic run deterministically.", "scope": "same implementation, configuration, and synthetic input", "check_ids": ["qinmed.replay"], "assumptions": ["integer semantics and canonical serialization remain unchanged"], "exclusions": ["cross-browser certification", "clinical equivalence"]},
            {"id": "qinmed.perturbation_observation", "status": perturbation_status, "statement": "Output drift was measured for the declared synthetic perturbation set.", "scope": "finite declared perturbation trials only", "check_ids": ["qinmed.perturbation"], "assumptions": ["synthetic perturbation generator is the declared threat model"], "exclusions": ["worst-case proof", "distribution shift", "patient outcome"]},
            {"id": "qinmed.clinical_use", "status": "unknown", "statement": "Clinical diagnostic use is not established.", "scope": "clinical use", "check_ids": ["qinmed.clinical_validation"], "assumptions": [], "exclusions": ["diagnosis", "treatment selection", "patient management"]},
        ],
        "coverage": {
            "included": ["synthetic phantom", "post-acquisition integer requantization", "declared rounding", "integer edge-aware filter", "surrogate-output difference map", "finite perturbation observation", "hash binding"],
            "excluded": ["transistor-level ADC behavior", "DICOM conformance", "patient data", "trained medical AI", "clinical validation", "regulatory clearance", "hardware energy measurement"],
        },
        "environment": {"runtime": "Python standard library reference", "network": "not required"},
        "lifecycle": {"status": "valid", "supersedes": [], "revocation_uri": None},
    }
    return wrap_core(core)
