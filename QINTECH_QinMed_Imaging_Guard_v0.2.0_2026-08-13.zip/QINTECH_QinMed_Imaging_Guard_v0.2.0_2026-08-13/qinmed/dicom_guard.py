"""Conservative DICOM metadata audit and research de-identification guard.

This module deliberately does not claim full DICOM PS3.15 Basic Application
Level Confidentiality Profile conformance. It provides a fail-closed research
workflow and records unresolved pixel/burned-in risks.
"""

from __future__ import annotations

import hashlib
import hmac
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from .artifacts import artifact_record, sha256_file
from .evidence import wrap_core


IDENTIFIER_KEYWORDS = {
    "PatientName", "PatientID", "IssuerOfPatientID", "TypeOfPatientID", "PatientBirthDate", "PatientBirthTime",
    "PatientAddress", "OtherPatientIDsSequence", "OtherPatientNames", "PatientTelephoneNumbers", "PatientComments",
    "MedicalRecordLocator", "InstitutionName", "InstitutionAddress", "InstitutionalDepartmentName", "ReferringPhysicianName",
    "ReferringPhysicianAddress", "ReferringPhysicianTelephoneNumbers", "PerformingPhysicianName", "OperatorsName",
    "NameOfPhysiciansReadingStudy", "RequestingPhysician", "RequestingService", "AccessionNumber", "StudyID",
    "AdmissionID", "ServiceEpisodeID", "ProtocolName", "StationName", "DeviceSerialNumber", "StudyDescription",
    "SeriesDescription", "AcquisitionDeviceProcessingDescription", "ClinicalTrialSponsorName", "ClinicalTrialProtocolID",
    "ClinicalTrialSiteID", "ClinicalTrialSiteName", "ClinicalTrialSubjectID", "ClinicalTrialSubjectReadingID",
}

DATE_KEYWORDS = {
    "StudyDate", "SeriesDate", "AcquisitionDate", "ContentDate", "InstanceCreationDate", "OverlayDate", "CurveDate",
    "AcquisitionDateTime", "StudyTime", "SeriesTime", "AcquisitionTime", "ContentTime", "InstanceCreationTime",
}

UID_PRESERVE = {"SOPClassUID", "MediaStorageSOPClassUID", "TransferSyntaxUID", "ImplementationClassUID", "CodingSchemeUID"}


def _pydicom():
    try:
        import pydicom  # type: ignore
    except ImportError as exc:
        raise RuntimeError("DICOM support requires pydicom; install requirements-optional.txt") from exc
    return pydicom


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _token(secret: bytes, label: str, value: str, length: int = 16) -> str:
    return hmac.new(secret, (label + "\0" + value).encode("utf-8"), hashlib.sha256).hexdigest()[:length].upper()


def _uid(secret: bytes, value: str) -> str:
    number = int.from_bytes(hmac.new(secret, ("uid\0" + value).encode("utf-8"), hashlib.sha256).digest()[:16], "big")
    return "2.25." + str(number)


def _shift_date(value: str, days: int) -> str:
    if len(value) < 8 or not value[:8].isdigit():
        return ""
    try:
        shifted = datetime.strptime(value[:8], "%Y%m%d") + timedelta(days=days)
        return shifted.strftime("%Y%m%d") + value[8:]
    except ValueError:
        return ""


def _private_count(dataset: Any) -> int:
    count = 0
    for element in dataset:
        if element.tag.is_private:
            count += 1
        if element.VR == "SQ":
            count += sum(_private_count(item) for item in element.value)
    return count


def _identifier_findings(dataset: Any) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []
    identity_removed = str(dataset.get("PatientIdentityRemoved", "")).upper() == "YES"
    for element in dataset:
        value = str(element.value).strip()
        recognized_pseudonym = identity_removed and (
            (element.keyword == "PatientName" and value.startswith("QIN^"))
            or (element.keyword == "PatientID" and value.startswith("QIN-"))
        )
        if element.keyword in IDENTIFIER_KEYWORDS and value and not recognized_pseudonym:
            findings.append({"tag": str(element.tag), "keyword": element.keyword, "vr": element.VR})
        if element.VR == "SQ":
            for item in element.value:
                findings.extend(_identifier_findings(item))
    return findings


def audit_dicom(path: Path) -> dict[str, Any]:
    pydicom = _pydicom()
    dataset = pydicom.dcmread(str(path), force=False)
    burned = str(dataset.get("BurnedInAnnotation", "UNKNOWN")).upper()
    findings = _identifier_findings(dataset)
    private = _private_count(dataset)
    overlay = any(element.tag.group & 0xFF00 == 0x6000 for element in dataset)
    can_release = not findings and private == 0 and burned == "NO" and not overlay
    return {
        "audit_version": "0.2.0",
        "generated_at": _utc_now(),
        "input_file": path.name,
        "input_digest": sha256_file(path),
        "sop_class_uid": str(dataset.get("SOPClassUID", "")),
        "transfer_syntax_uid": str(getattr(dataset.file_meta, "TransferSyntaxUID", "")) if getattr(dataset, "file_meta", None) else "",
        "identifier_findings": findings,
        "identifier_finding_count": len(findings),
        "private_element_count": private,
        "burned_in_annotation": burned,
        "overlay_present": overlay,
        "pixel_data_present": "PixelData" in dataset,
        "pixel_ocr_performed": False,
        "research_release_gate": "pass" if can_release else "fail",
        "profile_conformance": "not_claimed",
        "limitations": [
            "No OCR or visual review of burned-in pixel text is performed.",
            "This implementation does not claim full DICOM PS3.15 Basic Application Level Confidentiality Profile conformance.",
            "Clinical export requires institutional privacy review and validated configuration.",
        ],
    }


def _sanitize_dataset(dataset: Any, secret: bytes, day_shift: int) -> dict[str, int]:
    counters = {"removed_identifiers": 0, "shifted_dates": 0, "remapped_uids": 0, "removed_overlays": 0}
    for element in list(dataset):
        keyword = element.keyword
        if element.tag.is_private or element.tag.group & 0xFF00 == 0x6000:
            del dataset[element.tag]
            counters["removed_overlays" if element.tag.group & 0xFF00 == 0x6000 else "removed_identifiers"] += 1
            continue
        if element.VR == "SQ":
            for item in element.value:
                child = _sanitize_dataset(item, secret, day_shift)
                for key, value in child.items():
                    counters[key] += value
            continue
        value = str(element.value)
        if keyword == "PatientName" and value:
            element.value = "QIN^" + _token(secret, keyword, value, 12)
            counters["removed_identifiers"] += 1
        elif keyword == "PatientID" and value:
            element.value = "QIN-" + _token(secret, keyword, value, 16)
            counters["removed_identifiers"] += 1
        elif keyword in IDENTIFIER_KEYWORDS:
            element.value = ""
            counters["removed_identifiers"] += 1
        elif keyword in DATE_KEYWORDS:
            element.value = _shift_date(value, day_shift) if element.VR in {"DA", "DT"} else ""
            counters["shifted_dates"] += 1
        elif element.VR == "UI" and keyword not in UID_PRESERVE and value:
            element.value = _uid(secret, value)
            counters["remapped_uids"] += 1
    return counters


def deidentify_dicom(input_path: Path, output_path: Path, report_path: Path, secret: bytes) -> dict[str, Any]:
    if len(secret) < 16:
        raise ValueError("de-identification secret must be at least 16 bytes")
    pydicom = _pydicom()
    dataset = pydicom.dcmread(str(input_path), force=False)
    burned = str(dataset.get("BurnedInAnnotation", "UNKNOWN")).upper()
    if "PixelData" in dataset and burned != "NO":
        raise ValueError("fail closed: PixelData exists and BurnedInAnnotation is not explicitly NO")
    patient_anchor = str(dataset.get("PatientID", "")) or str(dataset.get("PatientName", "")) or sha256_file(input_path)
    day_shift = int(_token(secret, "date-shift", patient_anchor, 8), 16) % 7301 - 3650
    input_digest = sha256_file(input_path)
    counters = _sanitize_dataset(dataset, secret, day_shift)
    dataset.PatientIdentityRemoved = "YES"
    dataset.DeidentificationMethod = "QinMed v0.2 partial; HMAC IDs; private and overlay removed"
    dataset.LongitudinalTemporalInformationModified = "MODIFIED"
    dataset.BurnedInAnnotation = "NO"
    if getattr(dataset, "file_meta", None) and "SOPInstanceUID" in dataset:
        dataset.file_meta.MediaStorageSOPInstanceUID = dataset.SOPInstanceUID
    output_path.parent.mkdir(parents=True, exist_ok=True)
    dataset.save_as(str(output_path), enforce_file_format=True)
    post_audit = audit_dicom(output_path)
    report = {
        "operation": "research-dicom-deidentification",
        "generated_at": _utc_now(),
        "input_file": input_path.name,
        "input_digest": input_digest,
        "output_file": output_path.name,
        "output_digest": sha256_file(output_path),
        "secret_fingerprint": "sha256:" + hashlib.sha256(secret).hexdigest(),
        "date_shift_days": day_shift,
        "actions": counters,
        "post_audit": post_audit,
        "release_decision": "conditional_pass" if post_audit["research_release_gate"] == "pass" else "fail",
        "profile_conformance": "not_claimed",
        "required_external_actions": ["institutional privacy review", "pixel visual review or validated OCR", "DICOM conformance testing", "authorized data-use confirmation"],
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    root = report_path.parent
    core = {
        "evidence_kind": "qinmed-dicom-deidentification-audit",
        "generated_at": report["generated_at"],
        "subject": {"product": "QinMed Imaging Guard Research Edition", "profile": "research-partial-deidentification", "intended_use": "research privacy preprocessing only"},
        "producer": {"name": "QINTECH", "component": "qinmed.dicom_guard"},
        "engine": {"name": "QinMed DICOM Guard", "version": "0.2.0"},
        "inputs": [],
        "outputs": [artifact_record(output_path, "de-identified DICOM candidate", "application/dicom", relative_to=root), artifact_record(report_path, "de-identification report", "application/json", relative_to=root)],
        "execution": {"input_digest": input_digest, "secret_fingerprint": report["secret_fingerprint"], "date_shift_days": day_shift, "fail_closed_burned_in": True},
        "results": {"release_decision": report["release_decision"], "actions": counters, "post_audit": {key: post_audit[key] for key in ("identifier_finding_count", "private_element_count", "burned_in_annotation", "overlay_present", "research_release_gate")}},
        "checks": [
            {"id": "qinmed.dicom.metadata", "status": "pass" if post_audit["identifier_finding_count"] == 0 else "fail", "statement": "Configured direct identifier fields were absent after processing.", "severity": "critical", "observed": post_audit["identifier_finding_count"], "expected": 0, "unit": "findings", "evidence_paths": ["core.results.post_audit"]},
            {"id": "qinmed.dicom.private", "status": "pass" if post_audit["private_element_count"] == 0 else "fail", "statement": "Private data elements were absent after processing.", "severity": "critical", "observed": post_audit["private_element_count"], "expected": 0, "unit": "elements", "evidence_paths": ["core.results.post_audit"]},
            {"id": "qinmed.dicom.pixel_phi", "status": "unknown", "statement": "Pixel-level identifying information was not independently ruled out by OCR and visual review.", "severity": "critical", "observed": "not_performed", "expected": "validated_ocr_and_visual_review", "evidence_paths": ["core.coverage.excluded"]},
            {"id": "qinmed.dicom.ps315", "status": "unknown", "statement": "Full DICOM PS3.15 confidentiality-profile conformance has not been established.", "severity": "critical", "observed": "not_claimed", "expected": "formal_conformance_validation", "evidence_paths": ["core.coverage.excluded"]},
        ],
        "claims": [
            {"id": "qinmed.dicom.configured_metadata", "status": "pass" if post_audit["research_release_gate"] == "pass" else "fail", "statement": "The output passed the configured metadata and burned-in flag gates.", "scope": "implemented research guard only", "check_ids": ["qinmed.dicom.metadata", "qinmed.dicom.private"], "assumptions": ["input BurnedInAnnotation is truthful"], "exclusions": ["pixel OCR", "full profile conformance"]},
            {"id": "qinmed.dicom.pixel_safety", "status": "unknown", "statement": "Pixel-level privacy safety remains unverified.", "scope": "pixel data", "check_ids": ["qinmed.dicom.pixel_phi"], "assumptions": [], "exclusions": ["visual review"]},
            {"id": "qinmed.dicom.conformance", "status": "unknown", "statement": "DICOM PS3.15 conformance is not claimed.", "scope": "formal conformance", "check_ids": ["qinmed.dicom.ps315"], "assumptions": [], "exclusions": ["institutional validation"]},
        ],
        "coverage": {"included": ["configured metadata identifiers", "private elements", "overlay groups", "deterministic UID remap", "date shifting", "burned-in annotation fail-closed gate", "artifact hashes"], "excluded": ["OCR", "visual privacy review", "all PS3.15 Table E.1-1 actions/options", "clinical workflow validation", "regulatory clearance"]},
        "environment": {"runtime": f"Python + pydicom {pydicom.__version__}", "network": "not required"},
        "lifecycle": {"status": "valid", "supersedes": [], "revocation_uri": None},
    }
    evidence = wrap_core(core)
    evidence_path = root / "dicom-deidentification.qinevidence.json"
    evidence_path.write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"report": report, "evidence": evidence, "evidence_path": evidence_path}
