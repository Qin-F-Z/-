"""Dependency-free deterministic imaging surrogate and audit routines.

This is a research/reference engine. It is deliberately modality-neutral and
does not claim clinical reconstruction performance.
"""

from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass
from typing import Iterable

from .fixed import Rounding, div_round, quantize_ratio


@dataclass(frozen=True)
class Config:
    size: int = 64
    adc_bits: int = 12
    rounding: Rounding = Rounding.HALF_EVEN
    noise_codes: int = 5
    seed: int = 20260813
    filter_radius: int = 1
    edge_threshold: int = 180
    model_strength_percent: int = 70

    def validate(self) -> None:
        if self.size not in {32, 64, 96, 128}:
            raise ValueError("size must be one of 32, 64, 96, 128")
        if not 8 <= self.adc_bits <= 16:
            raise ValueError("adc_bits must be in [8, 16]")
        if not 0 <= self.noise_codes <= 128:
            raise ValueError("noise_codes must be in [0, 128]")
        if not 1 <= self.filter_radius <= 2:
            raise ValueError("filter_radius must be 1 or 2")
        if not 0 <= self.edge_threshold <= 4095:
            raise ValueError("edge_threshold must be in [0, 4095]")
        if not 0 <= self.model_strength_percent <= 200:
            raise ValueError("model strength must be in [0, 200]")


class XorShift32:
    def __init__(self, seed: int):
        self.state = seed & 0xFFFFFFFF or 0x9E3779B9

    def next_u32(self) -> int:
        value = self.state
        value ^= (value << 13) & 0xFFFFFFFF
        value ^= value >> 17
        value ^= (value << 5) & 0xFFFFFFFF
        self.state = value & 0xFFFFFFFF
        return self.state

    def symmetric(self, amplitude: int) -> int:
        if amplitude <= 0:
            return 0
        return int(self.next_u32() % (2 * amplitude + 1)) - amplitude


def _inside_ellipse(x: float, y: float, cx: float, cy: float, rx: float, ry: float, angle: float) -> bool:
    cosine, sine = math.cos(angle), math.sin(angle)
    dx, dy = x - cx, y - cy
    u = dx * cosine + dy * sine
    v = -dx * sine + dy * cosine
    return (u * u) / (rx * rx) + (v * v) / (ry * ry) <= 1.0


def make_phantom(size: int, variant: str = "low_contrast") -> list[int]:
    """Generate a deterministic, non-patient synthetic phantom in 12-bit units."""
    if size < 16:
        raise ValueError("size must be at least 16")
    ellipses = [
        (0.00, 0.00, 0.69, 0.92, 0.00, 600),
        (0.00, -0.02, 0.64, 0.87, 0.00, 500),
        (0.22, 0.00, 0.11, 0.31, -0.31, 550),
        (-0.22, 0.00, 0.16, 0.41, 0.31, 420),
        (0.00, 0.35, 0.21, 0.25, 0.00, 480),
        (0.00, 0.10, 0.05, 0.05, 0.00, 900),
        (-0.08, -0.55, 0.05, 0.04, 0.00, 650),
        (0.28, -0.52, 0.08, 0.03, 0.00, 520),
    ]
    if variant == "low_contrast":
        ellipses.extend([
            (-0.28, 0.28, 0.065, 0.065, 0.00, 48),
            (0.31, 0.27, 0.045, 0.045, 0.00, -42),
            (0.03, -0.31, 0.035, 0.035, 0.00, 34),
        ])
    elif variant == "resolution":
        for index, radius in enumerate((0.050, 0.038, 0.028, 0.021, 0.016)):
            ellipses.append((-0.32 + index * 0.16, 0.31, radius, radius, 0.0, 850))
    elif variant != "anatomy":
        raise ValueError("unknown phantom variant")

    output = [0] * (size * size)
    for row in range(size):
        y = 2.0 * (row + 0.5) / size - 1.0
        for column in range(size):
            x = 2.0 * (column + 0.5) / size - 1.0
            value = 0
            for cx, cy, rx, ry, angle, delta in ellipses:
                if _inside_ellipse(x, y, cx, cy, rx, ry, angle):
                    value += delta
            output[row * size + column] = max(0, min(4095, value))
    return output


def acquire(ideal: Iterable[int], config: Config, noise_seed_offset: int = 0) -> list[int]:
    """Model post-comparator integer codes with declared requantization and noise.

    This does not emulate transistor-level ADC behavior and never claims to add
    effective bits to a physical converter.
    """
    config.validate()
    target_max = (1 << config.adc_bits) - 1
    rng = XorShift32(config.seed + noise_seed_offset)
    output: list[int] = []
    for sample in ideal:
        code = quantize_ratio(max(0, min(4095, int(sample))), 4095, target_max, config.rounding)
        code = max(0, min(target_max, code + rng.symmetric(config.noise_codes)))
        output.append(code)
    return output


def normalize_codes(codes: Iterable[int], bits: int, mode: Rounding | str) -> list[int]:
    source_max = (1 << bits) - 1
    return [quantize_ratio(int(value), source_max, 4095, mode) for value in codes]


def certified_filter(codes: Iterable[int], config: Config) -> list[int]:
    """Edge-aware integer filter with explicit rounding at every division."""
    config.validate()
    image = normalize_codes(codes, config.adc_bits, config.rounding)
    size = config.size
    output = [0] * len(image)
    radius = config.filter_radius
    spatial = {0: 8, 1: 5, 2: 2, 3: 1, 4: 1, 5: 1, 8: 1}
    for row in range(size):
        for column in range(size):
            center = image[row * size + column]
            weighted_sum = 0
            total_weight = 0
            for dr in range(-radius, radius + 1):
                rr = min(size - 1, max(0, row + dr))
                for dc in range(-radius, radius + 1):
                    cc = min(size - 1, max(0, column + dc))
                    value = image[rr * size + cc]
                    difference = abs(value - center)
                    range_weight = 8 if difference <= config.edge_threshold else 1
                    weight = spatial.get(dr * dr + dc * dc, 1) * range_weight
                    weighted_sum += value * weight
                    total_weight += weight
            output[row * size + column] = max(0, min(4095, div_round(weighted_sum, total_weight, config.rounding)))
    return output


def model_surrogate(certified: Iterable[int], config: Config) -> list[int]:
    """Deterministic unsharp surrogate used only to exercise the audit layer."""
    image = list(certified)
    size = config.size
    output = [0] * len(image)
    strength = config.model_strength_percent
    for row in range(size):
        for column in range(size):
            total = 0
            count = 0
            for dr in (-1, 0, 1):
                rr = min(size - 1, max(0, row + dr))
                for dc in (-1, 0, 1):
                    cc = min(size - 1, max(0, column + dc))
                    total += image[rr * size + cc]
                    count += 1
            index = row * size + column
            blur = div_round(total, count, config.rounding)
            enhanced = image[index] + div_round((image[index] - blur) * strength, 100, config.rounding)
            output[index] = max(0, min(4095, enhanced))
    return output


def metrics(reference: Iterable[int], candidate: Iterable[int]) -> dict[str, float | int | None]:
    ref, out = list(reference), list(candidate)
    if len(ref) != len(out) or not ref:
        raise ValueError("images must have equal, nonzero length")
    absolute = [abs(a - b) for a, b in zip(ref, out)]
    squared = [(a - b) ** 2 for a, b in zip(ref, out)]
    mse = sum(squared) / len(squared)
    psnr = None if mse == 0 else 10.0 * math.log10((4095.0 * 4095.0) / mse)
    return {
        "mae_codes": sum(absolute) / len(absolute),
        "max_abs_codes": max(absolute),
        "rmse_codes": math.sqrt(mse),
        "psnr_db": psnr,
        "psnr_infinite": mse == 0,
    }


def perturbation_audit(ideal: list[int], config: Config, trials: int = 8) -> dict[str, object]:
    """Measure output ranges under declared deterministic input perturbations."""
    if not 2 <= trials <= 64:
        raise ValueError("trials must be in [2, 64]")
    outputs: list[list[int]] = []
    for trial in range(trials):
        acquired = acquire(ideal, config, noise_seed_offset=trial * 104729)
        certified = certified_filter(acquired, config)
        outputs.append(model_surrogate(certified, config))
    ranges = [max(values) - min(values) for values in zip(*outputs)]
    return {
        "trials": trials,
        "max_range_codes": max(ranges),
        "mean_range_codes": sum(ranges) / len(ranges),
        "range_map": ranges,
        "status": "observed_not_proven",
    }


def pixel_digest(values: Iterable[int]) -> str:
    payload = bytearray()
    for value in values:
        payload.extend(int(value).to_bytes(2, "little", signed=False))
    return "sha256:" + hashlib.sha256(payload).hexdigest()
