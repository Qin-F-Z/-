"""Ed25519 signing utilities for QinEvidence envelopes."""

from __future__ import annotations

import base64
import hashlib
from copy import deepcopy
from pathlib import Path
from typing import Any


def _crypto():
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    except ImportError as exc:
        raise RuntimeError("evidence signing requires cryptography") from exc
    return serialization, Ed25519PrivateKey


def public_key_fingerprint(raw_public_key: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw_public_key).hexdigest()


def generate_keypair(private_path: Path, public_path: Path) -> dict[str, str]:
    serialization, Ed25519PrivateKey = _crypto()
    private = Ed25519PrivateKey.generate()
    private_bytes = private.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public = private.public_key()
    public_bytes = public.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    public_pem = public.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
    private_path.parent.mkdir(parents=True, exist_ok=True)
    public_path.parent.mkdir(parents=True, exist_ok=True)
    private_path.write_bytes(private_bytes)
    public_path.write_bytes(public_pem)
    try:
        private_path.chmod(0o600)
    except OSError:
        pass
    fingerprint = public_key_fingerprint(public_bytes)
    return {"key_id": "ed25519:" + fingerprint, "public_key_fingerprint": fingerprint}


def sign_evidence(document: dict[str, Any], private_path: Path) -> dict[str, Any]:
    serialization, _ = _crypto()
    private = serialization.load_pem_private_key(private_path.read_bytes(), password=None)
    public_bytes = private.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    fingerprint = public_key_fingerprint(public_bytes)
    signature = private.sign(document["integrity"]["core_hash"].encode("ascii"))
    signed = deepcopy(document)
    signed["integrity"]["signatures"] = [
        {
            "algorithm": "Ed25519",
            "key_id": "ed25519:" + fingerprint,
            "public_key_base64": base64.b64encode(public_bytes).decode("ascii"),
            "signature_base64": base64.b64encode(signature).decode("ascii"),
            "signed_value": "integrity.core_hash ASCII",
        }
    ]
    return signed

