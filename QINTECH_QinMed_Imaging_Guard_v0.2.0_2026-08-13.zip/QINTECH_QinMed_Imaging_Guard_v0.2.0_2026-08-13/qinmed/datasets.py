"""Optional real-data adapters.

The fastMRI path uses NumPy FFT as an external numerical baseline and then
freezes a canonical 12-bit integer artifact. It does not claim cross-platform
bitwise identity for floating-point FFT implementations.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .artifacts import artifact_record, sha256_file, write_pgm
from .evidence import wrap_core
from .imaging import pixel_digest


def _dependencies():
    try:
        import h5py  # type: ignore
        import numpy as np  # type: ignore
    except ImportError as exc:
        raise RuntimeError("fastMRI support requires numpy and h5py; install requirements-optional.txt") from exc
    return h5py, np


def _json_value(value: Any) -> Any:
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    if hasattr(value, "tolist"):
        return _json_value(value.tolist())
    if isinstance(value, dict):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def inspect_fastmri(path: Path) -> dict[str, Any]:
    h5py, np = _dependencies()
    resolved = path.resolve()
    if not resolved.is_file():
        raise FileNotFoundError(resolved)
    datasets: dict[str, Any] = {}
    with h5py.File(resolved, "r") as handle:
        def visitor(name: str, item: Any) -> None:
            if isinstance(item, h5py.Dataset):
                datasets[name] = {"shape": list(item.shape), "dtype": str(item.dtype)}
        handle.visititems(visitor)
        attrs = {str(key): _json_value(value) for key, value in handle.attrs.items()}
    kspace = datasets.get("kspace")
    shape = kspace["shape"] if kspace else []
    inferred = "unknown"
    if shape:
        rank = len(shape) - (1 if shape[-1:] == [2] else 0)
        inferred = "singlecoil" if rank == 3 else "multicoil" if rank == 4 else "unknown"
    return {
        "format": "fastMRI-compatible-HDF5",
        "path": resolved.name,
        "file_digest": sha256_file(resolved),
        "datasets": datasets,
        "attributes": attrs,
        "inferred_track": inferred,
        "dependencies": {"numpy": np.__version__, "h5py": h5py.__version__},
        "limitations": [
            "HDF5 structure inspection is not dataset-license authorization.",
            "Floating-point FFT output is frozen after 12-bit quantization; cross-library bitwise FFT identity is not claimed.",
            "No clinical interpretation is performed.",
        ],
    }


def _as_complex(array: Any, np: Any) -> Any:
    if np.iscomplexobj(array):
        return array
    if array.shape and array.shape[-1] == 2:
        return array[..., 0] + 1j * array[..., 1]
    raise ValueError("kspace must be complex or have a final real/imaginary dimension of 2")


def _center_crop(image: Any, crop: int | None) -> Any:
    if crop is None:
        return image
    height, width = image.shape[-2:]
    target = min(crop, height, width)
    top = (height - target) // 2
    left = (width - target) // 2
    return image[top:top + target, left:left + target]


def reconstruct_fastmri_slice(path: Path, slice_index: int = 0, crop: int | None = None) -> dict[str, Any]:
    h5py, np = _dependencies()
    resolved = path.resolve()
    with h5py.File(resolved, "r") as handle:
        if "kspace" not in handle:
            raise ValueError("fastMRI file does not contain a kspace dataset")
        dataset = handle["kspace"]
        if not 0 <= slice_index < dataset.shape[0]:
            raise IndexError("slice index outside kspace volume")
        kspace = _as_complex(dataset[slice_index], np)
    if kspace.ndim not in {2, 3}:
        raise ValueError("selected kspace slice must be [H,W] or [coils,H,W]")
    shifted = np.fft.ifftshift(kspace, axes=(-2, -1))
    coil_images = np.fft.fftshift(np.fft.ifft2(shifted, axes=(-2, -1), norm="ortho"), axes=(-2, -1))
    magnitude = np.abs(coil_images) if coil_images.ndim == 2 else np.sqrt(np.sum(np.abs(coil_images) ** 2, axis=0))
    magnitude = _center_crop(magnitude, crop)
    finite = magnitude[np.isfinite(magnitude)]
    if finite.size == 0:
        raise ValueError("reconstruction contains no finite values")
    scale = float(np.percentile(finite, 99.5))
    if not scale > 0:
        scale = float(np.max(finite)) or 1.0
    quantized = np.clip(np.rint(magnitude / scale * 4095.0), 0, 4095).astype(np.uint16)
    values = [int(value) for value in quantized.reshape(-1)]
    height, width = quantized.shape
    return {
        "values": values,
        "width": int(width),
        "height": int(height),
        "pixel_digest": pixel_digest(values),
        "source_digest": sha256_file(resolved),
        "slice_index": slice_index,
        "coil_mode": "singlecoil" if kspace.ndim == 2 else "root-sum-of-squares",
        "normalization": {"method": "finite p99.5 then half-even 12-bit quantization", "scale": scale},
        "runtime": {"numpy": np.__version__, "h5py": h5py.__version__},
    }


def reconstruct_to_files(path: Path, output_dir: Path, slice_index: int = 0, crop: int | None = None) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    result = reconstruct_fastmri_slice(path, slice_index=slice_index, crop=crop)
    image_path = output_dir / f"slice-{slice_index:04d}.pgm"
    write_pgm(image_path, result.pop("values"), result["width"], result["height"])
    report_path = output_dir / f"slice-{slice_index:04d}.fastmri-report.json"
    report = {**result, "output": image_path.name, "output_file_digest": sha256_file(image_path)}
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    commitment_path = output_dir / "source-commitment.json"
    commitment = {"source_file": path.name, "source_digest": result["source_digest"], "adapter": "fastMRI-compatible-HDF5"}
    commitment_path.write_text(json.dumps(commitment, ensure_ascii=False, indent=2), encoding="utf-8")
    generated_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    core = {
        "evidence_kind": "qinmed-fastmri-adapter-run",
        "generated_at": generated_at,
        "subject": {"product": "QinMed Imaging Guard Research Edition", "profile": "fastmri-zero-filled-reference", "intended_use": "research data-adapter verification only"},
        "producer": {"name": "QINTECH", "component": "qinmed.datasets"},
        "engine": {"name": "QinMed fastMRI adapter", "version": "0.2.0"},
        "inputs": [artifact_record(commitment_path, "source file commitment", "application/json", relative_to=output_dir)],
        "outputs": [artifact_record(image_path, "canonical 12-bit reconstruction", "image/x-portable-graymap", relative_to=output_dir), artifact_record(report_path, "adapter report", "application/json", relative_to=output_dir)],
        "execution": {"slice_index": slice_index, "crop": crop, "coil_mode": result["coil_mode"], "normalization": result["normalization"], "runtime": result["runtime"]},
        "results": {"pixel_digest": result["pixel_digest"], "source_digest": result["source_digest"], "shape": [result["height"], result["width"]]},
        "checks": [
            {"id": "qinmed.fastmri.source_binding", "status": "pass", "statement": "The run is bound to the declared source HDF5 digest.", "severity": "high", "observed": result["source_digest"], "expected": result["source_digest"], "evidence_paths": ["core.results.source_digest"]},
            {"id": "qinmed.fastmri.integer_freeze", "status": "pass", "statement": "The floating-point reconstruction was frozen to a canonical 12-bit artifact and digest.", "severity": "high", "observed": result["pixel_digest"], "expected": result["pixel_digest"], "evidence_paths": ["core.results.pixel_digest"]},
            {"id": "qinmed.fastmri.cross_runtime", "status": "unknown", "statement": "Cross-library bitwise equality of the floating-point FFT is not established.", "severity": "medium", "observed": result["runtime"], "expected": "independent_multi_runtime_comparison", "evidence_paths": ["core.coverage.excluded"]},
            {"id": "qinmed.fastmri.clinical", "status": "unknown", "statement": "Clinical safety and effectiveness were not evaluated.", "severity": "critical", "observed": "not_performed", "expected": "independent_clinical_validation", "evidence_paths": ["core.coverage.excluded"]},
        ],
        "claims": [
            {"id": "qinmed.fastmri.adapter", "status": "pass", "statement": "This fastMRI-compatible input was reconstructed and frozen with declared semantics.", "scope": "declared file and slice only", "check_ids": ["qinmed.fastmri.source_binding", "qinmed.fastmri.integer_freeze"], "assumptions": ["HDF5 kspace follows the declared fastMRI-compatible shape"], "exclusions": ["trained-model performance"]},
            {"id": "qinmed.fastmri.cross_runtime", "status": "unknown", "statement": "Floating-point FFT reproducibility across runtimes remains unproven.", "scope": "floating-point baseline", "check_ids": ["qinmed.fastmri.cross_runtime"], "assumptions": [], "exclusions": ["canonical integer artifact after this run"]},
            {"id": "qinmed.fastmri.clinical_use", "status": "unknown", "statement": "Clinical use is not established.", "scope": "clinical use", "check_ids": ["qinmed.fastmri.clinical"], "assumptions": [], "exclusions": ["diagnosis", "treatment", "patient management"]},
        ],
        "coverage": {"included": ["fastMRI-compatible HDF5 structure", "zero-filled inverse FFT", "root-sum-of-squares", "12-bit quantization", "source/output digest binding"], "excluded": ["dataset license authorization", "trained model", "cross-library FFT proof", "clinical validation", "regulatory clearance"]},
        "environment": {"runtime": result["runtime"], "network": "not required"},
        "lifecycle": {"status": "valid", "supersedes": [], "revocation_uri": None},
    }
    evidence = wrap_core(core)
    evidence_path = output_dir / f"slice-{slice_index:04d}.qinevidence.json"
    evidence_path.write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")
    return {**report, "report": report_path.name, "evidence": evidence_path.name}
