"""Command-line entry point for QinMed Imaging Guard."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from .artifacts import write_pgm
from .blind_eval import evaluate, lock_protocol
from .datasets import inspect_fastmri, reconstruct_to_files
from .dicom_guard import audit_dicom, deidentify_dicom
from .evidence import build_evidence
from .fixed import Rounding
from .imaging import Config, acquire, certified_filter, make_phantom, metrics, model_surrogate, perturbation_audit, pixel_digest
from .signing import generate_keypair, sign_evidence


def _write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def run_demo(args: argparse.Namespace) -> int:
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    config = Config(size=args.size, adc_bits=args.bits, rounding=Rounding(args.rounding), noise_codes=args.noise, seed=args.seed)
    ideal = make_phantom(config.size, args.phantom)
    raw = acquire(ideal, config)
    certified = certified_filter(raw, config)
    model = model_surrogate(certified, config)
    repeat = certified_filter(acquire(ideal, config), config)
    perturbation = perturbation_audit(ideal, config, args.trials)
    observed = metrics(certified, model)
    hashes = {
        "ideal_hash": pixel_digest(ideal),
        "raw_hash": pixel_digest(raw),
        "certified_hash": pixel_digest(certified),
        "model_hash": pixel_digest(model),
        "replay_hash": pixel_digest(certified),
        "replay_hash_repeat": pixel_digest(repeat),
    }
    evidence = build_evidence(config, hashes, observed, perturbation)
    write_pgm(output / "ideal.pgm", ideal, config.size, config.size)
    write_pgm(output / "certified.pgm", certified, config.size, config.size)
    write_pgm(output / "model_surrogate.pgm", model, config.size, config.size)
    _write_json(output / "qinmed-demo.qinevidence.json", evidence)
    print(json.dumps({"output": str(output), "hashes": hashes, "metrics": observed, "evidence_id": evidence["evidence_id"]}, ensure_ascii=False, indent=2))
    return 0


def run_fastmri_inspect(args: argparse.Namespace) -> int:
    result = inspect_fastmri(args.input)
    if args.output:
        _write_json(args.output, result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def run_fastmri_reconstruct(args: argparse.Namespace) -> int:
    result = reconstruct_to_files(args.input, args.output, slice_index=args.slice, crop=args.crop)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def run_protocol_lock(args: argparse.Namespace) -> int:
    result = lock_protocol(args.case_manifest, args.output, name=args.name, model_id=args.model_id, seed=args.seed)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def run_blind_eval(args: argparse.Namespace) -> int:
    result = evaluate(args.protocol, args.case_manifest, args.predictions, args.output)
    print(json.dumps({"evidence_id": result["evidence"]["evidence_id"], **{key: result["report"][key] for key in ("technical_acceptance", "case_count", "evaluated_count", "incomplete_count")}}, ensure_ascii=False, indent=2))
    return 0 if result["report"]["technical_acceptance"] == "pass" else 2


def run_dicom_audit(args: argparse.Namespace) -> int:
    report = audit_dicom(args.input)
    if args.output:
        _write_json(args.output, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["research_release_gate"] == "pass" else 2


def _deid_secret(args: argparse.Namespace) -> bytes:
    if args.secret_file:
        secret = args.secret_file.read_bytes().strip()
    else:
        secret = os.environ.get("QINMED_DEID_SECRET", "").encode("utf-8")
    if not secret:
        raise ValueError("provide --secret-file or set QINMED_DEID_SECRET; secrets are never accepted as command-line values")
    return secret


def run_dicom_deidentify(args: argparse.Namespace) -> int:
    result = deidentify_dicom(args.input, args.output_dicom, args.report, _deid_secret(args))
    print(json.dumps({"release_decision": result["report"]["release_decision"], "output_digest": result["report"]["output_digest"], "evidence_id": result["evidence"]["evidence_id"]}, ensure_ascii=False, indent=2))
    return 0 if result["report"]["release_decision"] == "conditional_pass" else 2


def run_keygen(args: argparse.Namespace) -> int:
    result = generate_keypair(args.private, args.public)
    print(json.dumps({**result, "private_key": str(args.private), "public_key": str(args.public), "warning": "Protect the private key outside the product directory; demo generation is not organizational identity assurance."}, ensure_ascii=False, indent=2))
    return 0


def run_sign(args: argparse.Namespace) -> int:
    document = json.loads(args.evidence.read_text(encoding="utf-8"))
    signed = sign_evidence(document, args.private)
    _write_json(args.output, signed)
    print(json.dumps({"output": str(args.output), "evidence_id": signed["evidence_id"], "key_id": signed["integrity"]["signatures"][0]["key_id"]}, ensure_ascii=False, indent=2))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="QinMed Imaging Guard research verification platform")
    subparsers = parser.add_subparsers(dest="command", required=True)

    demo = subparsers.add_parser("demo", help="run deterministic synthetic imaging audit")
    demo.add_argument("--output", type=Path, default=Path("run-output"))
    demo.add_argument("--size", type=int, choices=[32, 64, 96, 128], default=64)
    demo.add_argument("--bits", type=int, choices=range(8, 17), default=12)
    demo.add_argument("--rounding", choices=[item.value for item in Rounding], default=Rounding.HALF_EVEN.value)
    demo.add_argument("--noise", type=int, default=5)
    demo.add_argument("--seed", type=int, default=20260813)
    demo.add_argument("--trials", type=int, default=8)
    demo.add_argument("--phantom", choices=["low_contrast", "resolution", "anatomy"], default="low_contrast")
    demo.set_defaults(handler=run_demo)

    inspect_parser = subparsers.add_parser("fastmri-inspect", help="inspect a fastMRI-compatible HDF5 file without exporting pixels")
    inspect_parser.add_argument("input", type=Path)
    inspect_parser.add_argument("--output", type=Path)
    inspect_parser.set_defaults(handler=run_fastmri_inspect)

    reconstruct = subparsers.add_parser("fastmri-reconstruct", help="create zero-filled/RSS 12-bit reference artifact and evidence")
    reconstruct.add_argument("input", type=Path)
    reconstruct.add_argument("--output", type=Path, required=True)
    reconstruct.add_argument("--slice", type=int, default=0)
    reconstruct.add_argument("--crop", type=int)
    reconstruct.set_defaults(handler=run_fastmri_reconstruct)

    protocol = subparsers.add_parser("protocol-lock", help="freeze a case manifest and evaluation policy before model scoring")
    protocol.add_argument("case_manifest", type=Path)
    protocol.add_argument("--output", type=Path, required=True)
    protocol.add_argument("--name", required=True)
    protocol.add_argument("--model-id", required=True)
    protocol.add_argument("--seed", type=int, default=20260813)
    protocol.set_defaults(handler=run_protocol_lock)

    blind = subparsers.add_parser("blind-eval", help="evaluate file-based outputs against a locked protocol")
    blind.add_argument("protocol", type=Path)
    blind.add_argument("case_manifest", type=Path)
    blind.add_argument("predictions", type=Path)
    blind.add_argument("--output", type=Path, required=True)
    blind.set_defaults(handler=run_blind_eval)

    audit = subparsers.add_parser("dicom-audit", help="report metadata, private-tag, overlay, and burned-in risks")
    audit.add_argument("input", type=Path)
    audit.add_argument("--output", type=Path)
    audit.set_defaults(handler=run_dicom_audit)

    deid = subparsers.add_parser("dicom-deidentify", help="fail-closed research de-identification candidate")
    deid.add_argument("input", type=Path)
    deid.add_argument("--output-dicom", type=Path, required=True)
    deid.add_argument("--report", type=Path, required=True)
    deid.add_argument("--secret-file", type=Path)
    deid.set_defaults(handler=run_dicom_deidentify)

    keygen = subparsers.add_parser("keygen", help="generate an Ed25519 evidence-signing keypair")
    keygen.add_argument("--private", type=Path, required=True)
    keygen.add_argument("--public", type=Path, required=True)
    keygen.set_defaults(handler=run_keygen)

    sign = subparsers.add_parser("sign", help="sign an existing QinEvidence core hash")
    sign.add_argument("evidence", type=Path)
    sign.add_argument("--private", type=Path, required=True)
    sign.add_argument("--output", type=Path, required=True)
    sign.set_defaults(handler=run_sign)

    args = parser.parse_args()
    return args.handler(args)


if __name__ == "__main__":
    raise SystemExit(main())

