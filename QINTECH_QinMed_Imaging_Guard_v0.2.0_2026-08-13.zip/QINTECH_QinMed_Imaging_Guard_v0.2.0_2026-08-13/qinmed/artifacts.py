"""Small, auditable artifact helpers used by QinMed adapters."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Iterable

from .fixed import Rounding, quantize_ratio


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def artifact_record(path: Path, role: str, media_type: str, *, relative_to: Path | None = None) -> dict[str, object]:
    resolved = path.resolve()
    declared = resolved.name if relative_to is None else resolved.relative_to(relative_to.resolve()).as_posix()
    return {
        "path": declared,
        "role": role,
        "media_type": media_type,
        "digest": sha256_file(resolved),
        "size_bytes": resolved.stat().st_size,
    }


def write_pgm(path: Path, values: Iterable[int], width: int, height: int, maximum: int = 4095) -> None:
    samples = list(values)
    if width <= 0 or height <= 0 or len(samples) != width * height:
        raise ValueError("PGM dimensions do not match sample count")
    if not 1 <= maximum <= 65535:
        raise ValueError("PGM maximum must be in [1, 65535]")
    header = f"P5\n{width} {height}\n65535\n".encode("ascii")
    payload = bytearray()
    for value in samples:
        scaled = quantize_ratio(max(0, min(maximum, int(value))), maximum, 65535, Rounding.HALF_EVEN)
        payload.extend(scaled.to_bytes(2, "big"))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(header + payload)


def _pgm_tokens(payload: bytes) -> tuple[list[bytes], int]:
    tokens: list[bytes] = []
    index = 0
    while len(tokens) < 4:
        while index < len(payload) and payload[index] in b" \t\r\n":
            index += 1
        if index >= len(payload):
            break
        if payload[index:index + 1] == b"#":
            while index < len(payload) and payload[index] not in b"\r\n":
                index += 1
            continue
        start = index
        while index < len(payload) and payload[index] not in b" \t\r\n":
            index += 1
        tokens.append(payload[start:index])
    while index < len(payload) and payload[index] in b" \t\r\n":
        index += 1
    return tokens, index


def read_pgm(path: Path) -> tuple[list[int], int, int]:
    payload = path.read_bytes()
    tokens, offset = _pgm_tokens(payload)
    if len(tokens) != 4 or tokens[0] not in {b"P5", b"P2"}:
        raise ValueError("unsupported or malformed PGM")
    width, height, maximum = (int(item) for item in tokens[1:])
    if width <= 0 or height <= 0 or not 1 <= maximum <= 65535:
        raise ValueError("invalid PGM geometry")
    count = width * height
    if tokens[0] == b"P2":
        raw = [int(item) for item in payload[offset:].split()]
    elif maximum < 256:
        raw = list(payload[offset:offset + count])
    else:
        body = payload[offset:offset + count * 2]
        if len(body) != count * 2:
            raise ValueError("truncated PGM")
        raw = [int.from_bytes(body[index:index + 2], "big") for index in range(0, len(body), 2)]
    if len(raw) != count:
        raise ValueError("PGM sample count mismatch")
    values = [quantize_ratio(value, maximum, 4095, Rounding.HALF_EVEN) for value in raw]
    return values, width, height

