"""Explicit integer rounding primitives used by QinMed Imaging Guard."""

from __future__ import annotations

from enum import Enum


class Rounding(str, Enum):
    DOWN = "down"
    UP = "up"
    TOWARD_ZERO = "toward_zero"
    AWAY_FROM_ZERO = "away_from_zero"
    HALF_UP = "half_up"
    HALF_EVEN = "half_even"


def div_round(numerator: int, denominator: int, mode: Rounding | str = Rounding.HALF_EVEN) -> int:
    """Divide signed integers with a declared, platform-independent rounding rule."""
    if denominator == 0:
        raise ZeroDivisionError("division by zero")
    mode = Rounding(mode)
    sign = -1 if (numerator < 0) ^ (denominator < 0) else 1
    n, d = abs(numerator), abs(denominator)
    quotient, remainder = divmod(n, d)
    if remainder == 0:
        return sign * quotient

    if mode is Rounding.TOWARD_ZERO:
        increment = False
    elif mode is Rounding.AWAY_FROM_ZERO:
        increment = True
    elif mode is Rounding.DOWN:
        increment = sign < 0
    elif mode is Rounding.UP:
        increment = sign > 0
    elif mode is Rounding.HALF_UP:
        increment = remainder * 2 >= d
    elif mode is Rounding.HALF_EVEN:
        doubled = remainder * 2
        increment = doubled > d or (doubled == d and quotient % 2 == 1)
    else:  # pragma: no cover - Enum construction rejects this first.
        raise ValueError(f"unsupported rounding mode: {mode}")
    return sign * (quotient + int(increment))


def quantize_ratio(value: int, source_max: int, target_max: int, mode: Rounding | str) -> int:
    """Map an integer measurement between declared code ranges."""
    if source_max <= 0 or target_max <= 0:
        raise ValueError("code range maxima must be positive")
    mapped = div_round(value * target_max, source_max, mode)
    return max(0, min(target_max, mapped))

