"""Locked-protocol, file-based evaluation harness for reconstruction outputs."""

from __future__ import annotations

import json
import math
import shutil
import statistics
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .artifacts import artifact_record, read_pgm, sha256_file
from .evidence import canonical_json, digest_json, wrap_core
from .imaging import XorShift32


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _safe_case_id(value: str) -> str:
    if not value or any(character not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for character in value):
        raise ValueError(f"unsafe case id: {value!r}")
    return value


def image_metrics(reference: list[int], candidate: list[int]) -> dict[str, float | int | bool | None]:
    if len(reference) != len(candidate) or not reference:
        raise ValueError("reference and candidate must have equal, nonzero lengths")
    count = len(reference)
    differences = [float(output - target) for target, output in zip(reference, candidate)]
    absolute = [abs(value) for value in differences]
    mse = sum(value * value for value in differences) / count
    rmse = math.sqrt(mse)
    span = max(reference) - min(reference)
    mean_ref = sum(reference) / count
    mean_candidate = sum(candidate) / count
    variance_ref = sum((value - mean_ref) ** 2 for value in reference) / count
    variance_candidate = sum((value - mean_candidate) ** 2 for value in candidate) / count
    covariance = sum((a - mean_ref) * (b - mean_candidate) for a, b in zip(reference, candidate)) / count
    c1, c2 = (0.01 * 4095) ** 2, (0.03 * 4095) ** 2
    denominator = (mean_ref**2 + mean_candidate**2 + c1) * (variance_ref + variance_candidate + c2)
    ssim = 1.0 if denominator == 0 else ((2 * mean_ref * mean_candidate + c1) * (2 * covariance + c2)) / denominator
    psnr = None if mse == 0 else 10.0 * math.log10((4095.0**2) / mse)
    nrmse = 0.0 if rmse == 0 else rmse / span if span else None
    return {
        "mae_codes": sum(absolute) / count,
        "max_abs_codes": int(max(absolute)),
        "rmse_codes": rmse,
        "nrmse_dynamic_range": nrmse,
        "psnr_db": psnr,
        "psnr_infinite": mse == 0,
        "global_ssim": max(-1.0, min(1.0, ssim)),
    }


def bootstrap_mean_ci(values: list[float], seed: int = 20260813, replicates: int = 2000) -> dict[str, float | int]:
    if not values:
        raise ValueError("bootstrap requires at least one value")
    if not 100 <= replicates <= 10000:
        raise ValueError("bootstrap replicates must be in [100, 10000]")
    rng = XorShift32(seed)
    means: list[float] = []
    for _ in range(replicates):
        sample = [values[rng.next_u32() % len(values)] for _ in values]
        means.append(sum(sample) / len(sample))
    means.sort()
    low_index = max(0, int(0.025 * replicates) - 1)
    high_index = min(replicates - 1, int(0.975 * replicates))
    return {"mean": sum(values) / len(values), "ci95_low": means[low_index], "ci95_high": means[high_index], "replicates": replicates, "seed": seed}


def lock_protocol(case_manifest: Path, output: Path, *, name: str, model_id: str, seed: int = 20260813) -> dict[str, Any]:
    manifest = json.loads(case_manifest.read_text(encoding="utf-8"))
    cases = manifest.get("cases", [])
    if not cases:
        raise ValueError("case manifest is empty")
    identifiers = [_safe_case_id(str(item["case_id"])) for item in cases]
    if len(identifiers) != len(set(identifiers)):
        raise ValueError("case ids must be unique")
    protocol = {
        "protocol_version": "1.0",
        "name": name,
        "locked_at": _utc_now(),
        "model_id": model_id,
        "case_manifest_sha256": sha256_file(case_manifest),
        "case_count": len(cases),
        "prediction_contract": "one 12-bit PGM named <case_id>.pgm; exact reference dimensions",
        "primary_metrics": ["nrmse_dynamic_range", "global_ssim"],
        "secondary_metrics": ["mae_codes", "max_abs_codes", "psnr_db"],
        "acceptance": {"max_missing_cases": 0, "max_mean_nrmse": 0.10, "min_mean_global_ssim": 0.95},
        "statistics": {"paired": True, "bootstrap_replicates": 2000, "bootstrap_seed": seed, "confidence": 0.95},
        "failure_policy": "missing, unreadable, dimension-mismatched, or non-finite results fail technical completeness",
        "blinding": {"operator_blinding": "not_enforced_by_software", "independent_holdout": "external_requirement"},
        "clinical_claim": "none",
    }
    protocol["protocol_hash"] = digest_json(protocol)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(protocol, ensure_ascii=False, indent=2), encoding="utf-8")
    return protocol


def _verify_protocol(protocol: dict[str, Any]) -> None:
    declared = protocol.get("protocol_hash")
    core = {key: value for key, value in protocol.items() if key != "protocol_hash"}
    if declared != digest_json(core):
        raise ValueError("protocol hash mismatch; protocol is not locked or was modified")


def evaluate(protocol_path: Path, case_manifest: Path, predictions: Path, output_dir: Path) -> dict[str, Any]:
    protocol = json.loads(protocol_path.read_text(encoding="utf-8"))
    _verify_protocol(protocol)
    if protocol.get("case_manifest_sha256") != sha256_file(case_manifest):
        raise ValueError("case manifest does not match locked protocol")
    manifest = json.loads(case_manifest.read_text(encoding="utf-8"))
    manifest_root = case_manifest.resolve().parent
    cases_report: list[dict[str, Any]] = []
    missing = 0
    for item in manifest.get("cases", []):
        case_id = _safe_case_id(str(item["case_id"]))
        reference_path = (manifest_root / item["reference"]).resolve()
        reference_path.relative_to(manifest_root)
        candidate_path = (predictions.resolve() / f"{case_id}.pgm").resolve()
        candidate_path.relative_to(predictions.resolve())
        if not candidate_path.is_file():
            missing += 1
            cases_report.append({"case_id": case_id, "status": "missing", "reference_digest": sha256_file(reference_path)})
            continue
        reference, width, height = read_pgm(reference_path)
        candidate, candidate_width, candidate_height = read_pgm(candidate_path)
        if (width, height) != (candidate_width, candidate_height):
            cases_report.append({"case_id": case_id, "status": "dimension_mismatch", "reference_shape": [height, width], "candidate_shape": [candidate_height, candidate_width]})
            continue
        cases_report.append({
            "case_id": case_id,
            "status": "evaluated",
            "shape": [height, width],
            "reference_digest": sha256_file(reference_path),
            "prediction_digest": sha256_file(candidate_path),
            "metrics": image_metrics(reference, candidate),
        })
    evaluated = [item for item in cases_report if item["status"] == "evaluated"]
    incomplete = len(cases_report) - len(evaluated)
    aggregates: dict[str, Any] = {}
    for metric in ("nrmse_dynamic_range", "global_ssim", "mae_codes", "psnr_db"):
        values = [float(item["metrics"][metric]) for item in evaluated if item["metrics"].get(metric) is not None and math.isfinite(float(item["metrics"][metric]))]
        if values:
            aggregates[metric] = {"mean": sum(values) / len(values), "median": statistics.median(values), "minimum": min(values), "maximum": max(values)}
            if metric in {"nrmse_dynamic_range", "global_ssim"}:
                aggregates[metric]["bootstrap"] = bootstrap_mean_ci(values, int(protocol["statistics"]["bootstrap_seed"]), int(protocol["statistics"]["bootstrap_replicates"]))
    acceptance = protocol["acceptance"]
    technical_pass = (
        incomplete <= int(acceptance["max_missing_cases"])
        and len(evaluated) == int(protocol["case_count"])
        and aggregates.get("nrmse_dynamic_range", {}).get("mean", float("inf")) <= float(acceptance["max_mean_nrmse"])
        and aggregates.get("global_ssim", {}).get("mean", -1.0) >= float(acceptance["min_mean_global_ssim"])
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    protocol_snapshot = output_dir / "locked-protocol.json"
    registry_path = output_dir / "case-hash-registry.json"
    report_path = output_dir / "blind-eval-report.json"
    shutil.copyfile(protocol_path, protocol_snapshot)
    registry = {"case_manifest_digest": sha256_file(case_manifest), "cases": [{key: value for key, value in item.items() if key.endswith("digest") or key in {"case_id", "status"}} for item in cases_report]}
    registry_path.write_text(json.dumps(registry, ensure_ascii=False, indent=2), encoding="utf-8")
    report = {
        "evaluation_kind": "locked-file-output-evaluation",
        "generated_at": _utc_now(),
        "protocol_hash": protocol["protocol_hash"],
        "model_id": protocol["model_id"],
        "case_count": len(cases_report),
        "evaluated_count": len(evaluated),
        "incomplete_count": incomplete,
        "technical_acceptance": "pass" if technical_pass else "fail",
        "aggregates": aggregates,
        "cases": cases_report,
        "limitations": ["Operator blinding is not enforced by software.", "Clinical safety and effectiveness are not evaluated.", "Global SSIM is a whole-image diagnostic metric, not a clinical endpoint."],
    }
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    core = {
        "evidence_kind": "qinmed-blind-evaluation",
        "generated_at": report["generated_at"],
        "subject": {"product": "QinMed Imaging Guard Research Edition", "model_id": protocol["model_id"], "intended_use": "research model-output QA only"},
        "producer": {"name": "QINTECH", "component": "qinmed.blind_eval"},
        "engine": {"name": "QinMed locked evaluation harness", "version": "0.2.0"},
        "inputs": [artifact_record(protocol_snapshot, "locked protocol", "application/json", relative_to=output_dir), artifact_record(registry_path, "case digest registry", "application/json", relative_to=output_dir)],
        "outputs": [artifact_record(report_path, "evaluation report", "application/json", relative_to=output_dir)],
        "execution": {"protocol_hash": protocol["protocol_hash"], "case_count": len(cases_report), "failure_policy": protocol["failure_policy"]},
        "results": {"technical_acceptance": report["technical_acceptance"], "aggregates": aggregates, "incomplete_count": incomplete},
        "checks": [
            {"id": "qinmed.eval.protocol_lock", "status": "pass", "statement": "The evaluation protocol hash and case manifest commitment matched.", "severity": "high", "observed": protocol["protocol_hash"], "expected": protocol["protocol_hash"], "evidence_paths": ["core.execution.protocol_hash"]},
            {"id": "qinmed.eval.technical_acceptance", "status": "pass" if technical_pass else "fail", "statement": "Declared technical acceptance criteria were applied without excluding failed cases.", "severity": "high", "observed": report["technical_acceptance"], "expected": "pass", "evidence_paths": ["core.results"]},
            {"id": "qinmed.eval.independent_blinding", "status": "unknown", "statement": "Independent operator blinding and external holdout custody were not established by this local run.", "severity": "high", "observed": "not_enforced", "expected": "external_custody", "evidence_paths": ["core.coverage.excluded"]},
            {"id": "qinmed.eval.clinical", "status": "unknown", "statement": "Clinical safety and effectiveness were not evaluated.", "severity": "critical", "observed": "not_performed", "expected": "independent_clinical_validation", "evidence_paths": ["core.coverage.excluded"]},
        ],
        "claims": [
            {"id": "qinmed.eval.locked_execution", "status": "pass", "statement": "This report is bound to the declared locked protocol and file digests.", "scope": "packaged file-output evaluation", "check_ids": ["qinmed.eval.protocol_lock"], "assumptions": ["SHA-256 collision resistance"], "exclusions": ["external custody"]},
            {"id": "qinmed.eval.technical", "status": "pass" if technical_pass else "fail", "statement": "The candidate met the predeclared technical criteria on this case set.", "scope": "declared case manifest only", "check_ids": ["qinmed.eval.technical_acceptance"], "assumptions": ["reference files are correct"], "exclusions": ["clinical generalization", "diagnostic accuracy"]},
            {"id": "qinmed.eval.independent_blinding", "status": "unknown", "statement": "Independent blinding remains an external validation requirement.", "scope": "study governance", "check_ids": ["qinmed.eval.independent_blinding"], "assumptions": [], "exclusions": ["self-run demonstration"]},
            {"id": "qinmed.eval.clinical_use", "status": "unknown", "statement": "Clinical use is not established.", "scope": "clinical use", "check_ids": ["qinmed.eval.clinical"], "assumptions": [], "exclusions": ["diagnosis", "treatment", "patient management"]},
        ],
        "coverage": {"included": ["locked protocol hash", "case completeness", "PGM digest binding", "NRMSE", "global SSIM", "deterministic bootstrap"], "excluded": ["independent holdout custody", "reader study", "clinical endpoints", "DICOM conformance", "regulatory clearance"]},
        "environment": {"runtime": "Python standard library", "network": "not required"},
        "lifecycle": {"status": "valid", "supersedes": [], "revocation_uri": None},
    }
    evidence = wrap_core(core)
    evidence_path = output_dir / "blind-eval.qinevidence.json"
    evidence_path.write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"report": report, "evidence": evidence, "evidence_path": evidence_path}
