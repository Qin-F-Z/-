#!/usr/bin/env python3
"""Standalone QinEvidence 1.0 verifier with no QINSCIENCE dependency.

It verifies canonical core hashing, evidence identity, claim/check consistency,
lifecycle state, optional artifact digests, and optional Ed25519 signatures when
the third-party ``cryptography`` package is available.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA = "https://schemas.qinscience.com/qinevidence/1.0.0.json"
VERSION = "1.0.0"
ID_PREFIX = "urn:qinevidence:"


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest_json(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def digest_file(path: Path) -> tuple[str, int]:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
            size += len(chunk)
    return "sha256:" + digest.hexdigest(), size


def safe_artifact(root: Path, declared: str) -> Path:
    relative = Path(declared)
    if relative.is_absolute() or ".." in relative.parts or not declared:
        raise ValueError("unsafe artifact path")
    resolved = (root / relative).resolve()
    resolved.relative_to(root.resolve())
    return resolved


def verify_signatures(document: dict[str, Any], trusted_fingerprints: set[str] | None = None) -> tuple[str, list[dict[str, Any]]]:
    signatures = document.get("integrity", {}).get("signatures", [])
    if not signatures:
        return "unsigned", []
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except ImportError:
        return "verification_dependency_unavailable", []
    digest = document["integrity"]["core_hash"].encode("ascii")
    results = []
    trusted = trusted_fingerprints or set()
    for signature in signatures:
        try:
            if signature["algorithm"] != "Ed25519":
                raise ValueError("unsupported algorithm")
            raw_public = base64.b64decode(signature["public_key_base64"], validate=True)
            fingerprint = "sha256:" + hashlib.sha256(raw_public).hexdigest()
            key = Ed25519PublicKey.from_public_bytes(raw_public)
            key.verify(base64.b64decode(signature["signature_base64"], validate=True), digest)
            results.append({"key_id": signature["key_id"], "fingerprint": fingerprint, "valid": True, "trusted": fingerprint in trusted})
        except Exception as exc:
            results.append({"key_id": signature.get("key_id"), "valid": False, "reason": type(exc).__name__})
    return ("valid" if results and all(item["valid"] for item in results) else "invalid"), results


def verify(
    document: dict[str, Any],
    artifact_root: Path | None,
    require_signature: bool,
    trusted_fingerprints: set[str] | None = None,
    require_trusted_signature: bool = False,
) -> dict[str, Any]:
    errors: list[str] = []
    if document.get("$schema") != SCHEMA or document.get("spec_version") != VERSION:
        errors.append("unsupported schema or version")
    core = document.get("core")
    if not isinstance(core, dict):
        return {"valid": False, "assurance": "invalid", "errors": [*errors, "missing core"]}
    expected_hash = digest_json(core)
    hash_valid = document.get("integrity", {}).get("core_hash") == expected_hash
    id_valid = document.get("evidence_id") == ID_PREFIX + expected_hash
    if not hash_valid:
        errors.append("core hash mismatch")
    if not id_valid:
        errors.append("evidence id mismatch")

    checks = core.get("checks", [])
    claims = core.get("claims", [])
    ids = [item.get("id") for item in checks]
    if len(ids) != len(set(ids)):
        errors.append("duplicate check id")
    by_id = {item.get("id"): item for item in checks}
    for claim in claims:
        missing = [item for item in claim.get("check_ids", []) if item not in by_id]
        if missing:
            errors.append(f"claim {claim.get('id')} references missing checks")
        if claim.get("status") == "pass" and any(by_id[item].get("status") != "pass" for item in claim.get("check_ids", []) if item in by_id):
            errors.append(f"claim {claim.get('id')} contradicts supporting checks")

    lifecycle = core.get("lifecycle", {}).get("status", "unknown")
    expires = core.get("lifecycle", {}).get("expires_at")
    if expires and datetime.now(timezone.utc) >= datetime.fromisoformat(expires.replace("Z", "+00:00")):
        lifecycle = "expired"
    if lifecycle in {"expired", "revoked", "superseded"}:
        errors.append(f"lifecycle status is {lifecycle}")

    artifact_items = []
    artifacts_status = "not_applicable"
    declared_artifacts = [*core.get("inputs", []), *core.get("outputs", [])]
    if declared_artifacts and artifact_root is None:
        artifacts_status = "unchecked"
    elif declared_artifacts:
        for item in declared_artifacts:
            try:
                path = safe_artifact(artifact_root.resolve(), item["path"])
                digest, size = digest_file(path)
                valid = digest == item.get("digest") and size == item.get("size_bytes")
                artifact_items.append({"path": item["path"], "valid": valid})
            except Exception as exc:
                artifact_items.append({"path": item.get("path"), "valid": False, "reason": type(exc).__name__})
        artifacts_status = "valid" if all(item["valid"] for item in artifact_items) else "invalid"
        if artifacts_status == "invalid":
            errors.append("artifact digest verification failed")

    signature_state, signature_items = verify_signatures(document, trusted_fingerprints) if hash_valid else ("not_checked", [])
    if require_signature and signature_state != "valid":
        errors.append(f"signature requirement not satisfied: {signature_state}")
    trusted_signature = any(item.get("valid") and item.get("trusted") for item in signature_items)
    if require_trusted_signature and not trusted_signature:
        errors.append("trusted signature requirement not satisfied")
    valid = not errors
    return {
        "valid": valid,
        "assurance": "signed_trusted" if valid and trusted_signature else "signed_untrusted" if valid and signature_state == "valid" else "unsigned" if valid else "invalid",
        "errors": errors,
        "integrity": {"hash_valid": hash_valid, "id_valid": id_valid, "expected_hash": expected_hash},
        "signatures": {"status": signature_state, "trusted_signature": trusted_signature, "items": signature_items},
        "artifacts": {"status": artifacts_status, "items": artifact_items},
        "lifecycle": lifecycle,
        "claim_summary": {status: sum(1 for item in claims if item.get("status") == status) for status in ("pass", "fail", "unknown", "not_applicable")},
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Independent QinEvidence verifier")
    parser.add_argument("evidence", type=Path)
    parser.add_argument("--artifact-root", type=Path)
    parser.add_argument("--require-signature", action="store_true")
    parser.add_argument("--trusted-key-sha256", action="append", default=[], help="trusted raw Ed25519 public-key fingerprint; repeatable")
    parser.add_argument("--require-trusted-signature", action="store_true")
    args = parser.parse_args()
    document = json.loads(args.evidence.read_text(encoding="utf-8"))
    trusted = {value if value.startswith("sha256:") else "sha256:" + value for value in args.trusted_key_sha256}
    result = verify(document, args.artifact_root, args.require_signature, trusted, args.require_trusted_signature)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
