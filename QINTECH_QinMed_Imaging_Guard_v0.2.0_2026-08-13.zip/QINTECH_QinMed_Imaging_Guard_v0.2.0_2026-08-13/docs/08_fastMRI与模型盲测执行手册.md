# fastMRI Guard 与锁定协议模型评测执行手册

## 数据接入

fastMRI 官方参考实现以每次 MR acquisition 一个 HDF5 文件组织数据，常见 `kspace` 为单线圈 `[slice, height, width]` 或多线圈 `[slice, coil, height, width]`。本适配器也接受最后一维为 2 的实部/虚部表示。具体字段随任务和数据分区变化，运行前必须先执行结构检查。

```powershell
python -m qinmed.cli fastmri-inspect input.h5 --output inspection.json
python -m qinmed.cli fastmri-reconstruct input.h5 --slice 0 --crop 320 --output run
```

参考：fastMRI 官方数据加载说明：https://github.com/facebookresearch/fastMRI/blob/main/fastmri/data/README.md

## 数值边界

零填充重建使用 NumPy `ifft2(norm="ortho")`。多线圈图像采用 root-sum-of-squares；有限值的 99.5 百分位作为显示尺度，随后采用 half-even 规则冻结为 0–4095 整数。浮点 FFT 受库、硬件和实现影响，因此证据只承诺本次输出已被冻结和哈希绑定，不承诺不同运行时在浮点阶段逐位一致。

## 评分前锁定

案例清单必须先写入 `cases.json`，每个案例包含唯一 `case_id` 和授权参考文件的相对路径。随后生成锁定协议：

```powershell
python -m qinmed.cli protocol-lock cases.json `
  --name 'MRI reconstruction locked evaluation' `
  --model-id 'candidate-model@sha256:...' `
  --output locked-protocol.json
```

锁定内容包括案例清单 SHA-256、模型身份、主次指标、缺失案例政策、阈值、bootstrap 次数和种子。修改任何字段都会导致 `protocol_hash` 失配。

## 模型输出合同

模型目录必须提供 `<case_id>.pgm`。尺寸必须与参考完全一致，缺失、损坏或尺寸不符都计为技术失败。评测器不执行模型代码，因此降低了任意模型插件直接在验证机上执行的攻击面。

```powershell
python -m qinmed.cli blind-eval locked-protocol.json cases.json predictions --output result
```

## 外部盲法

本机可以锁定协议和参考哈希，但无法证明操作者没有看过参考图像。正式研究应由独立数据托管方保管参考文件，模型团队只取得输入；评分在隔离环境完成，所有失败案例和偏离均保留。模板见 `protocols/external-blind-study.template.json`。

## 论文依据

- Knoll F, et al. *fastMRI: A Publicly Available Raw k-Space and DICOM Dataset...* Radiology: AI, 2020. DOI: https://doi.org/10.1148/ryai.2020190007
- Knoll F, et al. *Advancing machine learning for MR image reconstruction with an open competition...* Magnetic Resonance in Medicine, 2020. DOI: https://doi.org/10.1002/mrm.28338

