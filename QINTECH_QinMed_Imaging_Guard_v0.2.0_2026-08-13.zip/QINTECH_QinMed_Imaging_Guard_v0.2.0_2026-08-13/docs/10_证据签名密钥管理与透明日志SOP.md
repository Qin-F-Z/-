# QinEvidence 签名、密钥管理与透明日志 SOP

## 信任模型

QinEvidence 的 `core_hash` 绑定输入承诺、输出工件、参数、结果、检查、声称和边界。Ed25519 签名证明持有对应私钥的人签署了该哈希，但公钥随证据自带并不自动证明签名者身份。验证方必须从合同、官网、线下交付或证书系统等独立渠道固定公钥 SHA-256 指纹。

## 生产密钥规则

1. 根签名密钥不进入源码仓库、客户服务器镜像、日志或交付压缩包。
2. 优先使用 HSM/KMS；否则使用加密离线介质和双人控制。
3. 生产、测试、演示密钥完全分离。
4. 每个密钥有负责人、用途、创建时间、轮换时间、撤销状态和事件记录。
5. 证据签名之前验证 `core_hash` 和所有工件哈希；签名后再次独立复验。
6. 透明日志至少记录 evidence_id、签名公钥指纹、签署时间、产品版本、状态和前一条记录哈希。

## 验证要求

```powershell
python verifier\qinevidence_verify.py evidence.signed.qinevidence.json `
  --artifact-root run `
  --require-signature `
  --trusted-key-sha256 sha256:登记指纹 `
  --require-trusted-signature
```

验签有效但指纹未登记时，结果为 `signed_untrusted`；只有签名有效且指纹匹配独立信任列表才是 `signed_trusted`。

## 本包演示密钥

`examples/v0.2-extended/trust/` 只包含一次性演示公钥。私钥未打包。它证明签名机制可复验，不代表 QINTECH 公司身份、可信时间戳、第三方认证或监管认可。

