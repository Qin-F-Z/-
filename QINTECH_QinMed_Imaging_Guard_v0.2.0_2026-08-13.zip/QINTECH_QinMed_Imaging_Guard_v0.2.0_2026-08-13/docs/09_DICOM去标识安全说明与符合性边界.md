# DICOM Guard 安全说明与符合性边界

## 定位

DICOM Guard 是研究级、失败闭合的隐私预处理与证据组件。它检查并处理一组高风险直接标识符、私有数据元素、overlay、UID、日期和 `BurnedInAnnotation`，但不宣称完整实现 DICOM PS3.15 Basic Application Level Confidentiality Profile。

## 失败闭合规则

若 DICOM 包含 PixelData，而 `BurnedInAnnotation` 不是明确的 `NO`，去标识命令拒绝输出。原因是元数据删除无法证明像素中没有姓名、编号、面部结构或屏幕烧录文字。

软件 `conditional_pass` 还必须满足：配置内直接标识符为 0、私有标签为 0、overlay 不存在、`PatientIdentityRemoved=YES`、烧录标志为 `NO`。即使满足，也仍需授权、机构隐私审查、像素 OCR/人工复核和正式 conformance testing。

## 伪名与密钥

PatientName、PatientID 和 UID 使用秘密 HMAC 生成一致伪名；日期按同一患者锚点确定性平移。秘密只能从环境变量或文件读取，不能直接放在命令行中。输出报告只保存秘密指纹，不保存秘密。

```powershell
$env:QINMED_DEID_SECRET = '从 KMS/HSM 或受控秘密文件取得'
python -m qinmed.cli dicom-deidentify input.dcm `
  --output-dicom result\deidentified.dcm `
  --report result\deidentification-report.json
```

## 未覆盖风险

- 像素文字、面部结构与可视化 PHI。
- 所有嵌套或厂商专有属性的逐项验证。
- 多文件引用完整性与跨研究一致映射治理。
- DICOMDIR、结构化报告、波形、PDF、视频和封装文档的全部特例。
- 机构政策、司法辖区法律以及数据出境规则。

现行规范入口：DICOM PS3.15 2026b，https://dicom.nema.org/medical/dicom/current/output/html/part15.html

