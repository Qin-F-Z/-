# 权威参考

以下资料用于限定产品表述和后续工程路线；它们不等于 QinMed 已达到相应标准或获得监管许可。

1. DICOM Standard Committee, Current Edition: https://www.dicomstandard.org/current/
2. DICOM PS3.15, Security and System Management Profiles: https://dicom.nema.org/Medical/dicom/current/output/pdf/part15.pdf
3. FDA, Transparency for Machine Learning-Enabled Medical Devices: Guiding Principles: https://www.fda.gov/medical-devices/software-medical-device-samd/transparency-machine-learning-enabled-medical-devices-guiding-principles
4. FDA, Artificial Intelligence-Enabled Medical Devices: https://www.fda.gov/medical-devices/software-medical-device-samd/artificial-intelligence-enabled-medical-devices
5. FDA, Medical Device Software Guidance Navigator: https://www.fda.gov/medical-devices/regulatory-accelerator/medical-device-software-guidance-navigator
6. NYU fastMRI dataset: https://fastmri.org/
7. fastMRI reference repository and HDF5 data loading contract: https://github.com/facebookresearch/fastMRI and https://github.com/facebookresearch/fastMRI/blob/main/fastmri/data/README.md
8. Knoll F, et al. fastMRI public raw k-space and DICOM dataset. DOI: https://doi.org/10.1148/ryai.2020190007
9. Knoll F, et al. 2019 fastMRI challenge overview. DOI: https://doi.org/10.1002/mrm.28338
10. DICOM PS3.15 current edition: https://dicom.nema.org/medical/dicom/current/output/html/part15.html
11. FDA transparency principles for machine-learning-enabled medical devices: https://www.fda.gov/medical-devices/software-medical-device-samd/transparency-machine-learning-enabled-medical-devices-guiding-principles
12. FDA PCCP final guidance for AI-enabled device software functions: https://www.fda.gov/media/166704/download
