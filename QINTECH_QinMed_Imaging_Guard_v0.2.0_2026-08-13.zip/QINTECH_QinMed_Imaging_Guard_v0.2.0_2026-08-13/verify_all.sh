#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
export PYTHONPATH="$ROOT"
export PYTHONDONTWRITEBYTECODE=1
PYTHON=${QINMED_PYTHON:-python3}
RUN=$(mktemp -d "${TMPDIR:-/tmp}/qinmed-verification.XXXXXX")
trap 'rm -rf "$RUN"' EXIT INT TERM
"$PYTHON" "$ROOT/tools/build_standalone.py"
node "$ROOT/tests/test_engine.mjs"
"$PYTHON" -m unittest discover -s "$ROOT/tests" -p 'test_*.py' -v
if "$PYTHON" -c "import importlib.util as u,sys; sys.exit(0 if all(u.find_spec(n) for n in ('numpy','h5py','pydicom','cryptography')) else 1)"; then
  EXAMPLES="$ROOT/examples/v0.2-extended"
  FINGERPRINT=$(tr -d '\r\n' < "$EXAMPLES/trust/demo-public-fingerprint.txt")
  "$PYTHON" "$ROOT/verifier/qinevidence_verify.py" "$EXAMPLES/fastmri-synthetic/result/slice-0000.signed.qinevidence.json" --artifact-root "$EXAMPLES/fastmri-synthetic/result" --require-signature --trusted-key-sha256 "$FINGERPRINT" --require-trusted-signature
  "$PYTHON" "$ROOT/verifier/qinevidence_verify.py" "$EXAMPLES/blind-eval-synthetic/result/blind-eval.signed.qinevidence.json" --artifact-root "$EXAMPLES/blind-eval-synthetic/result" --require-signature --trusted-key-sha256 "$FINGERPRINT" --require-trusted-signature
  "$PYTHON" "$ROOT/verifier/qinevidence_verify.py" "$EXAMPLES/dicom-synthetic/result/dicom-deidentification.signed.qinevidence.json" --artifact-root "$EXAMPLES/dicom-synthetic/result" --require-signature --trusted-key-sha256 "$FINGERPRINT" --require-trusted-signature
  echo 'PASS: optional fastMRI, DICOM, and trusted-signature examples.'
elif [ "${QINMED_REQUIRE_OPTIONAL:-0}" = "1" ]; then
  echo 'FAIL: optional dependencies required but unavailable.' >&2
  exit 1
else
  echo 'SKIP: optional fastMRI/DICOM/signing examples.'
fi
"$PYTHON" -m qinmed.cli demo --output "$RUN" --size 64 --bits 12 --rounding half_even --noise 5 --seed 20260813 --trials 8
"$PYTHON" "$ROOT/verifier/qinevidence_verify.py" "$RUN/qinmed-demo.qinevidence.json"
node "$ROOT/tests/generate_browser_evidence.mjs" "$RUN/browser.qinevidence.json"
"$PYTHON" "$ROOT/verifier/qinevidence_verify.py" "$RUN/browser.qinevidence.json"
echo 'PASS: QinMed Imaging Guard v0.2.0 full verification.'

