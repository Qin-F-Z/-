param([switch]$RequireOptional)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path

function Resolve-CommandPath([string[]]$Candidates) {
  foreach ($Candidate in $Candidates) {
    $Command = Get-Command $Candidate -ErrorAction SilentlyContinue
    if ($Command) { return $Command.Source }
  }
  throw "Required runtime not found: $($Candidates -join ', ')"
}

$Python = if ($env:QINMED_PYTHON) { $env:QINMED_PYTHON } else { Resolve-CommandPath @('python.exe', 'python') }
$Node = Resolve-CommandPath @('node.exe', 'node')
$env:PYTHONPATH = $Root
$env:PYTHONDONTWRITEBYTECODE = '1'

& $Python (Join-Path $Root 'tools\build_standalone.py')
if ($LASTEXITCODE -ne 0) { throw 'Standalone build failed.' }

& $Node (Join-Path $Root 'tests\test_engine.mjs')
if ($LASTEXITCODE -ne 0) { throw 'JavaScript tests failed.' }

& $Python -m unittest discover -s (Join-Path $Root 'tests') -p 'test_*.py' -v
if ($LASTEXITCODE -ne 0) { throw 'Python tests failed.' }

& $Python -c "import importlib.util as u,sys; sys.exit(0 if all(u.find_spec(n) for n in ('numpy','h5py','pydicom','cryptography')) else 1)"
$OptionalAvailable = $LASTEXITCODE -eq 0
if ($RequireOptional -and -not $OptionalAvailable) {
  throw 'Optional fastMRI/DICOM/signing dependencies are required but unavailable. Run 安装_真实数据可选能力.ps1.'
}
if ($OptionalAvailable) {
  $Examples = Join-Path $Root 'examples\v0.2-extended'
  $Fingerprint = (Get-Content -LiteralPath (Join-Path $Examples 'trust\demo-public-fingerprint.txt') -Raw).Trim()
  $SignedEvidence = @(
    @{ Evidence = Join-Path $Examples 'fastmri-synthetic\result\slice-0000.signed.qinevidence.json'; Artifacts = Join-Path $Examples 'fastmri-synthetic\result' },
    @{ Evidence = Join-Path $Examples 'blind-eval-synthetic\result\blind-eval.signed.qinevidence.json'; Artifacts = Join-Path $Examples 'blind-eval-synthetic\result' },
    @{ Evidence = Join-Path $Examples 'dicom-synthetic\result\dicom-deidentification.signed.qinevidence.json'; Artifacts = Join-Path $Examples 'dicom-synthetic\result' }
  )
  foreach ($Item in $SignedEvidence) {
    & $Python (Join-Path $Root 'verifier\qinevidence_verify.py') $Item.Evidence --artifact-root $Item.Artifacts --require-signature --trusted-key-sha256 $Fingerprint --require-trusted-signature
    if ($LASTEXITCODE -ne 0) { throw "Signed example verification failed: $($Item.Evidence)" }
  }
  Write-Host 'PASS: optional fastMRI, DICOM, and trusted-signature examples.' -ForegroundColor Green
}
else {
  Write-Host 'SKIP: optional fastMRI/DICOM/signing examples; install requirements-optional.txt to enable.' -ForegroundColor Yellow
}

$Run = Join-Path ([IO.Path]::GetTempPath()) ("qinmed-verification-" + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $Run | Out-Null
try {
  & $Python -m qinmed.cli demo --output $Run --size 64 --bits 12 --rounding half_even --noise 5 --seed 20260813 --trials 8
  if ($LASTEXITCODE -ne 0) { throw 'Reference run failed.' }

  & $Python (Join-Path $Root 'verifier\qinevidence_verify.py') (Join-Path $Run 'qinmed-demo.qinevidence.json')
  if ($LASTEXITCODE -ne 0) { throw 'Independent evidence verification failed.' }

  & $Node (Join-Path $Root 'tests\generate_browser_evidence.mjs') (Join-Path $Run 'browser.qinevidence.json')
  if ($LASTEXITCODE -ne 0) { throw 'Browser evidence generation failed.' }
  & $Python (Join-Path $Root 'verifier\qinevidence_verify.py') (Join-Path $Run 'browser.qinevidence.json')
  if ($LASTEXITCODE -ne 0) { throw 'Browser/Python evidence interoperability failed.' }

  Write-Host 'PASS: QinMed Imaging Guard v0.2.0 full verification.' -ForegroundColor Green
}
finally {
  $ResolvedTemp = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
  $ResolvedRun = [IO.Path]::GetFullPath($Run)
  if ($ResolvedRun.StartsWith($ResolvedTemp, [StringComparison]::OrdinalIgnoreCase) -and (Split-Path -Leaf $ResolvedRun).StartsWith('qinmed-verification-')) {
    Remove-Item -LiteralPath $ResolvedRun -Recurse -Force -ErrorAction SilentlyContinue
  }
}

