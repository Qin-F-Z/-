@echo off
setlocal
start "QinMed Imaging Guard" "%~dp0QinMed_Imaging_Guard_Standalone.html"
endlocal
