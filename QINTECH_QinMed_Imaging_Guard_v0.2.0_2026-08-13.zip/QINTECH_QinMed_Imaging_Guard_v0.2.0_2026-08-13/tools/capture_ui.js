#!/usr/bin/env node
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { pathToFileURL } = require('url');
const { spawn } = require('child_process');

const root = path.resolve(__dirname, '..');
const chrome = process.env.QINMED_CHROME || 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const html = path.resolve(process.argv[2] || path.join(root, 'QinMed_Imaging_Guard_Standalone.html'));
const desktop = path.resolve(process.argv[3] || path.join(root, 'docs', 'QinMed_v0.2.0_UI_Desktop.png'));
const mobile = path.resolve(process.argv[4] || path.join(root, 'docs', 'QinMed_v0.2.0_UI_Mobile.png'));
const port = 9317;
const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'qinmed-chrome-'));

function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

async function waitForJson(url, attempts = 80) {
  for (let i = 0; i < attempts; i += 1) {
    try {
      const response = await fetch(url);
      if (response.ok) return response.json();
    } catch (_) {}
    await delay(100);
  }
  throw new Error(`Chrome DevTools endpoint did not become ready: ${url}`);
}

function cdpClient(wsUrl) {
  const socket = new WebSocket(wsUrl);
  let nextId = 1;
  const pending = new Map();
  const events = new Map();
  const opened = new Promise((resolve, reject) => {
    socket.addEventListener('open', resolve, { once: true });
    socket.addEventListener('error', reject, { once: true });
  });
  socket.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id && pending.has(message.id)) {
      const { resolve, reject } = pending.get(message.id);
      pending.delete(message.id);
      if (message.error) reject(new Error(message.error.message));
      else resolve(message.result || {});
      return;
    }
    const waiters = events.get(message.method);
    if (waiters && waiters.length) waiters.shift()(message.params || {});
  });
  return {
    opened,
    send(method, params = {}) {
      const id = nextId++;
      return new Promise((resolve, reject) => {
        pending.set(id, { resolve, reject });
        socket.send(JSON.stringify({ id, method, params }));
      });
    },
    once(method) {
      return new Promise(resolve => {
        const waiters = events.get(method) || [];
        waiters.push(resolve);
        events.set(method, waiters);
      });
    },
    close() { socket.close(); }
  };
}

async function capture(client, output, width, height, isMobile) {
  await client.send('Emulation.setDeviceMetricsOverride', {
    width, height, deviceScaleFactor: 1, mobile: isMobile,
    screenWidth: width, screenHeight: height
  });
  const loaded = client.once('Page.loadEventFired');
  await client.send('Page.navigate', { url: pathToFileURL(html).href });
  await loaded;
  await delay(750);
  const { data } = await client.send('Page.captureScreenshot', {
    format: 'png', fromSurface: true, captureBeyondViewport: false
  });
  fs.mkdirSync(path.dirname(output), { recursive: true });
  fs.writeFileSync(output, Buffer.from(data, 'base64'));
}

async function main() {
  if (!fs.existsSync(html)) throw new Error(`Standalone HTML not found: ${html}`);
  const child = spawn(chrome, [
    '--headless=new', '--disable-gpu', '--no-sandbox', '--hide-scrollbars',
    '--no-first-run', '--disable-extensions', '--allow-file-access-from-files',
    `--remote-debugging-port=${port}`, `--user-data-dir=${profile}`, 'about:blank'
  ], { stdio: 'ignore', windowsHide: true });
  try {
    await waitForJson(`http://127.0.0.1:${port}/json/version`);
    const target = await fetch(`http://127.0.0.1:${port}/json/new?about:blank`, { method: 'PUT' }).then(r => r.json());
    const client = cdpClient(target.webSocketDebuggerUrl);
    await client.opened;
    await client.send('Page.enable');
    await capture(client, desktop, 1440, 1100, false);
    await capture(client, mobile, 390, 844, true);
    client.close();
    console.log(JSON.stringify({ desktop, mobile, viewport: { desktop: [1440, 1100], mobile: [390, 844] } }, null, 2));
  } finally {
    child.kill();
  }
}

main().catch(error => {
  console.error(error.stack || error.message);
  process.exitCode = 1;
});
