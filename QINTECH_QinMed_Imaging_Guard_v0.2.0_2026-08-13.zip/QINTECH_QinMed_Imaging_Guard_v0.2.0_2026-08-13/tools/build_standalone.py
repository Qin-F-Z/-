from __future__ import annotations

import base64
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "web"
DESTINATION = ROOT / "QinMed_Imaging_Guard_Standalone.html"


def main() -> None:
    html = (WEB / "index.html").read_text(encoding="utf-8")
    css = (WEB / "styles.css").read_text(encoding="utf-8")
    engine = (WEB / "engine.js").read_text(encoding="utf-8")
    app = (WEB / "app.js").read_text(encoding="utf-8")
    logo = base64.b64encode((WEB / "assets" / "qintech-logo.png").read_bytes()).decode("ascii")

    html = html.replace("script-src 'self';", "script-src 'unsafe-inline';")
    html = html.replace("style-src 'self';", "style-src 'unsafe-inline';")
    html = html.replace('<link rel="stylesheet" href="styles.css">', f"<style>\n{css}\n</style>")
    html = html.replace('src="assets/qintech-logo.png"', f'src="data:image/png;base64,{logo}"')
    html = html.replace('<script src="engine.js"></script>', f"<script>\n{engine}\n</script>")
    html = html.replace('<script src="app.js"></script>', f"<script>\n{app}\n</script>")
    DESTINATION.write_text(html, encoding="utf-8")
    print(f"Built {DESTINATION} ({DESTINATION.stat().st_size} bytes)")


if __name__ == "__main__":
    main()

