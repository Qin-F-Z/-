#!/usr/bin/env python3
"""Prepare and finalize a deterministic QinMed release directory."""

from __future__ import annotations

import argparse
import hashlib
import shutil
import sys
import zipfile
from pathlib import Path, PurePosixPath


ROOT_FILES = {
    "安装_真实数据可选能力.ps1",
    "启动_QinMed_Imaging_Guard.bat",
    "CHANGELOG.md",
    "install_optional.sh",
    "LICENSE.txt",
    "QinMed_Imaging_Guard_Standalone.html",
    "README_从这里开始.md",
    "release.json",
    "requirements-optional.txt",
    "requirements.txt",
    "SBOM.json",
    "THIRD_PARTY_NOTICES.md",
    "verification_report.json",
    "VERIFICATION_REPORT.md",
    "verify_all.ps1",
    "verify_all.sh",
}
DIRECTORIES = {"docs", "examples", "protocols", "qinmed", "schemas", "source_material", "tests", "tools", "verifier", "web"}
EXCLUDED_NAMES = {"QinMed_UI_Desktop.png", "QinMed_UI_Mobile.png", "SHA256SUMS.txt", ".DS_Store"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def include(relative: Path) -> bool:
    return not (
        relative.name in EXCLUDED_NAMES
        or relative.suffix == ".pyc"
        or "__pycache__" in relative.parts
        or "qa" in relative.parts
    )


def prepare(source: Path, destination: Path) -> None:
    source = source.resolve()
    destination = destination.resolve()
    if destination.exists():
        raise FileExistsError(f"Refusing to overwrite existing release directory: {destination}")
    destination.mkdir(parents=True)
    for name in sorted(ROOT_FILES):
        candidate = source / name
        if not candidate.is_file():
            raise FileNotFoundError(f"Required release file missing: {candidate}")
        shutil.copy2(candidate, destination / name)
    for directory in sorted(DIRECTORIES):
        base = source / directory
        if not base.is_dir():
            raise FileNotFoundError(f"Required release directory missing: {base}")
        for candidate in sorted(base.rglob("*")):
            if not candidate.is_file():
                continue
            relative = candidate.relative_to(source)
            if not include(relative):
                continue
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(candidate, target)
    print(destination)


def write_manifest(release: Path) -> list[tuple[str, str]]:
    manifest = release / "SHA256SUMS.txt"
    items: list[tuple[str, str]] = []
    for candidate in sorted(release.rglob("*")):
        if candidate.is_file() and candidate != manifest and include(candidate.relative_to(release)):
            items.append((sha256(candidate), candidate.relative_to(release).as_posix()))
    manifest.write_text("".join(f"{digest}  {name}\n" for digest, name in items), encoding="utf-8", newline="\n")
    return items


def finalize(release: Path, archive: Path) -> None:
    release = release.resolve()
    archive = archive.resolve()
    if not release.is_dir():
        raise FileNotFoundError(release)
    write_manifest(release)
    if archive.exists():
        raise FileExistsError(f"Refusing to overwrite existing archive: {archive}")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for candidate in sorted(release.rglob("*")):
            if candidate.is_file():
                bundle.write(candidate, (Path(release.name) / candidate.relative_to(release)).as_posix())
    checksum = sha256(archive)
    archive.with_suffix(archive.suffix + ".sha256.txt").write_text(
        f"{checksum}  {archive.name}\n", encoding="utf-8", newline="\n"
    )
    print(f"archive={archive}")
    print(f"sha256={checksum}")


def verify_manifest(release: Path) -> None:
    release = release.resolve()
    manifest = release / "SHA256SUMS.txt"
    failures = []
    for line in manifest.read_text(encoding="utf-8").splitlines():
        expected, name = line.split("  ", 1)
        candidate = (release / Path(PurePosixPath(name))).resolve()
        if release not in candidate.parents:
            failures.append(f"unsafe path: {name}")
        elif not candidate.is_file():
            failures.append(f"missing: {name}")
        elif sha256(candidate) != expected:
            failures.append(f"hash mismatch: {name}")
    if failures:
        raise RuntimeError("; ".join(failures))
    print(f"PASS: {manifest}")


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    prep = sub.add_parser("prepare")
    prep.add_argument("source", type=Path)
    prep.add_argument("destination", type=Path)
    final = sub.add_parser("finalize")
    final.add_argument("release", type=Path)
    final.add_argument("archive", type=Path)
    check = sub.add_parser("verify-manifest")
    check.add_argument("release", type=Path)
    args = parser.parse_args()
    if args.command == "prepare":
        prepare(args.source, args.destination)
    elif args.command == "finalize":
        finalize(args.release, args.archive)
    else:
        verify_manifest(args.release)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise
