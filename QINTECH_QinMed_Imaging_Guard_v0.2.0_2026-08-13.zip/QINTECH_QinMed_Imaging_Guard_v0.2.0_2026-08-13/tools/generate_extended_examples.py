from __future__ import annotations

import json
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "verifier"))

from qinmed.artifacts import write_pgm
from qinmed.blind_eval import evaluate, lock_protocol
from qinmed.datasets import reconstruct_to_files
from qinmed.dicom_guard import deidentify_dicom
from qinmed.imaging import make_phantom
from qinmed.signing import generate_keypair, sign_evidence
from qinevidence_verify import verify


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def make_fastmri_fixture(path: Path) -> None:
    import h5py
    import numpy as np

    size = 32
    image = np.asarray(make_phantom(size, "anatomy"), dtype=np.float32).reshape(size, size) / 4095.0
    y, x = np.mgrid[:size, :size]
    coils = []
    for index, phase in enumerate((0.0, 0.7, 1.4, 2.1)):
        sensitivity = (0.72 + 0.08 * index) * np.exp(1j * (phase + (x - y) * 0.003 * (index + 1)))
        coils.append(image * sensitivity)
    coil_images = np.stack(coils)
    kspace = np.fft.fftshift(np.fft.fft2(np.fft.ifftshift(coil_images, axes=(-2, -1)), axes=(-2, -1), norm="ortho"), axes=(-2, -1)).astype(np.complex64)
    path.parent.mkdir(parents=True, exist_ok=True)
    with h5py.File(path, "w") as handle:
        handle.create_dataset("kspace", data=np.stack([kspace, kspace * np.complex64(0.95)]))
        handle.attrs["acquisition"] = "SYNTHETIC_QINMED_TEST_ONLY"
        handle.attrs["patient_data"] = "NONE"


def make_dicom_fixture(path: Path) -> None:
    from pydicom.dataset import FileDataset, FileMetaDataset
    from pydicom.uid import ExplicitVRLittleEndian, SecondaryCaptureImageStorage, generate_uid

    meta = FileMetaDataset()
    meta.MediaStorageSOPClassUID = SecondaryCaptureImageStorage
    meta.MediaStorageSOPInstanceUID = generate_uid()
    meta.TransferSyntaxUID = ExplicitVRLittleEndian
    meta.ImplementationClassUID = generate_uid()
    dataset = FileDataset(str(path), {}, file_meta=meta, preamble=b"\0" * 128)
    dataset.SOPClassUID = SecondaryCaptureImageStorage
    dataset.SOPInstanceUID = meta.MediaStorageSOPInstanceUID
    dataset.StudyInstanceUID = generate_uid()
    dataset.SeriesInstanceUID = generate_uid()
    dataset.PatientName = "SYNTHETIC^NOT_A_PATIENT"
    dataset.PatientID = "SYNTHETIC-0001"
    dataset.PatientBirthDate = "19000101"
    dataset.StudyDate = "20260813"
    dataset.InstitutionName = "SYNTHETIC TEST SITE"
    dataset.BurnedInAnnotation = "NO"
    dataset.Rows = 16
    dataset.Columns = 16
    dataset.SamplesPerPixel = 1
    dataset.PhotometricInterpretation = "MONOCHROME2"
    dataset.BitsAllocated = 16
    dataset.BitsStored = 12
    dataset.HighBit = 11
    dataset.PixelRepresentation = 0
    pixels = make_phantom(32, "low_contrast")
    sampled = [pixels[(row * 2) * 32 + column * 2] for row in range(16) for column in range(16)]
    dataset.PixelData = b"".join(int(value).to_bytes(2, "little") for value in sampled)
    dataset.add_new((0x0011, 0x0010), "LO", "SYNTHETIC_PRIVATE_CREATOR")
    path.parent.mkdir(parents=True, exist_ok=True)
    dataset.save_as(str(path), enforce_file_format=True)


def sign_file(path: Path, private: Path, fingerprint: str, artifact_root: Path) -> None:
    document = json.loads(path.read_text(encoding="utf-8"))
    signed = sign_evidence(document, private)
    signed_path = path.with_name(path.stem.replace(".qinevidence", "") + ".signed.qinevidence.json")
    write_json(signed_path, signed)
    result = verify(signed, artifact_root, True, {fingerprint}, True)
    if not result["valid"]:
        raise RuntimeError(result)


def main() -> None:
    examples = ROOT / "examples" / "v0.2-extended"
    examples.mkdir(parents=True, exist_ok=True)

    fastmri_root = examples / "fastmri-synthetic"
    fastmri_source = fastmri_root / "synthetic-fastmri.h5"
    make_fastmri_fixture(fastmri_source)
    reconstruct_to_files(fastmri_source, fastmri_root / "result", slice_index=0, crop=32)

    blind_root = examples / "blind-eval-synthetic"
    references, predictions = blind_root / "references", blind_root / "predictions"
    references.mkdir(parents=True, exist_ok=True)
    predictions.mkdir(parents=True, exist_ok=True)
    cases = []
    for index, variant in enumerate(("low_contrast", "resolution", "anatomy"), start=1):
        case_id = f"case{index:02d}"
        reference = make_phantom(32, variant)
        prediction = [min(4095, value + (1 if position % 23 == 0 else 0)) for position, value in enumerate(reference)]
        write_pgm(references / f"{case_id}.pgm", reference, 32, 32)
        write_pgm(predictions / f"{case_id}.pgm", prediction, 32, 32)
        cases.append({"case_id": case_id, "reference": f"references/{case_id}.pgm", "group": variant})
    manifest = blind_root / "cases.json"
    write_json(manifest, {"dataset": "QinMed synthetic non-patient fixture", "cases": cases})
    protocol = blind_root / "locked-protocol.json"
    lock_protocol(manifest, protocol, name="QinMed synthetic sealed-reference evaluation", model_id="qinmed-file-adapter-demo")
    evaluate(protocol, manifest, predictions, blind_root / "result")

    dicom_root = examples / "dicom-synthetic"
    dicom_source = dicom_root / "SYNTHETIC_NOT_PATIENT_source.dcm"
    make_dicom_fixture(dicom_source)
    deidentify_dicom(dicom_source, dicom_root / "result" / "deidentified.dcm", dicom_root / "result" / "deidentification-report.json", b"QINMED-SYNTHETIC-DEMO-SECRET-DO-NOT-REUSE")

    trust_root = examples / "trust"
    with tempfile.TemporaryDirectory() as directory:
        private = Path(directory) / "ephemeral-private.pem"
        public = trust_root / "demo-public.pem"
        identity = generate_keypair(private, public)
        fingerprint = identity["public_key_fingerprint"]
        (trust_root / "demo-public-fingerprint.txt").write_text(fingerprint + "\n", encoding="utf-8")
        sign_file(fastmri_root / "result" / "slice-0000.qinevidence.json", private, fingerprint, fastmri_root / "result")
        sign_file(blind_root / "result" / "blind-eval.qinevidence.json", private, fingerprint, blind_root / "result")
        sign_file(dicom_root / "result" / "dicom-deidentification.qinevidence.json", private, fingerprint, dicom_root / "result")

    notice = """# Demo signing identity\n\nThe packaged public key verifies the three synthetic example evidence files. The private key was generated ephemerally and was not packaged. This demonstrates cryptographic integrity only; it is not a QINTECH production identity, trusted timestamp, organizational certificate, or regulatory endorsement.\n"""
    (trust_root / "DEMO_IDENTITY_NOTICE.md").write_text(notice, encoding="utf-8")
    print(json.dumps({"output": str(examples), "status": "PASS", "patient_data": "NONE"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

