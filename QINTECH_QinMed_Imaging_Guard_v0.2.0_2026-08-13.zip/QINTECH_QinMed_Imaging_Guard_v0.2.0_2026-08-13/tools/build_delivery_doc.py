from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "docs" / "QinMed_v0.2.0_技术验收与商业化执行书.docx"
LOGO = ROOT / "web" / "assets" / "qintech-logo.png"

BLUE = "2E74B5"
DARK_BLUE = "1F4D78"
INK = "172033"
MUTED = "667085"
LIGHT = "F2F4F7"
PALE_BLUE = "E8EEF5"
PALE_GREEN = "E9F7EF"
PALE_GOLD = "FFF4DC"
PALE_RED = "FDEBEC"
WHITE = "FFFFFF"


def set_font(run, *, latin="Calibri", east_asia="Microsoft YaHei", size=11, bold=None, color=INK, italic=None):
    run.font.name = latin
    run._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:ascii"), latin)
    run._element.rPr.rFonts.set(qn("w:hAnsi"), latin)
    run._element.rPr.rFonts.set(qn("w:eastAsia"), east_asia)
    run.font.size = Pt(size)
    run.font.color.rgb = RGBColor.from_string(color)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic


def shade(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for edge, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{edge}"))
        if node is None:
            node = OxmlElement(f"w:{edge}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_geometry(table, widths):
    if sum(widths) != 9360:
        raise ValueError("table widths must sum to 9360 DXA")
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.autofit = False
    tbl_pr = table._tbl.tblPr
    for tag, attrs in (
        ("tblW", {"w": "9360", "type": "dxa"}),
        ("tblInd", {"w": "120", "type": "dxa"}),
        ("tblLayout", {"type": "fixed"}),
    ):
        node = tbl_pr.find(qn(f"w:{tag}"))
        if node is None:
            node = OxmlElement(f"w:{tag}")
            tbl_pr.append(node)
        for key, value in attrs.items():
            node.set(qn(f"w:{key}"), value)
    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)
    for row in table.rows:
        for cell, width in zip(row.cells, widths):
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(width))
            tc_w.set(qn("w:type"), "dxa")
            set_cell_margins(cell)
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


def set_repeat_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def set_paragraph_border(paragraph, color="D8DEE8", size="8"):
    p_pr = paragraph._p.get_or_add_pPr()
    p_bdr = p_pr.find(qn("w:pBdr"))
    if p_bdr is None:
        p_bdr = OxmlElement("w:pBdr")
        p_pr.append(p_bdr)
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), size)
    bottom.set(qn("w:space"), "7")
    bottom.set(qn("w:color"), color)
    p_bdr.append(bottom)


def add_page_field(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run("第 ")
    set_font(run, size=8.5, color=MUTED)
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    separate = OxmlElement("w:fldChar")
    separate.set(qn("w:fldCharType"), "separate")
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.extend([begin, instr, separate, end])
    tail = paragraph.add_run(" 页")
    set_font(tail, size=8.5, color=MUTED)


def configure_styles(doc):
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = section.bottom_margin = Inches(1)
    section.left_margin = section.right_margin = Inches(1)
    section.header_distance = section.footer_distance = Inches(0.492)

    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.font.size = Pt(11)
    normal.font.color.rgb = RGBColor.from_string(INK)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.10

    for name, size, color, before, after in (
        ("Heading 1", 16, BLUE, 16, 8),
        ("Heading 2", 13, BLUE, 12, 6),
        ("Heading 3", 12, DARK_BLUE, 8, 4),
    ):
        style = doc.styles[name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True


def make_numbering(doc):
    numbering = doc.part.numbering_part.element
    ids = [int(node.get(qn("w:abstractNumId"))) for node in numbering.findall(qn("w:abstractNum"))]
    num_ids = [int(node.get(qn("w:numId"))) for node in numbering.findall(qn("w:num"))]
    abstract_id = max(ids, default=0) + 1
    num_id = max(num_ids, default=0) + 1
    abstract = OxmlElement("w:abstractNum")
    abstract.set(qn("w:abstractNumId"), str(abstract_id))
    multi = OxmlElement("w:multiLevelType")
    multi.set(qn("w:val"), "singleLevel")
    abstract.append(multi)
    level = OxmlElement("w:lvl")
    level.set(qn("w:ilvl"), "0")
    start = OxmlElement("w:start")
    start.set(qn("w:val"), "1")
    num_fmt = OxmlElement("w:numFmt")
    num_fmt.set(qn("w:val"), "bullet")
    lvl_text = OxmlElement("w:lvlText")
    lvl_text.set(qn("w:val"), "•")
    p_pr = OxmlElement("w:pPr")
    tabs = OxmlElement("w:tabs")
    tab = OxmlElement("w:tab")
    tab.set(qn("w:val"), "num")
    tab.set(qn("w:pos"), "720")
    tabs.append(tab)
    ind = OxmlElement("w:ind")
    ind.set(qn("w:left"), "720")
    ind.set(qn("w:hanging"), "360")
    spacing = OxmlElement("w:spacing")
    spacing.set(qn("w:after"), "160")
    spacing.set(qn("w:line"), "280")
    spacing.set(qn("w:lineRule"), "auto")
    p_pr.extend([tabs, ind, spacing])
    level.extend([start, num_fmt, lvl_text, p_pr])
    abstract.append(level)
    numbering.append(abstract)
    num = OxmlElement("w:num")
    num.set(qn("w:numId"), str(num_id))
    ref = OxmlElement("w:abstractNumId")
    ref.set(qn("w:val"), str(abstract_id))
    num.append(ref)
    numbering.append(num)
    return num_id


def bullet(doc, text, num_id):
    paragraph = doc.add_paragraph()
    p_pr = paragraph._p.get_or_add_pPr()
    num_pr = OxmlElement("w:numPr")
    ilvl = OxmlElement("w:ilvl")
    ilvl.set(qn("w:val"), "0")
    num = OxmlElement("w:numId")
    num.set(qn("w:val"), str(num_id))
    num_pr.extend([ilvl, num])
    p_pr.append(num_pr)
    run = paragraph.add_run(text)
    set_font(run)
    return paragraph


def add_table(doc, headers, rows, widths, status_column=None):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    set_table_geometry(table, widths)
    set_repeat_header(table.rows[0])
    for index, header in enumerate(headers):
        cell = table.rows[0].cells[index]
        shade(cell, LIGHT)
        paragraph = cell.paragraphs[0]
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER if index != 0 else WD_ALIGN_PARAGRAPH.LEFT
        run = paragraph.add_run(header)
        set_font(run, size=9.5, bold=True, color=DARK_BLUE)
    for row in rows:
        cells = table.add_row().cells
        for index, value in enumerate(row):
            paragraph = cells[index].paragraphs[0]
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER if index == status_column else WD_ALIGN_PARAGRAPH.LEFT
            run = paragraph.add_run(str(value))
            color = INK
            if index == status_column:
                upper = str(value).upper()
                fill = PALE_GREEN if "PASS" in upper or "READY" in upper else PALE_GOLD if "UNKNOWN" in upper or "EXTERNAL" in upper or "CONDITIONAL" in upper else PALE_RED
                shade(cells[index], fill)
                color = DARK_BLUE
                run.bold = True
            set_font(run, size=9.2, bold=run.bold, color=color)
            paragraph.paragraph_format.space_after = Pt(2)
            paragraph.paragraph_format.line_spacing = 1.08
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return table


def callout(doc, label, text, fill=PALE_BLUE):
    table = doc.add_table(rows=1, cols=1)
    set_table_geometry(table, [9360])
    cell = table.cell(0, 0)
    shade(cell, fill)
    paragraph = cell.paragraphs[0]
    paragraph.paragraph_format.space_after = Pt(0)
    lead = paragraph.add_run(label + "  ")
    set_font(lead, size=10.5, bold=True, color=DARK_BLUE)
    body = paragraph.add_run(text)
    set_font(body, size=10.5, color=INK)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def add_body(doc, text, *, bold_lead=None):
    paragraph = doc.add_paragraph()
    if bold_lead and text.startswith(bold_lead):
        lead = paragraph.add_run(bold_lead)
        set_font(lead, bold=True)
        run = paragraph.add_run(text[len(bold_lead):])
        set_font(run)
    else:
        run = paragraph.add_run(text)
        set_font(run)
    return paragraph


def heading(doc, text, level=1):
    paragraph = doc.add_paragraph(text, style=f"Heading {level}")
    for run in paragraph.runs:
        set_font(run, size={1: 16, 2: 13, 3: 12}[level], bold=True, color={1: BLUE, 2: BLUE, 3: DARK_BLUE}[level])
    return paragraph


def build():
    doc = Document()
    configure_styles(doc)
    bullet_id = make_numbering(doc)
    section = doc.sections[0]
    doc.settings.odd_and_even_pages_header_footer = False
    section.different_first_page_header_footer = False

    header = section.header
    hp = header.paragraphs[0]
    hp.text = "QINTECH · QinMed Imaging Guard"
    set_font(hp.runs[0], size=8.5, bold=True, color=MUTED)
    hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    set_paragraph_border(hp, color="D8DEE8", size="4")
    add_page_field(section.footer.paragraphs[0])

    if LOGO.is_file():
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(10)
        logo = p.add_run().add_picture(str(LOGO), width=Inches(1.35))
        logo._inline.docPr.set("descr", "QINTECH 品牌标志")
        logo._inline.docPr.set("title", "QINTECH")
    kicker = doc.add_paragraph()
    kicker.paragraph_format.space_after = Pt(4)
    set_font(kicker.add_run("TECHNICAL ACCEPTANCE & COMMERCIAL EXECUTION BRIEF"), size=9, bold=True, color=BLUE)
    title = doc.add_paragraph()
    title.paragraph_format.space_after = Pt(5)
    set_font(title.add_run("QinMed Imaging Guard v0.2.0"), size=25, bold=True, color="111827")
    subtitle = doc.add_paragraph()
    subtitle.paragraph_format.space_after = Pt(14)
    set_font(subtitle.add_run("技术验收、证据边界与商业化执行书"), size=15, bold=True, color=DARK_BLUE)

    for label, value in (
        ("版本", "Research Edition v0.2.0"),
        ("日期", "2026-08-13"),
        ("状态", "本机实现完成；外部临床、数据托管、正式符合性与监管验证待开展"),
        ("适用", "医学成像算法 QA、可复验评测、隐私预处理研究、试点与专利实施例"),
    ):
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(label + "："), size=10.5, bold=True, color=INK)
        set_font(p.add_run(value), size=10.5, color=INK)
    rule = doc.add_paragraph()
    set_paragraph_border(rule, color=BLUE, size="12")

    callout(doc, "决策摘要", "v0.2.0 已从合成演示升级为可运行的医学成像验证基础设施。最有价值的商业路径是私有部署的模型版本验证、持续复验和 OEM 证据层，而不是把它包装成低价图像增强软件。", PALE_BLUE)
    add_table(doc, ["能力", "验收状态", "当前可交付结果"], [
        ("确定性整数成像", "PASS", "六种舍入语义、重放、有限扰动、浏览器/Python 证据互操作"),
        ("fastMRI Guard", "PASS", "HDF5 检查、零填充/RSS、12-bit 工件与证据"),
        ("锁定协议评测", "PASS", "协议/案例承诺、逐例失败保留、指标与 bootstrap"),
        ("DICOM Guard", "CONDITIONAL", "研究去标识候选与失败闭合隐私门；不宣称完全符合"),
        ("证据签名", "PASS", "Ed25519、工件哈希、独立公钥指纹固定"),
        ("临床/监管", "EXTERNAL", "必须由授权机构、独立研究者和监管流程完成"),
    ], [2100, 1500, 5760], status_column=1)

    doc.add_page_break()
    heading(doc, "1. 产品定位与不可混淆的边界")
    add_body(doc, "QinMed Imaging Guard 的核心价值是回答“这份报告是否对应这组数据、模型、参数、环境和隐私处理”，并使第三方能够独立复验。它不是诊断软件，也不根据图像给出疾病判断。")
    heading(doc, "1.1 允许声称", 2)
    for item in (
        "对声明的整数成像流程执行确定性重放并比较工件哈希。",
        "对 fastMRI 兼容 HDF5 的结构和指定切片执行可记录的零填充/RSS 基线。",
        "在评分前冻结案例清单、模型身份、指标、阈值、失败政策和统计种子。",
        "对配置内 DICOM 标识符、私有标签、overlay 和烧录标志执行研究级隐私门。",
        "用 Ed25519 签署证据核心，并由验证方固定公钥指纹。",
    ):
        bullet(doc, item, bullet_id)
    heading(doc, "1.2 禁止声称", 2)
    for item in (
        "不得声称提高 ADC 有效位数、突破噪声物理极限或恢复未采集信息。",
        "不得把 SSIM、PSNR 或合成体模结果升级为临床安全、诊断准确率或患者获益。",
        "不得声称 DICOM PS3.15 完全符合、像素无 PHI、PACS 生产兼容或监管批准。",
        "不得把演示签名密钥解释为 QINTECH 组织身份、可信时间戳或第三方认证。",
    ):
        bullet(doc, item, bullet_id)
    callout(doc, "原则", "通过只覆盖已执行且有证据的检查；未知、排除或未获得授权的事项必须继续显示为 UNKNOWN / EXTERNAL。", PALE_GOLD)

    heading(doc, "2. 端到端技术架构")
    add_table(doc, ["阶段", "输入", "处理", "证据输出"], [
        ("01 数据承诺", "HDF5 / DICOM / PGM", "最小读取、授权边界、SHA-256", "source commitment"),
        ("02 数值冻结", "k-space 或整数图像", "FFT/RSS 或 QinFixed 舍入", "12-bit canonical artifact"),
        ("03 模型评测", "case_id 输出", "失败保留、NRMSE/SSIM/PSNR", "case registry + report"),
        ("04 隐私门", "DICOM", "标识符、私有标签、overlay、烧录标志", "conditional release report"),
        ("05 信任层", "core + artifacts", "内容寻址、Ed25519、指纹固定", "signed QinEvidence"),
    ], [1180, 1950, 3100, 3130])

    section_three = heading(doc, "3. fastMRI Guard 与真实模型接口")
    add_body(doc, "适配器读取 fastMRI 兼容 HDF5 的 kspace，单线圈执行逆 FFT，多线圈执行 root-sum-of-squares。浮点重建随后以有限值 99.5 百分位归一化并按 half-even 规则冻结为 12-bit PGM。")
    callout(doc, "数值边界", "整数工件和哈希在本次运行后可复验；不同 NumPy/FFT 库、CPU 指令或硬件之间的浮点逐位一致性尚未证明。", PALE_GOLD)
    heading(doc, "3.1 锁定协议评测", 2)
    add_body(doc, "`protocol-lock` 在评分前绑定案例清单哈希、模型 ID、主次指标、阈值、失败政策、bootstrap 次数和种子。评测器只读取 `<case_id>.pgm`，不会执行任意模型代码；缺失、损坏或尺寸不符均不会静默排除。")
    add_table(doc, ["指标", "用途", "解释边界"], [
        ("NRMSE", "相对动态范围的重建误差", "动态范围为零时不产生伪造有限值"),
        ("Global SSIM", "整幅图统计诊断", "不是局部病灶或临床读片终点"),
        ("PSNR / MAE", "辅助误差描述", "完美一致时 PSNR 记录为无限标志而非非法 JSON 数值"),
        ("Failure rate", "完整性与鲁棒性", "缺失案例计失败，不做幸存者偏差筛选"),
        ("Bootstrap CI", "案例均值不确定性", "固定种子保证评测程序可复演"),
    ], [1600, 3100, 4660])
    heading(doc, "3.2 外部盲法尚需完成", 2)
    add_body(doc, "本机软件能锁定协议，却不能证明操作者没有访问参考图像。正式验证应由独立数据托管方隔离参考目标，模型团队只取得输入，评分在受控环境执行并保留所有偏离。")

    heading(doc, "4. DICOM Guard：隐私门而非合规捷径")
    add_body(doc, "DICOM Guard 对配置内直接标识符进行清除或 HMAC 伪名化，递归处理序列，清除私有元素和 overlay，确定性重映射 UID，并对日期进行一致平移。")
    heading(doc, "4.1 失败闭合", 2)
    add_body(doc, "存在 PixelData 且 BurnedInAnnotation 不是明确 NO 时，工具拒绝产生去标识候选。这避免把元数据清理误称为像素级隐私证明。")
    add_table(doc, ["门", "软件可检查", "外部仍必须做"], [
        ("直接标识符", "配置关键字和非空值", "完整 PS3.15 动作表与厂商特例验证"),
        ("私有/overlay", "递归私有元素和 0x60xx overlay", "隐藏在封装对象、SR、PDF、视频中的内容"),
        ("像素 PHI", "BurnedInAnnotation 状态", "验证过的 OCR、人工视觉复核、面部处理"),
        ("多文件一致性", "单次秘密下确定性 UID", "跨批次保管、引用完整性和密钥生命周期"),
        ("发布责任", "conditional_pass", "授权、机构隐私审查、出境/保留政策"),
    ], [1750, 3500, 4110])
    callout(doc, "符合性声明", "本版本明确记录 profile_conformance = not_claimed。conditional_pass 是继续外部复核的必要条件，不是临床或外部发布的充分条件。", PALE_RED)

    heading(doc, "5. QinEvidence 与签名信任")
    add_body(doc, "证据核心包含输入/输出、执行配置、结果、检查、声称、假设、排除项、环境和生命周期。evidence_id 是规范化 core 的 SHA-256 内容地址。")
    add_table(doc, ["层级", "验证内容", "保证"], [
        ("Hash valid", "core_hash 与 evidence_id", "证据核心未被篡改"),
        ("Artifact valid", "声明工件路径、大小和 SHA-256", "报告对应这些工件"),
        ("Signed untrusted", "Ed25519 数学验签", "某个私钥签过，但身份未独立确认"),
        ("Signed trusted", "验签 + 独立登记指纹", "签名密钥属于验证方信任列表"),
        ("Lifecycle valid", "valid / expired / revoked / superseded", "证据仍在声明生命周期内"),
    ], [1800, 3600, 3960])

    section_six = heading(doc, "6. 本机验收结果")
    section_six.paragraph_format.page_break_before = True
    add_table(doc, ["验证项", "结果", "证明对象"], [
        ("Python 单元与集成测试", "10 / 10 PASS", "核心、PGM、fastMRI、盲测、DICOM、签名"),
        ("JavaScript 引擎测试", "PASS", "舍入、重放、范围、指标、SHA-256"),
        ("fastMRI 签名示例", "SIGNED_TRUSTED", "源承诺、PGM、报告和证据"),
        ("盲测签名示例", "SIGNED_TRUSTED", "锁定协议、案例注册表、报告"),
        ("DICOM 签名示例", "SIGNED_TRUSTED", "去标识候选、报告、边界"),
        ("篡改测试", "REJECTED", "证据 core 与锁定协议修改"),
        ("患者数据", "NONE", "所有扩展示例均为本地合成"),
    ], [3000, 1800, 4560], status_column=1)
    heading(doc, "6.1 一键复验", 2)
    add_body(doc, "$env:QINMED_PYTHON='C:\\path\\to\\python.exe'; .\\verify_all.ps1 -RequireOptional")
    add_body(doc, "验证脚本不修改正式示例；临时运行目录位于系统临时目录并在完成后清理。可选依赖缺失时核心验证仍可执行，使用 -RequireOptional 可将缺失依赖升级为失败。")

    heading(doc, "7. 商业化优先级")
    callout(doc, "最佳首单", "一个影像设备厂商、医学 AI 团队或医院算法平台的私有部署验证试点：锁定一个模型版本、一套授权数据和一组预注册指标，交付签名证据与失败案例。", PALE_GREEN)
    add_table(doc, ["阶段", "产品", "收入逻辑", "成功条件"], [
        ("试点", "固定范围项目验证", "一次性项目费", "客户侧复验通过；边界无争议"),
        ("续费", "模型更新持续监控", "年度订阅 + 用量", "每次模型/数据更新自动失效与复验"),
        ("扩张", "私有部署 / OEM", "许可、实施、支持", "客户密钥、隔离执行、审计日志"),
        ("监管准备", "技术文档与变更证据", "高价值专业服务", "由合格法规与临床团队主导"),
    ], [1350, 2650, 2350, 3010])
    heading(doc, "7.1 建议客户顺序", 2)
    for item in (
        "正在迭代 MRI/CT 重建、降噪或超分辨模型的影像设备与算法供应商。",
        "需要在内网验证多模型版本、保留失败证据的医院科研平台。",
        "为多家客户提供模型验证、DICOM 处理或合规材料的审计/测试机构。",
        "需要 OEM 证据层而不想自建内容寻址、签名和生命周期系统的软件公司。",
    ):
        bullet(doc, item, bullet_id)

    heading(doc, "8. 专利与商业秘密策略")
    add_body(doc, "专利主张不应落在已知的 FFT、SSIM、哈希、Ed25519 或通用去标识本身，而应围绕它们在医学成像评测中的组合状态机、失败闭合交互、声称边界传播和升级失效机制。")
    add_table(doc, ["资产", "保护方式", "披露策略"], [
        ("协议锁定 + 整数冻结 + 证据绑定", "发明专利候选", "申请前不公开核心权利要求树"),
        ("DICOM 隐私门与评测状态联动", "发明专利候选", "以实施例和失败路径说明技术效果"),
        ("声称—检查—排除项结构", "专利 + 证据格式版权", "公开最小验证规范，保留高价值规则"),
        ("规则库、阈值、客户适配经验", "商业秘密", "仅私有部署和最小必要披露"),
        ("独立验证器", "开源或 source-available", "增强可信度，但先确认专利申请时序"),
    ], [2600, 2500, 4260])
    callout(doc, "申请前动作", "先冻结代码和发明日志，再由代理师完成现有技术检索、发明人确认、权利要求分层与中国/PCT/美国策略。工程文档不替代法律意见。", PALE_GOLD)

    heading(doc, "9. 无法在本机越过的最后边界")
    add_table(doc, ["外部事项", "为什么本机不能替代", "进入条件"], [
        ("数据授权与伦理", "需要数据控制者与伦理主体决定", "协议、DPA、IRB/豁免"),
        ("独立盲法", "操作者知识与参考托管是组织事实", "第三方托管与审计日志"),
        ("临床有效性", "需要医生、患者、临床终点与样本量", "预注册多中心研究"),
        ("正式 DICOM 符合性", "需要完整配置、测试工具与声明主体", "conformance testing 和声明"),
        ("监管批准", "由相应主管机构依法决定", "质量体系、技术档案和申报"),
        ("组织级签名身份", "需要法人控制密钥与可信登记", "HSM/KMS、证书和透明日志"),
    ], [2200, 3920, 3240])

    heading(doc, "10. 接下来 30 天执行清单")
    for item in (
        "由专利代理师在任何公开演示前审阅 v0.2.0 增补交底和现有技术矩阵。",
        "选择一个有授权的公开/合作 MRI 数据子集，完成独立托管的三方盲测演练。",
        "冻结一个真实模型或容器 digest，只通过文件输出合同接入，不把模型代码直接带入验证器。",
        "与 DICOM/隐私专家共同补全 PS3.15 动作表、像素 OCR 验证集和人工抽检 SOP。",
        "建立生产 HSM/KMS 密钥、公开指纹登记、证据透明日志和撤销机制。",
        "向一个设备厂商或算法团队出售固定范围私有试点，以客户侧复验作为验收标准。",
    ):
        bullet(doc, item, bullet_id)

    heading(doc, "参考资料")
    references = [
        "DICOM PS3.15 current edition: https://dicom.nema.org/medical/dicom/current/output/html/part15.html",
        "fastMRI official code and data contract: https://github.com/facebookresearch/fastMRI/blob/main/fastmri/data/README.md",
        "Knoll F, et al. fastMRI dataset. DOI: https://doi.org/10.1148/ryai.2020190007",
        "Knoll F, et al. fastMRI challenge. DOI: https://doi.org/10.1002/mrm.28338",
        "FDA ML-enabled medical device transparency principles: https://www.fda.gov/medical-devices/software-medical-device-samd/transparency-machine-learning-enabled-medical-devices-guiding-principles",
        "FDA PCCP guidance: https://www.fda.gov/media/166704/download",
    ]
    for item in references:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.18)
        p.paragraph_format.first_line_indent = Inches(-0.18)
        p.paragraph_format.space_after = Pt(4)
        set_font(p.add_run(item), size=8.8, color=MUTED)

    doc.core_properties.title = "QinMed Imaging Guard v0.2.0 技术验收与商业化执行书"
    doc.core_properties.subject = "Research validation, evidence boundaries, commercialization, and patent handoff"
    doc.core_properties.author = "QINTECH"
    doc.core_properties.keywords = "QinMed, medical imaging, fastMRI, DICOM, evidence, reproducibility"
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    build()
