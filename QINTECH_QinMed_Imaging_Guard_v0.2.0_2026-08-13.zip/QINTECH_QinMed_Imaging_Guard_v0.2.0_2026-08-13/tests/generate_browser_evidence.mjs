import fs from 'node:fs';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
require('../web/engine.js');
const Q = globalThis.QinMed;
const destination = process.argv[2];
if (!destination) throw new Error('destination path required');

const config = { size: 32, bits: 12, rounding: 'half_even', noise: 3, seed: 20260813, radius: 1, threshold: 180, strength: 70 };
const ideal = Q.makePhantom(config.size, 'low_contrast');
const raw = Q.acquire(ideal, config, 0);
const certified = Q.certifiedFilter(raw, config);
const model = Q.modelSurrogate(certified, config);
const repeat = Q.certifiedFilter(Q.acquire(ideal, config, 0), config);
const perturbation = Q.perturbationAudit(ideal, config, 3);
const hashes = {
  ideal_hash: Q.pixelDigest(ideal),
  raw_hash: Q.pixelDigest(raw),
  certified_hash: Q.pixelDigest(certified),
  model_hash: Q.pixelDigest(model),
  replay_hash: Q.pixelDigest(certified),
  replay_hash_repeat: Q.pixelDigest(repeat),
  source: 'synthetic:low_contrast'
};
const evidence = Q.buildEvidence(config, hashes, Q.metrics(certified, model), perturbation);
fs.writeFileSync(destination, JSON.stringify(evidence, null, 2), 'utf8');
console.log(evidence.evidence_id);
