import assert from 'node:assert/strict';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
require('../web/engine.js');
const Q = globalThis.QinMed;

assert.equal(Q.divRound(5, 2, 'half_even'), 2);
assert.equal(Q.divRound(7, 2, 'half_even'), 4);
assert.equal(Q.divRound(-5, 2, 'down'), -3);
assert.equal(Q.divRound(-5, 2, 'up'), -2);

const config = { size: 32, bits: 12, rounding: 'half_even', noise: 3, seed: 20260813, radius: 1, threshold: 180, strength: 70 };
const ideal = Q.makePhantom(32, 'low_contrast');
const raw1 = Q.acquire(ideal, config, 0);
const raw2 = Q.acquire(ideal, config, 0);
assert.deepEqual(Array.from(raw1), Array.from(raw2));
const certified1 = Q.certifiedFilter(raw1, config);
const certified2 = Q.certifiedFilter(raw2, config);
assert.equal(Q.pixelDigest(certified1), Q.pixelDigest(certified2));
const model = Q.modelSurrogate(certified1, config);
const audit = Q.metrics(certified1, model);
assert.ok(audit.maxAbs >= 0 && audit.mae >= 0);
assert.equal(Q.sha256('abc'), 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
console.log('PASS: QinMed browser engine rounding, replay, image range, metrics, and SHA-256.');

