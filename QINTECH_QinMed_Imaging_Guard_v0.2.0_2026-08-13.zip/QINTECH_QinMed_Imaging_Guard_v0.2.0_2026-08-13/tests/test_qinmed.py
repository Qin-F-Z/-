from __future__ import annotations

import copy
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "verifier"))

from qinmed.evidence import build_evidence
from qinmed.fixed import Rounding, div_round
from qinmed.imaging import Config, acquire, certified_filter, make_phantom, metrics, model_surrogate, perturbation_audit, pixel_digest
from qinevidence_verify import verify


class FixedTests(unittest.TestCase):
    def test_rounding_modes(self) -> None:
        self.assertEqual(div_round(5, 2, Rounding.HALF_EVEN), 2)
        self.assertEqual(div_round(7, 2, Rounding.HALF_EVEN), 4)
        self.assertEqual(div_round(5, 2, Rounding.HALF_UP), 3)
        self.assertEqual(div_round(-5, 2, Rounding.DOWN), -3)
        self.assertEqual(div_round(-5, 2, Rounding.UP), -2)
        self.assertEqual(div_round(-5, 2, Rounding.TOWARD_ZERO), -2)
        self.assertEqual(div_round(-5, 2, Rounding.AWAY_FROM_ZERO), -3)


class ImagingTests(unittest.TestCase):
    def setUp(self) -> None:
        self.config = Config(size=32, noise_codes=3, seed=20260813)
        self.ideal = make_phantom(32)

    def test_determinism_and_ranges(self) -> None:
        first = acquire(self.ideal, self.config)
        second = acquire(self.ideal, self.config)
        self.assertEqual(first, second)
        filtered = certified_filter(first, self.config)
        self.assertTrue(all(0 <= value <= 4095 for value in filtered))
        self.assertEqual(pixel_digest(filtered), pixel_digest(certified_filter(second, self.config)))

    def test_surrogate_and_metrics(self) -> None:
        filtered = certified_filter(acquire(self.ideal, self.config), self.config)
        model = model_surrogate(filtered, self.config)
        report = metrics(filtered, model)
        self.assertGreaterEqual(report["mae_codes"], 0)
        self.assertGreaterEqual(report["max_abs_codes"], 0)

    def test_perturbation_is_observed_not_proven(self) -> None:
        report = perturbation_audit(self.ideal, self.config, trials=3)
        self.assertEqual(report["status"], "observed_not_proven")
        self.assertEqual(len(report["range_map"]), 32 * 32)

    def test_qinevidence_valid_and_tamper_detected(self) -> None:
        filtered = certified_filter(acquire(self.ideal, self.config), self.config)
        model = model_surrogate(filtered, self.config)
        digest = pixel_digest(filtered)
        evidence = build_evidence(
            self.config,
            {"replay_hash": digest, "replay_hash_repeat": digest, "certified_hash": digest, "model_hash": pixel_digest(model)},
            metrics(filtered, model),
            perturbation_audit(self.ideal, self.config, trials=2),
            generated_at="2026-08-13T00:00:00Z",
        )
        self.assertTrue(verify(evidence, None, False)["valid"])
        tampered = copy.deepcopy(evidence)
        tampered["core"]["execution"]["seed"] += 1
        self.assertFalse(verify(tampered, None, False)["valid"])


if __name__ == "__main__":
    unittest.main()

