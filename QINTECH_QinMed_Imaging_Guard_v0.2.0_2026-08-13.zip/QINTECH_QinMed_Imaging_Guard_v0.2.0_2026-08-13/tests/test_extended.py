from __future__ import annotations

import copy
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "verifier"))

from qinmed.artifacts import read_pgm, write_pgm
from qinmed.blind_eval import evaluate, lock_protocol
from qinmed.datasets import inspect_fastmri, reconstruct_to_files
from qinmed.dicom_guard import audit_dicom, deidentify_dicom
from qinmed.evidence import build_evidence
from qinmed.imaging import Config, acquire, certified_filter, make_phantom, metrics, model_surrogate, perturbation_audit, pixel_digest
from qinmed.signing import generate_keypair, sign_evidence
from qinevidence_verify import verify


HAS_H5 = importlib.util.find_spec("h5py") is not None and importlib.util.find_spec("numpy") is not None
HAS_DICOM = importlib.util.find_spec("pydicom") is not None
HAS_CRYPTO = importlib.util.find_spec("cryptography") is not None


class ArtifactTests(unittest.TestCase):
    def test_pgm_roundtrip(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "image.pgm"
            values = [0, 1, 2048, 4095]
            write_pgm(path, values, 2, 2)
            loaded, width, height = read_pgm(path)
            self.assertEqual((width, height), (2, 2))
            self.assertEqual(loaded, values)


@unittest.skipUnless(HAS_H5, "numpy+h5py optional dependencies unavailable")
class FastMRIAdapterTests(unittest.TestCase):
    def test_fastmri_inspection_reconstruction_and_evidence(self) -> None:
        import h5py
        import numpy as np

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / "synthetic-fastmri.h5"
            image = np.zeros((16, 16), dtype=np.float32)
            image[4:12, 5:11] = 1.0
            coil_images = np.stack([image, image * 0.6])
            kspace = np.fft.fftshift(np.fft.fft2(np.fft.ifftshift(coil_images, axes=(-2, -1)), axes=(-2, -1), norm="ortho"), axes=(-2, -1))
            with h5py.File(path, "w") as handle:
                handle.create_dataset("kspace", data=np.stack([kspace, kspace]))
                handle.attrs["acquisition"] = "SYNTHETIC_TEST_ONLY"
            inspected = inspect_fastmri(path)
            self.assertEqual(inspected["inferred_track"], "multicoil")
            first = reconstruct_to_files(path, root / "run-a", slice_index=0, crop=16)
            second = reconstruct_to_files(path, root / "run-b", slice_index=0, crop=16)
            self.assertEqual(first["pixel_digest"], second["pixel_digest"])
            evidence_path = root / "run-a" / first["evidence"]
            evidence = json.loads(evidence_path.read_text(encoding="utf-8"))
            result = verify(evidence, root / "run-a", False)
            self.assertTrue(result["valid"], result)
            self.assertEqual(result["artifacts"]["status"], "valid")


class BlindEvaluationTests(unittest.TestCase):
    def test_locked_protocol_evaluation_and_tamper_rejection(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            references = root / "references"
            predictions = root / "predictions"
            references.mkdir()
            predictions.mkdir()
            cases = []
            for index, variant in enumerate(("low_contrast", "resolution", "anatomy"), start=1):
                case_id = f"case{index:02d}"
                values = make_phantom(32, variant)
                candidate = [min(4095, value + (1 if position % 19 == 0 else 0)) for position, value in enumerate(values)]
                write_pgm(references / f"{case_id}.pgm", values, 32, 32)
                write_pgm(predictions / f"{case_id}.pgm", candidate, 32, 32)
                cases.append({"case_id": case_id, "reference": f"references/{case_id}.pgm", "group": variant})
            manifest = root / "cases.json"
            manifest.write_text(json.dumps({"cases": cases}, indent=2), encoding="utf-8")
            protocol_path = root / "locked-protocol.json"
            protocol = lock_protocol(manifest, protocol_path, name="synthetic sealed-reference acceptance", model_id="qinmed-test-candidate")
            result = evaluate(protocol_path, manifest, predictions, root / "results")
            self.assertEqual(result["report"]["technical_acceptance"], "pass")
            verified = verify(result["evidence"], root / "results", False)
            self.assertTrue(verified["valid"], verified)
            tampered = copy.deepcopy(protocol)
            tampered["acceptance"]["min_mean_global_ssim"] = 0.1
            protocol_path.write_text(json.dumps(tampered), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "protocol hash mismatch"):
                evaluate(protocol_path, manifest, predictions, root / "tampered")


@unittest.skipUnless(HAS_DICOM, "pydicom optional dependency unavailable")
class DICOMGuardTests(unittest.TestCase):
    def _fixture(self, path: Path) -> None:
        import pydicom
        from pydicom.dataset import FileDataset, FileMetaDataset
        from pydicom.uid import ExplicitVRLittleEndian, SecondaryCaptureImageStorage, generate_uid

        meta = FileMetaDataset()
        meta.MediaStorageSOPClassUID = SecondaryCaptureImageStorage
        meta.MediaStorageSOPInstanceUID = generate_uid()
        meta.TransferSyntaxUID = ExplicitVRLittleEndian
        meta.ImplementationClassUID = generate_uid()
        dataset = FileDataset(str(path), {}, file_meta=meta, preamble=b"\0" * 128)
        dataset.SOPClassUID = SecondaryCaptureImageStorage
        dataset.SOPInstanceUID = meta.MediaStorageSOPInstanceUID
        dataset.StudyInstanceUID = generate_uid()
        dataset.SeriesInstanceUID = generate_uid()
        dataset.PatientName = "Example^Patient"
        dataset.PatientID = "MRN-123456"
        dataset.PatientBirthDate = "19800102"
        dataset.StudyDate = "20260813"
        dataset.InstitutionName = "Example Hospital"
        dataset.BurnedInAnnotation = "NO"
        dataset.Rows = 8
        dataset.Columns = 8
        dataset.SamplesPerPixel = 1
        dataset.PhotometricInterpretation = "MONOCHROME2"
        dataset.BitsAllocated = 16
        dataset.BitsStored = 12
        dataset.HighBit = 11
        dataset.PixelRepresentation = 0
        dataset.PixelData = b"\0\0" * 64
        dataset.add_new((0x0011, 0x0010), "LO", "PRIVATE_CREATOR")
        dataset.save_as(str(path), enforce_file_format=True)

    def test_fail_closed_deidentification_and_evidence(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "source.dcm"
            self._fixture(source)
            before = audit_dicom(source)
            self.assertEqual(before["research_release_gate"], "fail")
            output = root / "release" / "deidentified.dcm"
            report = root / "release" / "deidentification-report.json"
            result = deidentify_dicom(source, output, report, b"test-secret-at-least-16-bytes")
            self.assertEqual(result["report"]["release_decision"], "conditional_pass")
            self.assertEqual(result["report"]["profile_conformance"], "not_claimed")
            verified = verify(result["evidence"], root / "release", False)
            self.assertTrue(verified["valid"], verified)
            self.assertEqual(verified["artifacts"]["status"], "valid")


@unittest.skipUnless(HAS_CRYPTO, "cryptography optional dependency unavailable")
class SigningTests(unittest.TestCase):
    def test_trusted_signature_and_untrusted_self_signature_distinguished(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = Config(size=32)
            ideal = make_phantom(32)
            certified = certified_filter(acquire(ideal, config), config)
            model = model_surrogate(certified, config)
            digest = pixel_digest(certified)
            evidence = build_evidence(config, {"replay_hash": digest, "replay_hash_repeat": digest}, metrics(certified, model), perturbation_audit(ideal, config, 2), generated_at="2026-08-13T00:00:00Z")
            private, public = root / "private.pem", root / "public.pem"
            identity = generate_keypair(private, public)
            signed = sign_evidence(evidence, private)
            untrusted = verify(signed, None, True)
            self.assertEqual(untrusted["assurance"], "signed_untrusted")
            trusted = verify(signed, None, True, {identity["public_key_fingerprint"]}, True)
            self.assertTrue(trusted["valid"], trusted)
            self.assertEqual(trusted["assurance"], "signed_trusted")


if __name__ == "__main__":
    unittest.main()

