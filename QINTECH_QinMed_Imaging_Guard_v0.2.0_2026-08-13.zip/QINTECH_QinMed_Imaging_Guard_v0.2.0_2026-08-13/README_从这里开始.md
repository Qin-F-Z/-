# QINTECH QinMed Imaging Guard Research Edition v0.2.0

## 一句话定位

QinMed Imaging Guard 是医学成像算法的本地确定性验证、数据/模型接口审计和机器证据平台。它不是诊断软件，不替代医生、伦理审查、数据授权、DICOM 正式符合性测试或监管审批。

## 立即体验

Windows 双击 `启动_QinMed_Imaging_Guard.bat`，或直接打开 `QinMed_Imaging_Guard_Standalone.html`。浏览器版不联网，只处理合成体模或用户主动选择的本地图像。

## v0.2.0 新增的可运行能力

1. fastMRI Guard：检查 fastMRI 兼容 HDF5 结构，对单线圈或多线圈 k-space 运行零填充逆 FFT/RSS，并将结果冻结为 12-bit PGM、报告和 QinEvidence。
2. Sealed Evaluation：在评分前锁定协议、案例清单哈希、失败处理和统计方法；评分时不删除失败案例，输出 NRMSE、全局 SSIM、PSNR、MAE 和确定性 bootstrap 区间。
3. DICOM Guard：检查直接标识符、私有标签、overlay 和 BurnedInAnnotation；存在像素且未明确声明无烧录文字时失败闭合。
4. Evidence Trust：Ed25519 签名、公钥指纹固定、工件 SHA-256 复验，并明确区分“签名有效”与“签名身份可信”。
5. 三套无患者数据的端到端示例：fastMRI 合成 HDF5、DICOM 合成文件、锁定协议模型输出评测。

## 安装可选真实数据能力

核心浏览器和合成体模不需要第三方 Python 包。fastMRI、DICOM 和签名功能需要可选依赖：

```powershell
.\安装_真实数据可选能力.ps1
```

如果需要指定 Python：

```powershell
$env:QINMED_PYTHON = 'C:\path\to\python.exe'
.\安装_真实数据可选能力.ps1
```

## 一键验收

核心验收：

```powershell
.\verify_all.ps1
```

强制验收 fastMRI、DICOM 与签名能力：

```powershell
$env:QINMED_PYTHON = 'C:\path\to\python.exe'
.\verify_all.ps1 -RequireOptional
```

## CLI 示例

```powershell
python -m qinmed.cli --help
python -m qinmed.cli fastmri-inspect input.h5 --output inspection.json
python -m qinmed.cli fastmri-reconstruct input.h5 --slice 0 --crop 320 --output fastmri-run
python -m qinmed.cli protocol-lock cases.json --name 'locked MRI evaluation' --model-id model-v1 --output locked-protocol.json
python -m qinmed.cli blind-eval locked-protocol.json cases.json predictions --output evaluation-run
python -m qinmed.cli dicom-audit input.dcm --output dicom-audit.json
$env:QINMED_DEID_SECRET = '从安全密钥系统读取且至少16字节'
python -m qinmed.cli dicom-deidentify input.dcm --output-dicom run\deidentified.dcm --report run\deidentification-report.json
python -m qinmed.cli keygen --private private.pem --public public.pem
python -m qinmed.cli sign evidence.json --private private.pem --output evidence.signed.json
```

生产环境不要把私钥放在产品目录中，也不要把秘密直接写入命令行历史。建议使用 HSM、KMS 或受控离线签名机。

## 证据独立复验

```powershell
python verifier\qinevidence_verify.py evidence.signed.qinevidence.json `
  --artifact-root run `
  --require-signature `
  --trusted-key-sha256 sha256:你的已登记公钥指纹 `
  --require-trusted-signature
```

仅仅“自带一个公钥并能验签”不等于身份可信；验证方必须从独立渠道取得并固定公钥指纹。

## 科学与合规边界

- fastMRI 适配器的 NumPy FFT 是浮点数值基线；本次运行后的 12-bit 整数工件可哈希固定，但不宣称不同 FFT 库和硬件之间逐位一致。
- DICOM Guard 是研究级保守实现，不宣称完整 DICOM PS3.15 Basic Application Level Confidentiality Profile 符合性；仍需像素 OCR/人工复核、机构隐私审查和正式 conformance testing。
- 内置模型代理与合成案例仅证明工作流可执行，不能证明真实模型优越、临床有效或具有患者获益。
- 软件不提高物理 ADC 的 ENOB，也不能消除热噪声、时钟抖动、INL/DNL 或采集链路误差。

## 目录

- `web/`：浏览器工作台源码。
- `qinmed/`：确定性核心、fastMRI、盲测、DICOM 与签名模块。
- `verifier/`：独立 QinEvidence 验证器。
- `examples/v0.2-extended/`：无患者数据的端到端扩展示例与演示签名。
- `protocols/`：预注册协议和模型文件接口规范。
- `docs/`：架构、隐私、专利、商业试点、外部验证材料、7 页技术验收书及桌面/移动界面验收图。
- `tests/`：核心与扩展测试。
- `tools/capture_ui.js`：通过 Chrome DevTools Protocol 固定真实桌面/移动 viewport 并生成界面验收图。
- `VERIFICATION_REPORT.md` / `verification_report.json`：人类和机器可读的本机验收结论。
- `SHA256SUMS.txt`：发布时生成的逐文件哈希清单。
