(function (global) {
  'use strict';

  const VERSION = '0.2.0';
  const SCHEMA = 'https://schemas.qinscience.com/qinevidence/1.0.0.json';
  const ROUNDING = ['down', 'up', 'toward_zero', 'away_from_zero', 'half_up', 'half_even'];

  function divRound(numerator, denominator, mode = 'half_even') {
    if (!Number.isSafeInteger(numerator) || !Number.isSafeInteger(denominator)) throw new RangeError('divRound requires safe integers');
    if (denominator === 0) throw new RangeError('division by zero');
    if (!ROUNDING.includes(mode)) throw new RangeError(`unsupported rounding mode: ${mode}`);
    const sign = (numerator < 0) !== (denominator < 0) ? -1 : 1;
    const n = Math.abs(numerator), d = Math.abs(denominator);
    const q = Math.floor(n / d), r = n % d;
    if (r === 0) return sign * q;
    let inc = false;
    if (mode === 'away_from_zero') inc = true;
    else if (mode === 'down') inc = sign < 0;
    else if (mode === 'up') inc = sign > 0;
    else if (mode === 'half_up') inc = r * 2 >= d;
    else if (mode === 'half_even') inc = r * 2 > d || (r * 2 === d && q % 2 === 1);
    return sign * (q + (inc ? 1 : 0));
  }

  function quantizeRatio(value, sourceMax, targetMax, mode) {
    return Math.max(0, Math.min(targetMax, divRound(value * targetMax, sourceMax, mode)));
  }

  function xorshift32(seed) {
    let state = (seed >>> 0) || 0x9e3779b9;
    return {
      next() {
        let value = state;
        value ^= value << 13;
        value ^= value >>> 17;
        value ^= value << 5;
        state = value >>> 0;
        return state;
      },
      symmetric(amplitude) {
        if (amplitude <= 0) return 0;
        return (this.next() % (2 * amplitude + 1)) - amplitude;
      }
    };
  }

  function insideEllipse(x, y, cx, cy, rx, ry, angle) {
    const cosine = Math.cos(angle), sine = Math.sin(angle);
    const dx = x - cx, dy = y - cy;
    const u = dx * cosine + dy * sine;
    const v = -dx * sine + dy * cosine;
    return (u * u) / (rx * rx) + (v * v) / (ry * ry) <= 1;
  }

  function makePhantom(size, variant = 'low_contrast') {
    const ellipses = [
      [0.00, 0.00, 0.69, 0.92, 0.00, 600],
      [0.00, -0.02, 0.64, 0.87, 0.00, 500],
      [0.22, 0.00, 0.11, 0.31, -0.31, 550],
      [-0.22, 0.00, 0.16, 0.41, 0.31, 420],
      [0.00, 0.35, 0.21, 0.25, 0.00, 480],
      [0.00, 0.10, 0.05, 0.05, 0.00, 900],
      [-0.08, -0.55, 0.05, 0.04, 0.00, 650],
      [0.28, -0.52, 0.08, 0.03, 0.00, 520]
    ];
    if (variant === 'low_contrast') {
      ellipses.push([-0.28, 0.28, 0.065, 0.065, 0.00, 48], [0.31, 0.27, 0.045, 0.045, 0.00, -42], [0.03, -0.31, 0.035, 0.035, 0.00, 34]);
    } else if (variant === 'resolution') {
      [0.050, 0.038, 0.028, 0.021, 0.016].forEach((radius, index) => ellipses.push([-0.32 + index * 0.16, 0.31, radius, radius, 0, 850]));
    } else if (variant !== 'anatomy') {
      throw new RangeError('unknown phantom variant');
    }
    const output = new Uint16Array(size * size);
    for (let row = 0; row < size; row++) {
      const y = 2 * (row + 0.5) / size - 1;
      for (let column = 0; column < size; column++) {
        const x = 2 * (column + 0.5) / size - 1;
        let value = 0;
        for (const [cx, cy, rx, ry, angle, delta] of ellipses) if (insideEllipse(x, y, cx, cy, rx, ry, angle)) value += delta;
        output[row * size + column] = Math.max(0, Math.min(4095, value));
      }
    }
    return output;
  }

  function validateConfig(config) {
    if (![32, 64, 96, 128].includes(config.size)) throw new RangeError('invalid size');
    if (config.bits < 8 || config.bits > 16) throw new RangeError('bits outside [8,16]');
    if (!ROUNDING.includes(config.rounding)) throw new RangeError('invalid rounding');
    if (config.noise < 0 || config.noise > 128) throw new RangeError('noise outside [0,128]');
  }

  function acquire(ideal, config, seedOffset = 0) {
    validateConfig(config);
    const targetMax = (2 ** config.bits) - 1;
    const rng = xorshift32((config.seed + seedOffset) >>> 0);
    const output = new Uint16Array(ideal.length);
    for (let i = 0; i < ideal.length; i++) {
      let code = quantizeRatio(Math.max(0, Math.min(4095, ideal[i])), 4095, targetMax, config.rounding);
      code = Math.max(0, Math.min(targetMax, code + rng.symmetric(config.noise)));
      output[i] = code;
    }
    return output;
  }

  function normalizeCodes(codes, bits, mode) {
    const sourceMax = (2 ** bits) - 1;
    const output = new Uint16Array(codes.length);
    for (let i = 0; i < codes.length; i++) output[i] = quantizeRatio(codes[i], sourceMax, 4095, mode);
    return output;
  }

  function certifiedFilter(codes, config) {
    validateConfig(config);
    const image = normalizeCodes(codes, config.bits, config.rounding);
    const size = config.size;
    const output = new Uint16Array(image.length);
    const radius = config.radius || 1;
    const spatial = new Map([[0, 8], [1, 5], [2, 2], [3, 1], [4, 1], [5, 1], [8, 1]]);
    for (let row = 0; row < size; row++) {
      for (let column = 0; column < size; column++) {
        const center = image[row * size + column];
        let weighted = 0, totalWeight = 0;
        for (let dr = -radius; dr <= radius; dr++) {
          const rr = Math.min(size - 1, Math.max(0, row + dr));
          for (let dc = -radius; dc <= radius; dc++) {
            const cc = Math.min(size - 1, Math.max(0, column + dc));
            const value = image[rr * size + cc];
            const rangeWeight = Math.abs(value - center) <= config.threshold ? 8 : 1;
            const weight = (spatial.get(dr * dr + dc * dc) || 1) * rangeWeight;
            weighted += value * weight;
            totalWeight += weight;
          }
        }
        output[row * size + column] = Math.max(0, Math.min(4095, divRound(weighted, totalWeight, config.rounding)));
      }
    }
    return output;
  }

  function modelSurrogate(certified, config) {
    const size = config.size;
    const output = new Uint16Array(certified.length);
    for (let row = 0; row < size; row++) {
      for (let column = 0; column < size; column++) {
        let total = 0, count = 0;
        for (let dr = -1; dr <= 1; dr++) {
          const rr = Math.min(size - 1, Math.max(0, row + dr));
          for (let dc = -1; dc <= 1; dc++) {
            const cc = Math.min(size - 1, Math.max(0, column + dc));
            total += certified[rr * size + cc];
            count++;
          }
        }
        const index = row * size + column;
        const blur = divRound(total, count, config.rounding);
        const enhanced = certified[index] + divRound((certified[index] - blur) * config.strength, 100, config.rounding);
        output[index] = Math.max(0, Math.min(4095, enhanced));
      }
    }
    return output;
  }

  function metrics(reference, candidate) {
    if (!reference.length || reference.length !== candidate.length) throw new RangeError('image shape mismatch');
    let abs = 0, maxAbs = 0, squared = 0;
    for (let i = 0; i < reference.length; i++) {
      const delta = candidate[i] - reference[i];
      const magnitude = Math.abs(delta);
      abs += magnitude;
      squared += delta * delta;
      if (magnitude > maxAbs) maxAbs = magnitude;
    }
    const mse = squared / reference.length;
    return {
      mae: abs / reference.length,
      maxAbs,
      rmse: Math.sqrt(mse),
      psnr: mse === 0 ? Infinity : 10 * Math.log10((4095 * 4095) / mse)
    };
  }

  function differenceMap(reference, candidate) {
    const output = new Uint16Array(reference.length);
    for (let i = 0; i < output.length; i++) output[i] = Math.abs(candidate[i] - reference[i]);
    return output;
  }

  function perturbationAudit(ideal, config, trials = 8) {
    if (trials < 2 || trials > 32) throw new RangeError('trials outside [2,32]');
    const minima = new Uint16Array(ideal.length); minima.fill(65535);
    const maxima = new Uint16Array(ideal.length);
    for (let trial = 0; trial < trials; trial++) {
      const raw = acquire(ideal, config, trial * 104729);
      const output = modelSurrogate(certifiedFilter(raw, config), config);
      for (let i = 0; i < output.length; i++) {
        if (output[i] < minima[i]) minima[i] = output[i];
        if (output[i] > maxima[i]) maxima[i] = output[i];
      }
    }
    const rangeMap = new Uint16Array(ideal.length);
    let total = 0, maxRange = 0;
    for (let i = 0; i < rangeMap.length; i++) {
      rangeMap[i] = maxima[i] - minima[i];
      total += rangeMap[i];
      if (rangeMap[i] > maxRange) maxRange = rangeMap[i];
    }
    return { trials, maxRange, meanRange: total / rangeMap.length, rangeMap, status: 'observed_not_proven' };
  }

  function sha256Bytes(bytes) {
    const rightRotate = (value, amount) => (value >>> amount) | (value << (32 - amount));
    const maxWord = 2 ** 32;
    const words = [];
    const bitLength = bytes.length * 8;
    const hash = [], k = [], composites = {};
    let primeCounter = 0;
    for (let candidate = 2; primeCounter < 64; candidate++) {
      if (!composites[candidate]) {
        for (let multiple = candidate; multiple < 400; multiple += candidate) composites[multiple] = true;
        hash[primeCounter] = (Math.sqrt(candidate) * maxWord) | 0;
        k[primeCounter++] = (Math.cbrt(candidate) * maxWord) | 0;
      }
    }
    const padded = Array.from(bytes);
    padded.push(0x80);
    while ((padded.length % 64) !== 56) padded.push(0);
    const high = Math.floor(bitLength / maxWord), low = bitLength >>> 0;
    padded.push((high >>> 24) & 255, (high >>> 16) & 255, (high >>> 8) & 255, high & 255, (low >>> 24) & 255, (low >>> 16) & 255, (low >>> 8) & 255, low & 255);
    for (let i = 0; i < padded.length; i++) words[i >> 2] = (words[i >> 2] || 0) | padded[i] << ((3 - i) % 4) * 8;
    let state = hash.slice(0, 8);
    for (let offset = 0; offset < words.length; offset += 16) {
      const w = words.slice(offset, offset + 16);
      const old = state.slice();
      for (let i = 0; i < 64; i++) {
        const w15 = w[i - 15], w2 = w[i - 2];
        const a = state[0], e = state[4];
        const temp1 = state[7] + (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25)) + ((e & state[5]) ^ (~e & state[6])) + k[i]
          + (w[i] = i < 16 ? w[i] : (w[i - 16] + (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3)) + w[i - 7] + (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))) | 0);
        const temp2 = (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22)) + ((a & state[1]) ^ (a & state[2]) ^ (state[1] & state[2]));
        state = [(temp1 + temp2) | 0].concat(state);
        state[4] = (state[4] + temp1) | 0;
        state.pop();
      }
      state = state.map((value, index) => (value + old[index]) | 0);
    }
    return state.map(value => [3, 2, 1, 0].map(shift => ((value >>> (shift * 8)) & 255).toString(16).padStart(2, '0')).join('')).join('');
  }

  function utf8Bytes(text) {
    if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(text);
    return Uint8Array.from(unescape(encodeURIComponent(text)), char => char.charCodeAt(0));
  }

  function sha256(text) { return sha256Bytes(utf8Bytes(text)); }

  function pixelDigest(values) {
    const bytes = new Uint8Array(values.length * 2);
    for (let i = 0; i < values.length; i++) {
      bytes[i * 2] = values[i] & 255;
      bytes[i * 2 + 1] = (values[i] >>> 8) & 255;
    }
    return `sha256:${sha256Bytes(bytes)}`;
  }

  function canonicalize(value) {
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return `[${value.map(canonicalize).join(',')}]`;
    return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${canonicalize(value[key])}`).join(',')}}`;
  }

  function buildEvidence(config, hashes, observed, perturbation) {
    const deterministic = hashes.replay_hash === hashes.replay_hash_repeat;
    const core = {
      evidence_kind: 'qinmed-imaging-audit',
      generated_at: new Date().toISOString(),
      subject: { intended_use: 'research verification and algorithm QA only', product: 'QinMed Imaging Guard Research Edition', profile: 'synthetic-or-local-image-post-acquisition-audit' },
      producer: { component: 'qinmed.browser', name: 'QINTECH' },
      engine: { name: 'QinMed deterministic browser reference', version: VERSION },
      inputs: [], outputs: [],
      execution: { adc_bits: config.bits, edge_threshold: config.threshold, filter_radius: config.radius, model_strength_percent: config.strength, noise_codes: config.noise, rounding: config.rounding, seed: config.seed, size: config.size },
      results: { hashes, observed_metrics: observed, perturbation: { max_range_codes: perturbation.maxRange, mean_range_codes: perturbation.meanRange, status: perturbation.status, trials: perturbation.trials } },
      checks: [
        { evidence_paths: ['core.results.hashes.replay_hash', 'core.results.hashes.replay_hash_repeat'], expected: true, id: 'qinmed.replay', observed: deterministic, severity: 'high', statement: 'Same engine and declared input replay to the same output digest.', status: deterministic ? 'pass' : 'fail' },
        { evidence_paths: ['core.results.perturbation'], expected: 2, id: 'qinmed.perturbation', observed: perturbation.trials, severity: 'high', statement: 'Declared perturbation trials were executed and reported without upgrading observation to proof.', status: perturbation.trials >= 2 ? 'pass' : 'unknown', unit: 'trials' },
        { evidence_paths: ['core.coverage.excluded'], expected: 'independent_clinical_validation', id: 'qinmed.clinical_validation', observed: 'not_performed', severity: 'critical', statement: 'Clinical safety and effectiveness have not been established.', status: 'unknown' }
      ],
      claims: [
        { assumptions: ['integer semantics and canonical serialization remain unchanged'], check_ids: ['qinmed.replay'], exclusions: ['cross-browser certification', 'clinical equivalence'], id: 'qinmed.deterministic_replay', scope: 'same implementation configuration and input', statement: 'The packaged reference engine replays this run deterministically.', status: deterministic ? 'pass' : 'fail' },
        { assumptions: ['synthetic perturbation generator is the declared threat model'], check_ids: ['qinmed.perturbation'], exclusions: ['worst-case proof', 'distribution shift', 'patient outcome'], id: 'qinmed.perturbation_observation', scope: 'finite declared perturbation trials only', statement: 'Output drift was measured for the declared perturbation set.', status: perturbation.trials >= 2 ? 'pass' : 'unknown' },
        { assumptions: [], check_ids: ['qinmed.clinical_validation'], exclusions: ['diagnosis', 'treatment selection', 'patient management'], id: 'qinmed.clinical_use', scope: 'clinical use', statement: 'Clinical diagnostic use is not established.', status: 'unknown' }
      ],
      coverage: { included: ['post-acquisition integer requantization', 'declared rounding', 'integer edge-aware filter', 'surrogate-output difference map', 'finite perturbation observation', 'hash binding'], excluded: ['transistor-level ADC behavior', 'DICOM conformance', 'patient data validation', 'trained medical AI', 'clinical validation', 'regulatory clearance', 'hardware energy measurement'] },
      environment: { network: 'not required', runtime: 'browser JavaScript reference' },
      lifecycle: { revocation_uri: null, status: 'valid', supersedes: [] }
    };
    const coreHash = `sha256:${sha256(canonicalize(core))}`;
    return { $schema: SCHEMA, spec_version: '1.0.0', evidence_id: `urn:qinevidence:${coreHash}`, core, integrity: { canonicalization: 'qin-canonical-json/1', core_hash: coreHash, signatures: [] } };
  }

  function fromImageData(imageData, size) {
    const output = new Uint16Array(size * size);
    const { data, width, height } = imageData;
    for (let row = 0; row < size; row++) {
      const sourceRow = Math.min(height - 1, Math.floor((row + 0.5) * height / size));
      for (let column = 0; column < size; column++) {
        const sourceColumn = Math.min(width - 1, Math.floor((column + 0.5) * width / size));
        const offset = (sourceRow * width + sourceColumn) * 4;
        const luminance = Math.round(0.2126 * data[offset] + 0.7152 * data[offset + 1] + 0.0722 * data[offset + 2]);
        output[row * size + column] = Math.round(luminance * 4095 / 255);
      }
    }
    return output;
  }

  global.QinMed = { VERSION, ROUNDING, divRound, quantizeRatio, makePhantom, acquire, certifiedFilter, modelSurrogate, metrics, differenceMap, perturbationAudit, sha256, pixelDigest, canonicalize, buildEvidence, fromImageData };
})(typeof window !== 'undefined' ? window : globalThis);
