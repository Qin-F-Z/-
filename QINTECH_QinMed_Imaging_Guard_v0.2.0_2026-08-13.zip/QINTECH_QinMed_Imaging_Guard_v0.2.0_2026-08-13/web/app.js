(function () {
  'use strict';
  const Q = window.QinMed;
  const $ = id => document.getElementById(id);
  const canvases = {
    raw: $('raw-canvas'), certified: $('certified-canvas'), model: $('model-canvas'), difference: $('difference-canvas'), profile: $('profile-canvas')
  };
  const state = { ideal: null, raw: null, certified: null, model: null, difference: null, stability: null, evidence: null, config: null, selected: [48, 48], mapMode: 'difference', sourceLabel: 'synthetic' };

  function config() {
    return {
      size: Number($('size').value), bits: Number($('bits').value), rounding: $('rounding').value,
      noise: Number($('noise').value), seed: Number($('seed').value) >>> 0,
      radius: Number($('radius').value), threshold: Number($('threshold').value), strength: Number($('strength').value)
    };
  }

  function setBusy(value, message) {
    document.body.classList.toggle('busy', value);
    $('run').disabled = value;
    $('stress').disabled = value;
    if (message) $('evidence-state').textContent = message;
  }

  function resetSource() {
    const c = config();
    state.ideal = Q.makePhantom(c.size, $('phantom').value);
    state.sourceLabel = `synthetic:${$('phantom').value}`;
    state.selected = [Math.floor(c.size / 2), Math.floor(c.size / 2)];
    clearResults();
    const rawPreview = new Uint16Array(state.ideal.length);
    for (let i = 0; i < rawPreview.length; i++) rawPreview[i] = state.ideal[i];
    drawGray(canvases.raw, rawPreview, c.size);
    drawEmpty(canvases.certified, '等待认证处理');
    drawEmpty(canvases.model, '等待模型输出');
    drawEmpty(canvases.difference, '等待审计地图');
  }

  function clearResults() {
    state.raw = state.certified = state.model = state.difference = state.stability = state.evidence = null;
    ['mae', 'max-diff', 'runtime'].forEach(id => $(id).textContent = '—');
    $('max-drift').textContent = '待审计';
    $('replay-status').textContent = '待运行';
    $('replay-hash').textContent = '—';
    $('raw-hash').textContent = 'SHA-256 —';
    $('certified-hash').textContent = 'SHA-256 —';
    $('model-hash').textContent = 'SHA-256 —';
    $('evidence-id').textContent = '运行流程后生成规范化 core hash、evidence_id 与独立验证材料。';
    $('evidence-state').textContent = '尚未生成';
    $('export-evidence').disabled = true;
    $('export-report').disabled = true;
    setClaim('claim-replay', 'unknown');
    setClaim('claim-perturbation', 'unknown');
    updatePixel();
  }

  function windowPixel(value) {
    const level = Number($('level').value), width = Math.max(1, Number($('window').value));
    return Math.max(0, Math.min(255, Math.round((value - (level - width / 2)) * 255 / width)));
  }

  function drawGray(canvas, values, size) {
    const ctx = canvas.getContext('2d');
    const image = ctx.createImageData(size, size);
    for (let i = 0; i < values.length; i++) {
      const value = windowPixel(values[i]);
      image.data[i * 4] = image.data[i * 4 + 1] = image.data[i * 4 + 2] = value;
      image.data[i * 4 + 3] = 255;
    }
    const scratch = document.createElement('canvas');
    scratch.width = scratch.height = size;
    scratch.getContext('2d').putImageData(image, 0, 0);
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(scratch, 0, 0, canvas.width, canvas.height);
    drawCrosshair(ctx, canvas, size);
  }

  function drawHeat(canvas, values, size) {
    const ctx = canvas.getContext('2d');
    let max = 1;
    for (const value of values) if (value > max) max = value;
    const image = ctx.createImageData(size, size);
    for (let i = 0; i < values.length; i++) {
      const t = Math.sqrt(values[i] / max);
      const r = Math.round(255 * Math.min(1, t * 1.8));
      const g = Math.round(255 * Math.max(0, 1 - Math.abs(t - 0.52) * 2));
      const b = Math.round(230 * Math.max(0, 1 - t * 1.3));
      image.data.set([r, g, b, 255], i * 4);
    }
    const scratch = document.createElement('canvas'); scratch.width = scratch.height = size;
    scratch.getContext('2d').putImageData(image, 0, 0);
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(scratch, 0, 0, canvas.width, canvas.height);
    drawCrosshair(ctx, canvas, size);
  }

  function drawCrosshair(ctx, canvas, size) {
    const [row, column] = state.selected;
    const x = (column + 0.5) * canvas.width / size;
    const y = (row + 0.5) * canvas.height / size;
    ctx.save();
    ctx.strokeStyle = '#42d3c7'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(x - 7, y); ctx.lineTo(x + 7, y); ctx.moveTo(x, y - 7); ctx.lineTo(x, y + 7); ctx.stroke();
    ctx.restore();
  }

  function drawEmpty(canvas, label) {
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#080a0f'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#697487'; ctx.font = '13px Segoe UI'; ctx.textAlign = 'center'; ctx.fillText(label, canvas.width / 2, canvas.height / 2);
  }

  function drawAll() {
    const c = state.config || config();
    if (state.raw) drawGray(canvases.raw, normalizeRaw(state.raw, c.bits), c.size);
    else if (state.ideal) drawGray(canvases.raw, state.ideal, c.size);
    if (state.certified) drawGray(canvases.certified, state.certified, c.size);
    if (state.model) drawGray(canvases.model, state.model, c.size);
    const map = state.mapMode === 'stability' ? state.stability : state.difference;
    if (map) drawHeat(canvases.difference, map, c.size);
    drawProfile();
    updatePixel();
  }

  function normalizeRaw(raw, bits) {
    const max = (2 ** bits) - 1;
    const out = new Uint16Array(raw.length);
    for (let i = 0; i < out.length; i++) out[i] = Math.round(raw[i] * 4095 / max);
    return out;
  }

  function runPipeline() {
    const c = config();
    if (!state.ideal || state.ideal.length !== c.size * c.size) resetSource();
    setBusy(true, '正在运行确定性流程…');
    window.setTimeout(() => {
      const started = performance.now();
      state.config = c;
      state.raw = Q.acquire(state.ideal, c, 0);
      state.certified = Q.certifiedFilter(state.raw, c);
      state.model = Q.modelSurrogate(state.certified, c);
      state.difference = Q.differenceMap(state.certified, state.model);
      const repeat = Q.certifiedFilter(Q.acquire(state.ideal, c, 0), c);
      const hashes = {
        ideal_hash: Q.pixelDigest(state.ideal), raw_hash: Q.pixelDigest(state.raw), certified_hash: Q.pixelDigest(state.certified),
        model_hash: Q.pixelDigest(state.model), replay_hash: Q.pixelDigest(state.certified), replay_hash_repeat: Q.pixelDigest(repeat), source: state.sourceLabel
      };
      const observed = Q.metrics(state.certified, state.model);
      const placeholder = state.stability ? { trials: Number($('trials').value), maxRange: maxOf(state.stability), meanRange: meanOf(state.stability), status: 'observed_not_proven' } : { trials: 0, maxRange: 0, meanRange: 0, status: 'not_run' };
      state.evidence = Q.buildEvidence(c, hashes, observed, placeholder);
      const elapsed = performance.now() - started;
      const replayPass = hashes.replay_hash === hashes.replay_hash_repeat;
      $('mae').textContent = observed.mae.toFixed(2);
      $('max-diff').textContent = observed.maxAbs.toLocaleString('zh-CN');
      $('runtime').textContent = `${elapsed.toFixed(1)} ms`;
      $('replay-status').textContent = replayPass ? 'PASS' : 'FAIL';
      $('replay-status').style.color = replayPass ? '#55d68b' : '#ff727d';
      $('replay-hash').textContent = shortHash(hashes.replay_hash);
      $('raw-hash').textContent = shortHash(hashes.raw_hash);
      $('certified-hash').textContent = shortHash(hashes.certified_hash);
      $('model-hash').textContent = shortHash(hashes.model_hash);
      $('evidence-id').textContent = state.evidence.evidence_id;
      $('evidence-state').textContent = '完整性已生成 · 未签名';
      $('export-evidence').disabled = false;
      $('export-report').disabled = false;
      setClaim('claim-replay', replayPass ? 'pass' : 'fail');
      setClaim('claim-perturbation', state.stability ? 'pass' : 'unknown');
      drawAll();
      setBusy(false, 'QinEvidence 已生成');
      $('run').classList.add('flash'); setTimeout(() => $('run').classList.remove('flash'), 650);
    }, 30);
  }

  function runStress() {
    if (!state.certified) runPipeline();
    setBusy(true, '正在执行有限扰动试验…');
    window.setTimeout(() => {
      const c = state.config || config();
      const audit = Q.perturbationAudit(state.ideal, c, Number($('trials').value));
      state.stability = audit.rangeMap;
      state.mapMode = 'stability';
      $('max-drift').textContent = audit.maxRange.toLocaleString('zh-CN');
      $('map-mode').textContent = `${audit.trials} TRIAL RANGE`;
      setClaim('claim-perturbation', 'pass');
      toggleMapButtons();
      const hashes = state.evidence.core.results.hashes;
      const observed = Q.metrics(state.certified, state.model);
      state.evidence = Q.buildEvidence(c, hashes, observed, audit);
      $('evidence-id').textContent = state.evidence.evidence_id;
      $('evidence-state').textContent = `扰动审计完成 · ${audit.trials} 次有限试验`;
      drawAll();
      setBusy(false);
    }, 30);
  }

  function setClaim(id, status) {
    const element = $(id);
    element.className = `claim-status ${status}`;
    element.textContent = status.toUpperCase();
  }

  function shortHash(hash) { return `${hash.slice(0, 15)}…${hash.slice(-8)}`; }
  function maxOf(values) { let max = 0; for (const value of values) if (value > max) max = value; return max; }
  function meanOf(values) { let total = 0; for (const value of values) total += value; return total / values.length; }

  function updatePixel() {
    const c = state.config || config();
    const [row, column] = state.selected;
    const index = row * c.size + column;
    $('pixel-coordinate').textContent = `(${row}, ${column})`;
    $('pixel-raw').textContent = state.raw ? state.raw[index] : '—';
    $('pixel-certified').textContent = state.certified ? state.certified[index] : '—';
    $('pixel-model').textContent = state.model ? state.model[index] : '—';
    $('pixel-difference').textContent = state.difference ? state.difference[index] : '—';
    $('pixel-stability').textContent = state.stability ? state.stability[index] : '未测';
  }

  function drawProfile() {
    const canvas = canvases.profile, ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#0b0e14'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = '#2b3342'; ctx.lineWidth = 1;
    for (let y = 20; y < canvas.height; y += 35) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke(); }
    if (!state.certified || !state.model) return;
    const size = state.config.size, row = state.selected[0];
    const plot = (values, color) => {
      ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.beginPath();
      for (let column = 0; column < size; column++) {
        const x = column * (canvas.width - 1) / (size - 1);
        const y = canvas.height - 8 - values[row * size + column] / 4095 * (canvas.height - 16);
        if (column === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
    };
    plot(state.certified, '#42d3c7'); plot(state.model, '#a89ff0');
    ctx.fillStyle = '#42d3c7'; ctx.fillRect(12, 10, 16, 2); ctx.fillStyle = '#98a2b3'; ctx.font = '10px Segoe UI'; ctx.fillText('认证', 34, 14);
    ctx.fillStyle = '#a89ff0'; ctx.fillRect(82, 10, 16, 2); ctx.fillStyle = '#98a2b3'; ctx.fillText('模型', 104, 14);
  }

  function toggleMapButtons() {
    $('show-diff').classList.toggle('selected', state.mapMode === 'difference');
    $('show-stability').classList.toggle('selected', state.mapMode === 'stability');
  }

  function download(name, type, content) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = name; document.body.appendChild(anchor); anchor.click(); anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function exportEvidence() {
    if (state.evidence) download('QinMed_Imaging_Audit.qinevidence.json', 'application/json;charset=utf-8', JSON.stringify(state.evidence, null, 2));
  }

  function exportReport() {
    if (!state.evidence) return;
    const r = state.evidence.core.results;
    const html = `<!doctype html><meta charset="utf-8"><title>QinMed Audit Report</title><style>body{font:14px/1.6 system-ui;max-width:900px;margin:40px auto;padding:0 20px;color:#20242c}h1{color:#49447f}code{overflow-wrap:anywhere}.warn{padding:12px;background:#fff4dc;border-left:4px solid #e0a329}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ddd;padding:8px;text-align:left}</style><h1>QinMed Imaging Guard 审计报告</h1><p class="warn"><b>Research Edition：</b>仅限科研和算法 QA，不用于诊断、治疗选择或患者管理。</p><h2>事件身份</h2><p><code>${state.evidence.evidence_id}</code></p><h2>配置</h2><pre>${JSON.stringify(state.evidence.core.execution, null, 2)}</pre><h2>观测结果</h2><pre>${JSON.stringify(r, null, 2)}</pre><h2>声称边界</h2><table><tr><th>声称</th><th>状态</th><th>范围</th></tr>${state.evidence.core.claims.map(c => `<tr><td>${c.statement}</td><td>${c.status}</td><td>${c.scope}</td></tr>`).join('')}</table><p>完整机器证据请以 QinEvidence JSON 和独立验证器为准。</p>`;
    download('QinMed_Imaging_Audit_Report.html', 'text/html;charset=utf-8', html);
  }

  function loadImage(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const image = new Image();
      image.onload = () => {
        const c = config();
        const scratch = document.createElement('canvas'); scratch.width = image.width; scratch.height = image.height;
        const ctx = scratch.getContext('2d', { willReadFrequently: true }); ctx.drawImage(image, 0, 0);
        state.ideal = Q.fromImageData(ctx.getImageData(0, 0, image.width, image.height), c.size);
        state.sourceLabel = `local-image:${Q.sha256(file.name + ':' + file.size + ':' + file.lastModified)}`;
        state.selected = [Math.floor(c.size / 2), Math.floor(c.size / 2)];
        clearResults(); drawGray(canvases.raw, state.ideal, c.size);
        $('evidence-state').textContent = '本地图像已载入 · 未上传';
      };
      image.src = reader.result;
    };
    reader.readAsDataURL(file);
  }

  function bindCanvas(canvas) {
    canvas.addEventListener('click', event => {
      const c = state.config || config();
      const rect = canvas.getBoundingClientRect();
      const column = Math.max(0, Math.min(c.size - 1, Math.floor((event.clientX - rect.left) / rect.width * c.size)));
      const row = Math.max(0, Math.min(c.size - 1, Math.floor((event.clientY - rect.top) / rect.height * c.size)));
      state.selected = [row, column]; drawAll();
    });
  }

  $('noise').addEventListener('input', () => $('noise-value').textContent = `${$('noise').value} codes`);
  $('threshold').addEventListener('input', () => $('threshold-value').textContent = `${$('threshold').value} codes`);
  $('strength').addEventListener('input', () => $('strength-value').textContent = `${$('strength').value}%`);
  $('level').addEventListener('input', () => { $('level-value').textContent = $('level').value; drawAll(); });
  $('window').addEventListener('input', () => { $('window-value').textContent = $('window').value; drawAll(); });
  $('size').addEventListener('change', resetSource);
  $('phantom').addEventListener('change', resetSource);
  $('load-phantom').addEventListener('click', resetSource);
  $('image-input').addEventListener('change', event => loadImage(event.target.files[0]));
  $('run').addEventListener('click', runPipeline);
  $('stress').addEventListener('click', runStress);
  $('export-evidence').addEventListener('click', exportEvidence);
  $('export-report').addEventListener('click', exportReport);
  $('show-diff').addEventListener('click', () => { state.mapMode = 'difference'; $('map-mode').textContent = 'MODEL − CERTIFIED'; toggleMapButtons(); drawAll(); });
  $('show-stability').addEventListener('click', () => { state.mapMode = 'stability'; $('map-mode').textContent = state.stability ? `${$('trials').value} TRIAL RANGE` : 'NOT RUN'; toggleMapButtons(); drawAll(); });
  Object.values(canvases).filter(canvas => canvas !== canvases.profile).forEach(bindCanvas);

  resetSource();
  window.setTimeout(runPipeline, 80);
})();

